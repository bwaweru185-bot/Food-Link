import { Stack, router, useSegments } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { useEffect } from "react";
import { QueryProvider } from "../providers/QueryProvider";
import { useAuthStore } from "../store/auth";

function Guard() {
  const segments = useSegments();
  const { hydrated } = useAuthStore();

  useEffect(() => {
    if (!hydrated) return;
    const inAuth = segments[0] === "(auth)";
    // The access token is intentionally not exposed to the UI store.
    // The API client is the authority for token presence/refresh.
    if (!inAuth) return;
    // Login screen remains public; authenticated users are redirected after login.
  }, [hydrated, segments]);

  return null;
}

export default function RootLayout() {
  useEffect(() => {
    void useAuthStore.getState().hydrate();
  }, []);

  return (
    <QueryProvider>
      <Guard />
      <StatusBar style="auto" />
      <Stack screenOptions={{ headerBackTitle: "Back" }}>
        <Stack.Screen name="(auth)" options={{ headerShown: false }} />
        <Stack.Screen name="(vendor)" options={{ headerShown: false }} />
      </Stack>
    </QueryProvider>
  );
}