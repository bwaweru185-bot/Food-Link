import { Redirect } from "expo-router";
import { ActivityIndicator, View } from "react-native";
import { useAuthStore } from "../store/auth";

export default function Index() {
  const { hydrated } = useAuthStore();
  if (!hydrated) return <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}><ActivityIndicator /></View>;
  return <Redirect href="/(auth)/login" />;
}