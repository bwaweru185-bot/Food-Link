import { useState } from "react";
import { Alert, StyleSheet, Text, TextInput, View } from "react-native";
import { router } from "expo-router";
import { Screen } from "../../components/Screen";
import { Button } from "../../components/Button";
import { colors, spacing } from "../../constants/theme";
import { authService } from "../../services/auth";
import { useAuthStore } from "../../store/auth";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit() {
    if (!email.trim() || !password) return Alert.alert("Missing details", "Enter your email and password.");
    setLoading(true);
    try {
      const result = await authService.login(email.trim().toLowerCase(), password);
      await useAuthStore.getState().setSession(result.user, result.tokens);
      router.replace("/(vendor)");
    } catch (error) {
      Alert.alert("Sign in failed", error instanceof Error ? error.message : "Please try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <Screen>
      <View style={styles.hero}>
        <Text style={styles.title}>Vendor Portal</Text>
        <Text style={styles.subtitle}>Manage your store, menu and incoming orders.</Text>
      </View>
      <View style={styles.form}>
        <TextInput autoCapitalize="none" autoComplete="email" keyboardType="email-address" placeholder="Business email" value={email} onChangeText={setEmail} style={styles.input} />
        <TextInput autoCapitalize="none" secureTextEntry placeholder="Password" value={password} onChangeText={setPassword} style={styles.input} />
        <Button label="Sign in" onPress={() => void submit()} loading={loading} />
      </View>
    </Screen>
  );
}
const styles = StyleSheet.create({
  hero: { paddingTop: spacing.xl, gap: spacing.sm },
  title: { fontSize: 32, fontWeight: "900", color: colors.text },
  subtitle: { fontSize: 16, color: colors.muted, lineHeight: 23 },
  form: { gap: spacing.md, marginTop: spacing.lg },
  input: { minHeight: 50, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surface, borderRadius: 12, paddingHorizontal: spacing.md, fontSize: 16 },
});