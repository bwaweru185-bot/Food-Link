import { useQuery } from "@tanstack/react-query";
import { router } from "expo-router";
import { Pressable, StyleSheet, Switch, Text, View } from "react-native";
import { Screen } from "../../components/Screen";
import { LoadingState, ErrorState } from "../../components/StateView";
import { colors, spacing } from "../../constants/theme";
import { dashboardService } from "../../services/dashboard";
import { storeService } from "../../services/store";
import { useVendorStore } from "../../store/vendor";

export default function DashboardScreen() {
  const { store, setStore } = useVendorStore();
  const storeQuery = useQuery({ queryKey: ["store"], queryFn: storeService.get, staleTime: 30_000 });
  const dashboardQuery = useQuery({ queryKey: ["dashboard"], queryFn: dashboardService.get, refetchInterval: 15_000 });

  if (storeQuery.isLoading || dashboardQuery.isLoading) return <Screen><LoadingState /></Screen>;
  if (storeQuery.error || dashboardQuery.error) {
    return <Screen><ErrorState message={(storeQuery.error ?? dashboardQuery.error) instanceof Error ? (storeQuery.error ?? dashboardQuery.error)!.message : "Unable to load dashboard."} onRetry={() => { void storeQuery.refetch(); void dashboardQuery.refetch(); }} /></Screen>;
  }

  const currentStore = store ?? storeQuery.data!;
  const data = dashboardQuery.data!;

  async function toggle(value: boolean) {
    const next = await storeService.setStatus(value ? "open" : "closed");
    setStore(next);
    await dashboardQuery.refetch();
  }

  return (
    <Screen>
      <View style={styles.header}>
        <View style={{ flex: 1 }}>
          <Text style={styles.title}>{currentStore.name}</Text>
          <Text style={styles.muted}>{currentStore.address}</Text>
        </View>
        <Switch value={currentStore.status === "open"} onValueChange={(value) => void toggle(value)} />
      </View>

      <View style={styles.status}><Text style={styles.statusText}>{currentStore.status === "open" ? "Store is open" : "Store is closed"}</Text></View>

      <Text style={styles.section}>Today</Text>
      <View style={styles.grid}>
        <Metric label="New orders" value={data.newOrders} />
        <Metric label="Preparing" value={data.preparingOrders} />
        <Metric label="Ready" value={data.readyOrders} />
        <Metric label="Orders today" value={data.todayOrders} />
      </View>

      <View style={styles.revenue}>
        <Text style={styles.label}>Gross sales</Text>
        <Text style={styles.money}>{data.todayGross.toFixed(2)}</Text>
        <Text style={styles.muted}>Pending payout: {data.pendingPayout.toFixed(2)}</Text>
      </View>

      <Pressable style={styles.action} onPress={() => router.push("/(vendor)/orders")}><Text style={styles.actionText}>View incoming orders</Text></Pressable>
      <Pressable style={styles.action} onPress={() => router.push("/(vendor)/menu")}><Text style={styles.actionText}>Manage menu</Text></Pressable>
      <Pressable style={styles.action} onPress={() => router.push("/(vendor)/store")}><Text style={styles.actionText}>Store settings</Text></Pressable>
    </Screen>
  );
}

function Metric({ label, value }: { label: string; value: number }) {
  return <View style={styles.metric}><Text style={styles.metricValue}>{value}</Text><Text style={styles.muted}>{label}</Text></View>;
}
const styles = StyleSheet.create({
  header: { flexDirection: "row", alignItems: "center", gap: spacing.md },
  title: { fontSize: 26, fontWeight: "900", color: colors.text },
  muted: { color: colors.muted },
  status: { backgroundColor: colors.primarySoft, padding: 12, borderRadius: 12 },
  statusText: { color: colors.primary, fontWeight: "800" },
  section: { fontSize: 20, fontWeight: "800", color: colors.text, marginTop: spacing.md },
  grid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  metric: { width: "47%", backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 14, padding: spacing.md },
  metricValue: { fontSize: 25, fontWeight: "900", color: colors.text },
  revenue: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 14, padding: spacing.md, gap: 6 },
  label: { color: colors.muted },
  money: { fontSize: 30, fontWeight: "900", color: colors.primary },
  action: { minHeight: 50, borderRadius: 12, backgroundColor: colors.text, justifyContent: "center", alignItems: "center" },
  actionText: { color: "#fff", fontWeight: "800" },
});