import { useQuery } from "@tanstack/react-query";
import { router } from "expo-router";
import { Screen } from "../../../components/Screen";
import { OrderCard } from "../../../components/OrderCard";
import { EmptyState, ErrorState, LoadingState } from "../../../components/StateView";
import { orderService } from "../../../services/orders";
import { Text } from "react-native";
import { colors } from "../../../constants/theme";

export default function OrdersScreen() {
  const query = useQuery({ queryKey: ["orders"], queryFn: () => orderService.list(), refetchInterval: 10_000 });
  if (query.isLoading) return <Screen><LoadingState /></Screen>;
  if (query.error) return <Screen><ErrorState message={query.error instanceof Error ? query.error.message : "Unable to load orders."} onRetry={() => void query.refetch()} /></Screen>;
  const orders = query.data ?? [];
  return (
    <Screen>
      <Text style={{ fontSize: 26, fontWeight: "900", color: colors.text }}>Orders</Text>
      {orders.length === 0 ? <EmptyState title="No orders yet" detail="New customer orders will appear here." /> : orders.map((order) => (
        <OrderCard key={order.id} order={order} onPress={() => router.push(`/(vendor)/orders/${order.id}`)} />
      ))}
    </Screen>
  );
}