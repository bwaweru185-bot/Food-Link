import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Stack, useLocalSearchParams } from "expo-router";
import { Alert, StyleSheet, Text, View } from "react-native";
import { Screen } from "../../../components/Screen";
import { Button } from "../../../components/Button";
import { LoadingState, ErrorState } from "../../../components/StateView";
import { StatusBadge } from "../../../components/StatusBadge";
import { colors, spacing } from "../../../constants/theme";
import { orderService } from "../../../services/orders";

export default function OrderDetails() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const client = useQueryClient();
  const query = useQuery({ queryKey: ["order", id], queryFn: () => orderService.get(id), enabled: Boolean(id) });
  const action = useMutation({
    mutationFn: async (kind: "accept" | "reject" | "preparing" | "ready") => {
      if (kind === "accept") return orderService.accept(id);
      if (kind === "reject") return orderService.reject(id, "Rejected by vendor");
      if (kind === "preparing") return orderService.startPreparing(id);
      return orderService.ready(id);
    },
    onSuccess: async () => {
      await client.invalidateQueries({ queryKey: ["order", id] });
      await client.invalidateQueries({ queryKey: ["orders"] });
      await client.invalidateQueries({ queryKey: ["dashboard"] });
    },
    onError: (error) => Alert.alert("Action failed", error instanceof Error ? error.message : "Please try again."),
  });

  if (query.isLoading) return <Screen><LoadingState /></Screen>;
  if (query.error || !query.data) return <Screen><ErrorState message={query.error instanceof Error ? query.error.message : "Order not found."} onRetry={() => void query.refetch()} /></Screen>;
  const order = query.data;
  const canAccept = order.status === "new";
  const canPrepare = order.status === "accepted";
  const canReady = order.status === "preparing";
  const terminal = ["rejected", "cancelled", "delivered", "picked_up"].includes(order.status);

  return (
    <Screen>
      <Stack.Screen options={{ title: `Order #${order.orderNumber}` }} />
      <View style={styles.header}><View><Text style={styles.number}>#{order.orderNumber}</Text><Text style={styles.customer}>{order.customerName}</Text></View><StatusBadge status={order.status} /></View>

      {order.customerNote ? <View style={styles.note}><Text style={styles.noteTitle}>Customer note</Text><Text>{order.customerNote}</Text></View> : null}

      <View style={styles.card}>
        {order.items.map((item) => (
          <View key={item.id} style={styles.item}><Text style={styles.itemName}>{item.quantity} × {item.name}</Text><Text>{order.currency} {item.lineTotal.toFixed(2)}</Text>{item.notes ? <Text style={styles.muted}>{item.notes}</Text> : null}</View>
        ))}
        <Line label="Subtotal" value={`${order.currency} ${order.subtotal.toFixed(2)}`} />
        <Line label="Tax" value={`${order.currency} ${order.tax.toFixed(2)}`} />
        <Line label="Delivery" value={`${order.currency} ${order.deliveryFee.toFixed(2)}`} />
        <Line label="Total" value={`${order.currency} ${order.total.toFixed(2)}`} strong />
      </View>

      {!terminal && <View style={{ gap: spacing.sm }}>
        {canAccept ? <Button label="Accept order" onPress={() => action.mutate("accept")} loading={action.isPending} /> : null}
        {canAccept ? <Button label="Reject order" variant="danger" onPress={() => action.mutate("reject")} loading={action.isPending} /> : null}
        {canPrepare ? <Button label="Start preparing" onPress={() => action.mutate("preparing")} loading={action.isPending} /> : null}
        {canReady ? <Button label="Ready for pickup" onPress={() => action.mutate("ready")} loading={action.isPending} /> : null}
      </View>}
      {order.riderName ? <Text style={styles.muted}>Assigned rider: {order.riderName}</Text> : null}
    </Screen>
  );
}
function Line({ label, value, strong = false }: { label: string; value: string; strong?: boolean }) {
  return <View style={styles.line}><Text style={strong ? styles.strong : undefined}>{label}</Text><Text style={strong ? styles.strong : undefined}>{value}</Text></View>;
}
const styles = StyleSheet.create({
  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  number: { fontSize: 24, fontWeight: "900", color: colors.text },
  customer: { color: colors.muted, marginTop: 4 },
  note: { backgroundColor: colors.warningSoft, padding: spacing.md, borderRadius: 12, gap: 5 },
  noteTitle: { fontWeight: "800" },
  card: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 14, padding: spacing.md, gap: 12 },
  item: { paddingBottom: 10, borderBottomWidth: 1, borderBottomColor: colors.border, gap: 4 },
  itemName: { fontWeight: "700" },
  muted: { color: colors.muted },
  line: { flexDirection: "row", justifyContent: "space-between" },
  strong: { fontWeight: "900", fontSize: 17 },
});