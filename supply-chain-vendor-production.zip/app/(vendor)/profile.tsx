import { Alert, StyleSheet, Text } from "react-native";
import { router } from "expo-router";
import { Screen } from "../../components/Screen";
import { Button } from "../../components/Button";
import { colors } from "../../constants/theme";
import { useAuthStore } from "../../store/auth";
import { authService } from "../../services/auth";

export default function Profile() {
  const user = useAuthStore((s) => s.user);
  async function logout() {
    try { await authService.logout(); } catch (error) { Alert.alert("Logout warning", error instanceof Error ? error.message : "Server logout failed."); }
    await useAuthStore.getState().signOut();
    router.replace("/(auth)/login");
  }
  return (
    <Screen>
      <Text style={styles.title}>{user?.name ?? "Vendor user"}</Text>
      <Text style={styles.muted}>{user?.email ?? ""}</Text>
      <Text style={styles.muted}>Role: {user?.role ?? "staff"}</Text>
      <Button label="Sign out" variant="danger" onPress={() => void logout()} />
    </Screen>
  );
}
const styles = StyleSheet.create({
  title: { fontSize: 28, fontWeight: "900", color: colors.text },
  muted: { color: colors.muted },
});