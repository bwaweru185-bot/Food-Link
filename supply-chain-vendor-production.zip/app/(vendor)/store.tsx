import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Alert, StyleSheet, Switch, Text, View } from "react-native";
import { Screen } from "../../components/Screen";
import { Button } from "../../components/Button";
import { LoadingState, ErrorState } from "../../components/StateView";
import { colors, spacing } from "../../constants/theme";
import { storeService } from "../../services/store";

export default function StoreSettings() {
  const client = useQueryClient();
  const store = useQuery({ queryKey: ["store"], queryFn: storeService.get });
  const hours = useQuery({ queryKey: ["store-hours"], queryFn: storeService.getHours });
  const status = useMutation({
    mutationFn: (open: boolean) => storeService.setStatus(open ? "open" : "closed"),
    onSuccess: () => void client.invalidateQueries({ queryKey: ["store"] }),
    onError: (e) => Alert.alert("Unable to update store", e instanceof Error ? e.message : "Please try again."),
  });

  if (store.isLoading || hours.isLoading) return <Screen><LoadingState /></Screen>;
  if (store.error || hours.error || !store.data) return <Screen><ErrorState message="Unable to load store settings." onRetry={() => { void store.refetch(); void hours.refetch(); }} /></Screen>;
  return (
    <Screen>
      <Text style={styles.title}>{store.data.name}</Text>
      <Text style={styles.muted}>{store.data.description}</Text>
      <View style={styles.row}><Text style={styles.label}>Accepting orders</Text><Switch value={store.data.status === "open" && store.data.acceptingOrders} onValueChange={(v) => status.mutate(v)} /></View>
      <Text style={styles.section}>Business hours</Text>
      {(hours.data ?? []).map((day) => (
        <View key={day.weekday} style={styles.hour}><Text>Day {day.weekday + 1}</Text><Text style={styles.muted}>{day.closed ? "Closed" : `${day.open ?? "—"} – ${day.close ?? "—"}`}</Text></View>
      ))}
      <Button label="Refresh store settings" variant="secondary" onPress={() => { void store.refetch(); void hours.refetch(); }} />
    </Screen>
  );
}
const styles = StyleSheet.create({
  title: { fontSize: 28, fontWeight: "900", color: colors.text },
  muted: { color: colors.muted },
  row: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 14, padding: spacing.md, flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  label: { fontWeight: "800" },
  section: { fontSize: 20, fontWeight: "800", marginTop: spacing.md },
  hour: { flexDirection: "row", justifyContent: "space-between", backgroundColor: colors.surface, padding: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.border },
});