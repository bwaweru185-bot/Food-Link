import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { router, Stack } from "expo-router";
import { Alert, StyleSheet, Text, TextInput } from "react-native";
import { useState } from "react";
import { Screen } from "../../../components/Screen";
import { Button } from "../../../components/Button";
import { LoadingState } from "../../../components/StateView";
import { colors, spacing } from "../../../constants/theme";
import { menuService } from "../../../services/menu";

export default function NewMenuItem() {
  const client = useQueryClient();
  const categories = useQuery({ queryKey: ["menu-categories"], queryFn: menuService.categories });
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [categoryId, setCategoryId] = useState("");
  const mutation = useMutation({
    mutationFn: () => menuService.create({ categoryId, name: name.trim(), description: description.trim() || undefined, price: Number(price) }),
    onSuccess: async () => { await client.invalidateQueries({ queryKey: ["menu-items"] }); router.back(); },
    onError: (e) => Alert.alert("Could not create item", e instanceof Error ? e.message : "Please try again."),
  });
  if (categories.isLoading) return <Screen><LoadingState /></Screen>;
  const firstCategory = categories.data?.[0]?.id ?? "";
  const selected = categoryId || firstCategory;
  return (
    <Screen>
      <Stack.Screen options={{ title: "New menu item" }} />
      <TextInput placeholder="Item name" value={name} onChangeText={setName} style={styles.input} />
      <TextInput placeholder="Description" value={description} onChangeText={setDescription} multiline style={[styles.input, styles.area]} />
      <TextInput placeholder="Price" value={price} onChangeText={setPrice} keyboardType="decimal-pad" style={styles.input} />
      <Text style={styles.help}>Category: {selected || "No category configured"}</Text>
      <Button label="Create item" onPress={() => mutation.mutate()} loading={mutation.isPending} disabled={!name.trim() || !selected || !Number.isFinite(Number(price))} />
    </Screen>
  );
}
const styles = StyleSheet.create({
  input: { minHeight: 50, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 12, paddingHorizontal: spacing.md, fontSize: 16 },
  area: { minHeight: 100, paddingTop: spacing.md, textAlignVertical: "top" },
  help: { color: colors.muted },
});