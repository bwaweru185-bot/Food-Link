import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Stack, useLocalSearchParams, router } from "expo-router";
import { Alert, StyleSheet, Text, TextInput } from "react-native";
import { useEffect, useState } from "react";
import { Screen } from "../../../components/Screen";
import { Button } from "../../../components/Button";
import { LoadingState, ErrorState } from "../../../components/StateView";
import { colors, spacing } from "../../../constants/theme";
import { menuService } from "../../../services/menu";

export default function EditMenuItem() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const client = useQueryClient();
  const query = useQuery({ queryKey: ["menu-items"], queryFn: menuService.items });
  const item = query.data?.find((entry) => entry.id === id);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");

  useEffect(() => {
    if (item) { setName(item.name); setDescription(item.description ?? ""); setPrice(String(item.price)); }
  }, [item]);

  const mutation = useMutation({
    mutationFn: () => menuService.update(id, { name: name.trim(), description: description.trim() || undefined, price: Number(price) }),
    onSuccess: async () => { await client.invalidateQueries({ queryKey: ["menu-items"] }); router.back(); },
    onError: (e) => Alert.alert("Could not save", e instanceof Error ? e.message : "Please try again."),
  });

  if (query.isLoading) return <Screen><LoadingState /></Screen>;
  if (query.error || !item) return <Screen><ErrorState message={query.error instanceof Error ? query.error.message : "Menu item not found."} onRetry={() => void query.refetch()} /></Screen>;

  return (
    <Screen>
      <Stack.Screen options={{ title: "Edit menu item" }} />
      <TextInput value={name} onChangeText={setName} style={styles.input} />
      <TextInput value={description} onChangeText={setDescription} multiline style={[styles.input, styles.area]} />
      <TextInput value={price} onChangeText={setPrice} keyboardType="decimal-pad" style={styles.input} />
      <Button label="Save changes" onPress={() => mutation.mutate()} loading={mutation.isPending} disabled={!name.trim() || !Number.isFinite(Number(price))} />
    </Screen>
  );
}
const styles = StyleSheet.create({
  input: { minHeight: 50, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 12, paddingHorizontal: spacing.md, fontSize: 16 },
  area: { minHeight: 110, paddingTop: spacing.md, textAlignVertical: "top" },
});