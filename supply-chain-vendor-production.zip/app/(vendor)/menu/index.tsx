import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { router } from "expo-router";
import { Text, View } from "react-native";
import { Screen } from "../../../components/Screen";
import { MenuItemCard } from "../../../components/MenuItemCard";
import { Button } from "../../../components/Button";
import { EmptyState, ErrorState, LoadingState } from "../../../components/StateView";
import { colors } from "../../../constants/theme";
import { menuService } from "../../../services/menu";

export default function MenuScreen() {
  const client = useQueryClient();
  const items = useQuery({ queryKey: ["menu-items"], queryFn: menuService.items });
  const toggle = useMutation({
    mutationFn: ({ id, available }: { id: string; available: boolean }) => menuService.setAvailability(id, available),
    onSuccess: () => void client.invalidateQueries({ queryKey: ["menu-items"] }),
  });

  if (items.isLoading) return <Screen><LoadingState /></Screen>;
  if (items.error) return <Screen><ErrorState message={items.error instanceof Error ? items.error.message : "Unable to load menu."} onRetry={() => void items.refetch()} /></Screen>;
  return (
    <Screen>
      <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
        <Text style={{ fontSize: 26, fontWeight: "900", color: colors.text }}>Menu</Text>
        <Button label="Add item" onPress={() => router.push("/(vendor)/menu/new")} />
      </View>
      {(items.data ?? []).length === 0 ? <EmptyState title="Your menu is empty" detail="Create the first menu item to start accepting orders." /> : (items.data ?? []).map((item) => (
        <MenuItemCard key={item.id} item={item} onPress={() => router.push(`/(vendor)/menu/${item.id}`)} onToggle={(available) => toggle.mutate({ id: item.id, available })} />
      ))}
    </Screen>
  );
}