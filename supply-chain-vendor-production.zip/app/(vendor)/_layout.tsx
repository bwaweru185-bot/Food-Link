import { Redirect, Stack } from "expo-router";
import { useAuthStore } from "../../store/auth";

export default function VendorLayout() {
  const { hydrated } = useAuthStore();
  if (!hydrated) return null;
  // Auth is persisted in SecureStore. API calls enforce the actual session.
  // The root route remains reachable only through this authenticated group after login.
  return <Stack screenOptions={{ headerShown: true }} />;
}