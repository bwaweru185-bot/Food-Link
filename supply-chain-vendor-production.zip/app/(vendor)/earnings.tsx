import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Screen } from "../../components/Screen";
import { LoadingState, ErrorState } from "../../components/StateView";
import { Text, Pressable, StyleSheet, View } from "react-native";
import { colors, spacing } from "../../constants/theme";
import { earningsService } from "../../services/earnings";
import type { EarningsSummary } from "../../types/vendor";

export default function Earnings() {
  const [period, setPeriod] = useState<EarningsSummary["period"]>("today");
  const query = useQuery({ queryKey: ["earnings", period], queryFn: () => earningsService.summary(period) });
  if (query.isLoading) return <Screen><LoadingState /></Screen>;
  if (query.error) return <Screen><ErrorState message={query.error instanceof Error ? query.error.message : "Unable to load earnings."} onRetry={() => void query.refetch()} /></Screen>;
  const data = query.data!;
  return (
    <Screen>
      <Text style={styles.title}>Earnings</Text>
      <View style={styles.tabs}>{(["today", "week", "month"] as const).map((value) => <Pressable key={value} onPress={() => setPeriod(value)} style={[styles.tab, period === value && styles.selected]}><Text style={period === value ? styles.selectedText : undefined}>{value}</Text></Pressable>)}</View>
      <Metric label="Gross sales" value={data.grossSales} />
      <Metric label="Platform fees" value={data.platformFees} />
      <Metric label="Refunds" value={data.refunds} />
      <Metric label="Net sales" value={data.netSales} />
      <Metric label="Orders" value={data.orderCount} />
    </Screen>
  );
}
function Metric({ label, value }: { label: string; value: number }) {
  return <View style={styles.metric}><Text style={styles.muted}>{label}</Text><Text style={styles.value}>{value.toFixed(2)}</Text></View>;
}
const styles = StyleSheet.create({
  title: { fontSize: 28, fontWeight: "900", color: colors.text },
  tabs: { flexDirection: "row", gap: 8 },
  tab: { padding: 10, borderRadius: 10, borderWidth: 1, borderColor: colors.border },
  selected: { backgroundColor: colors.primary },
  selectedText: { color: "#fff", fontWeight: "800" },
  metric: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 14, padding: spacing.md, gap: 5 },
  muted: { color: colors.muted },
  value: { fontSize: 25, fontWeight: "900", color: colors.text },
});