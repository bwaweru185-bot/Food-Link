import { ActivityIndicator, Pressable, StyleSheet, Text } from "react-native";
import { colors, radius, spacing } from "../constants/theme";

export function Button({
  label, onPress, loading = false, disabled = false, variant = "primary",
}: {
  label: string; onPress: () => void; loading?: boolean; disabled?: boolean;
  variant?: "primary" | "secondary" | "danger";
}) {
  return (
    <Pressable
      accessibilityRole="button"
      disabled={disabled || loading}
      onPress={onPress}
      style={[styles.base, variant === "secondary" && styles.secondary, variant === "danger" && styles.danger, (disabled || loading) && styles.disabled]}
    >
      {loading ? <ActivityIndicator /> : <Text style={styles.text}>{label}</Text>}
    </Pressable>
  );
}
const styles = StyleSheet.create({
  base: { minHeight: 48, borderRadius: radius.md, alignItems: "center", justifyContent: "center", paddingHorizontal: spacing.md, backgroundColor: colors.primary },
  secondary: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border },
  danger: { backgroundColor: colors.danger },
  disabled: { opacity: 0.5 },
  text: { fontSize: 16, fontWeight: "700", color: "#FFFFFF" },
});