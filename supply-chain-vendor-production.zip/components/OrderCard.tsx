import { Pressable, StyleSheet, Text, View } from "react-native";
import { colors, spacing } from "../constants/theme";
import type { VendorOrder } from "../types/order";
import { StatusBadge } from "./StatusBadge";

export function OrderCard({ order, onPress }: { order: VendorOrder; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} style={styles.card}>
      <View style={styles.row}>
        <Text style={styles.number}>#{order.orderNumber}</Text>
        <StatusBadge status={order.status} />
      </View>
      <Text style={styles.customer}>{order.customerName}</Text>
      <Text style={styles.meta}>{order.items.reduce((sum, item) => sum + item.quantity, 0)} items · {order.currency} {order.total.toFixed(2)}</Text>
      <Text style={styles.time}>{new Date(order.placedAt).toLocaleString()}</Text>
    </Pressable>
  );
}
const styles = StyleSheet.create({
  card: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 14, padding: spacing.md, gap: 7 },
  row: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  number: { fontSize: 17, fontWeight: "800", color: colors.text },
  customer: { fontSize: 15, fontWeight: "700", color: colors.text },
  meta: { color: colors.muted },
  time: { fontSize: 12, color: colors.muted },
});