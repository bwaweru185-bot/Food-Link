import { ActivityIndicator, StyleSheet, Text, View } from "react-native";
import { colors, spacing } from "../constants/theme";

export function LoadingState() {
  return <View style={styles.box}><ActivityIndicator /><Text style={styles.text}>Loading…</Text></View>;
}
export function EmptyState({ title, detail }: { title: string; detail?: string }) {
  return <View style={styles.box}><Text style={styles.title}>{title}</Text>{detail ? <Text style={styles.text}>{detail}</Text> : null}</View>;
}
export function ErrorState({ message, onRetry }: { message: string; onRetry: () => void }) {
  return <View style={styles.box}><Text style={styles.title}>Something went wrong</Text><Text style={styles.text}>{message}</Text><Text onPress={onRetry} style={styles.retry}>Try again</Text></View>;
}
const styles = StyleSheet.create({
  box: { padding: spacing.lg, alignItems: "center", gap: spacing.sm },
  title: { fontSize: 17, fontWeight: "800", color: colors.text, textAlign: "center" },
  text: { color: colors.muted, textAlign: "center" },
  retry: { color: colors.primary, fontWeight: "800" },
});