import { Pressable, StyleSheet, Switch, Text, View } from "react-native";
import { colors, spacing } from "../constants/theme";
import type { MenuItem } from "../types/menu";

export function MenuItemCard({ item, onPress, onToggle }: { item: MenuItem; onPress: () => void; onToggle: (available: boolean) => void }) {
  return (
    <Pressable onPress={onPress} style={styles.card}>
      <View style={styles.main}>
        <View style={styles.copy}>
          <Text style={styles.name}>{item.name}</Text>
          {item.description ? <Text style={styles.description}>{item.description}</Text> : null}
          <Text style={styles.price}>{item.currency} {item.price.toFixed(2)}</Text>
        </View>
        <Switch value={item.available} onValueChange={onToggle} />
      </View>
    </Pressable>
  );
}
const styles = StyleSheet.create({
  card: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 14, padding: spacing.md },
  main: { flexDirection: "row", justifyContent: "space-between", gap: spacing.md },
  copy: { flex: 1, gap: 5 },
  name: { fontWeight: "800", fontSize: 16, color: colors.text },
  description: { color: colors.muted },
  price: { fontWeight: "700", color: colors.primary, marginTop: 4 },
});