import { StyleSheet, Text, View } from "react-native";
import { colors } from "../constants/theme";
import type { VendorOrderStatus } from "../types/order";

const labels: Record<VendorOrderStatus, string> = {
  new: "New", accepted: "Accepted", preparing: "Preparing", ready_for_pickup: "Ready",
  picked_up: "Picked up", delivered: "Delivered", rejected: "Rejected", cancelled: "Cancelled",
};

export function StatusBadge({ status }: { status: VendorOrderStatus }) {
  const active = status === "new" || status === "preparing";
  const done = status === "delivered" || status === "picked_up";
  return (
    <View style={[styles.badge, done ? styles.done : active ? styles.active : styles.neutral]}>
      <Text style={styles.text}>{labels[status]}</Text>
    </View>
  );
}
const styles = StyleSheet.create({
  badge: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 999 },
  active: { backgroundColor: colors.warningSoft },
  done: { backgroundColor: colors.successSoft },
  neutral: { backgroundColor: colors.border },
  text: { fontWeight: "700", color: colors.text },
});