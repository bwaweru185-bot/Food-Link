# Order state machine

Customer-facing order lifecycle is shared across customer, vendor and rider apps.

`new -> accepted -> preparing -> ready_for_pickup -> picked_up -> delivered`

Terminal alternatives:

`new -> rejected`
`new|accepted|preparing -> cancelled`

Only the backend may authorize transitions. Mobile actions are commands; they are not authoritative state mutations.

Recommended transition record fields:

- order_id
- from_status
- to_status
- actor_type
- actor_id
- reason
- idempotency_key
- created_at
- request_id
