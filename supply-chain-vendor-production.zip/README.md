# Supply Chain Vendor App

Production-oriented Expo/React Native + TypeScript vendor application foundation for a multi-app food/logistics platform.

## Included

- Expo SDK 57 / React Native 0.86 baseline
- Expo Router file-based navigation
- Strict TypeScript
- TanStack Query for server state
- Zustand for session/store UI state
- SecureStore access/refresh token persistence
- Token refresh handling in the API client
- Vendor login/logout
- Vendor dashboard with server metrics
- Store open/closed control
- Incoming orders with polling
- Server-authoritative order workflow:
  - new -> accepted -> preparing -> ready_for_pickup
  - rejection support
- Menu listing
- Menu item create/edit
- Menu availability control
- Store settings and business hours
- Earnings summary
- Loading/error/empty states
- No fake orders, revenue, customers, or menu records

## Install

Requires Node 22.13+ for the Expo SDK 57 baseline.

```bash
npm install
cp .env.example .env
npm run typecheck
npx expo start
```

Set `EXPO_PUBLIC_API_BASE_URL` to your real API.

## API contract

Auth:
- POST `/v1/auth/vendor/login`
- POST `/v1/auth/vendor/refresh`
- POST `/v1/auth/vendor/logout`

Vendor:
- GET `/v1/vendor/me`
- GET `/v1/vendor/dashboard`
- GET `/v1/vendor/store`
- PATCH `/v1/vendor/store/status`
- GET `/v1/vendor/store/hours`
- PATCH `/v1/vendor/store/hours`

Menu:
- GET `/v1/vendor/menu/categories`
- GET `/v1/vendor/menu/items`
- POST `/v1/vendor/menu/items`
- PATCH `/v1/vendor/menu/items/:id`
- PATCH `/v1/vendor/menu/items/:id/availability`

Orders:
- GET `/v1/vendor/orders`
- GET `/v1/vendor/orders/:id`
- POST `/v1/vendor/orders/:id/accept`
- POST `/v1/vendor/orders/:id/reject`
- POST `/v1/vendor/orders/:id/preparing`
- POST `/v1/vendor/orders/:id/ready-for-pickup`

Earnings:
- GET `/v1/vendor/earnings/summary?period=today|week|month`

## Production backend requirements

The mobile client must not be treated as the source of truth. The backend must enforce:

1. Vendor ownership/role authorization on every vendor endpoint.
2. Valid order-state transitions and idempotency for transition commands.
3. Server-side price/tax/fee calculations.
4. Inventory/menu availability validation at order acceptance.
5. Audit history for order and store state changes.
6. Concurrency control so two staff devices cannot incorrectly transition the same order.
7. Webhooks/event processing for payment and delivery lifecycle changes.
8. Real-time or push notification delivery for new orders and rider assignment.
9. Signed image-upload URLs or a media service for menu photos; never put permanent storage credentials in the app.
10. Pagination/cursors for order and transaction history.
11. Rate limiting, structured errors, request IDs and observability.
12. Automated tests for authorization, transitions, refunds, inventory and payout calculations.

## Important

This repository is a production app foundation, not a claim that the complete business system is production-ready without the backend, database, payments, notifications, media storage, CI/CD, secrets and observability infrastructure.

Do not add fake records to make screens look populated. Integrate the endpoints above with the real backend.

## Suggested next build

Build the shared backend/API and database contract next so the customer, rider and vendor apps use the same order state machine, pricing model, authentication system, inventory model and event/audit stream.
