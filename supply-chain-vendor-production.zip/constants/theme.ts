export const colors = {
  background: "#F7F8FA",
  surface: "#FFFFFF",
  text: "#15171A",
  muted: "#6B7280",
  border: "#E5E7EB",
  primary: "#166534",
  primarySoft: "#DCFCE7",
  danger: "#B91C1C",
  dangerSoft: "#FEE2E2",
  warning: "#A16207",
  warningSoft: "#FEF3C7",
  success: "#15803D",
  successSoft: "#DCFCE7",
} as const;

export const spacing = {
  xs: 6, sm: 10, md: 16, lg: 24, xl: 32,
} as const;

export const radius = {
  sm: 8, md: 12, lg: 18,
} as const;