import { api } from "../lib/api";
import type { VendorOrder, VendorOrderStatus } from "../types/order";

export const orderService = {
  list: (status?: VendorOrderStatus) =>
    api.get<VendorOrder[]>(status ? `/v1/vendor/orders?status=${status}` : "/v1/vendor/orders"),
  get: (id: string) => api.get<VendorOrder>(`/v1/vendor/orders/${id}`),
  accept: (id: string) => api.post<VendorOrder>(`/v1/vendor/orders/${id}/accept`),
  reject: (id: string, reason: string) => api.post<VendorOrder>(`/v1/vendor/orders/${id}/reject`, { reason }),
  startPreparing: (id: string) => api.post<VendorOrder>(`/v1/vendor/orders/${id}/preparing`),
  ready: (id: string) => api.post<VendorOrder>(`/v1/vendor/orders/${id}/ready-for-pickup`),
};