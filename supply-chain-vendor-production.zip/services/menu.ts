import { api } from "../lib/api";
import type { MenuCategory, MenuItem } from "../types/menu";

export const menuService = {
  categories: () => api.get<MenuCategory[]>("/v1/vendor/menu/categories"),
  items: () => api.get<MenuItem[]>("/v1/vendor/menu/items"),
  create: (input: { categoryId: string; name: string; description?: string; price: number }) =>
    api.post<MenuItem>("/v1/vendor/menu/items", input),
  update: (id: string, input: Partial<Pick<MenuItem, "categoryId" | "name" | "description" | "price">>) =>
    api.patch<MenuItem>(`/v1/vendor/menu/items/${id}`, input),
  setAvailability: (id: string, available: boolean) =>
    api.patch<MenuItem>(`/v1/vendor/menu/items/${id}/availability`, { available }),
};