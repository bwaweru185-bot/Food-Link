import { api } from "../lib/api";
import type { BusinessHours, VendorStore } from "../types/vendor";

export const storeService = {
  get: () => api.get<VendorStore>("/v1/vendor/store"),
  setStatus: (status: VendorStore["status"]) =>
    api.patch<VendorStore>("/v1/vendor/store/status", { status }),
  getHours: () => api.get<BusinessHours[]>("/v1/vendor/store/hours"),
  updateHours: (hours: BusinessHours[]) =>
    api.patch<BusinessHours[]>("/v1/vendor/store/hours", { hours }),
};