import { api } from "../lib/api";
import type { Dashboard } from "../types/vendor";

export const dashboardService = {
  get: () => api.get<Dashboard>("/v1/vendor/dashboard"),
};