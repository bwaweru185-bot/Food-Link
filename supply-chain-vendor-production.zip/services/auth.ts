import { api } from "../lib/api";
import type { LoginResponse } from "../types/auth";

export const authService = {
  login: (email: string, password: string) =>
    api.post<LoginResponse>("/v1/auth/vendor/login", { email, password }),
  logout: () => api.post<void>("/v1/auth/vendor/logout"),
};