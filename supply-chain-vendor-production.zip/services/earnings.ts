import { api } from "../lib/api";
import type { EarningsSummary } from "../types/vendor";

export const earningsService = {
  summary: (period: EarningsSummary["period"]) =>
    api.get<EarningsSummary>(`/v1/vendor/earnings/summary?period=${period}`),
};