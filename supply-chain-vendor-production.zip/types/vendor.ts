export type StoreStatus = "open" | "closed";

export type VendorStore = {
  id: string;
  vendorId: string;
  name: string;
  description?: string;
  phone?: string;
  address: string;
  status: StoreStatus;
  acceptingOrders: boolean;
  timezone: string;
};

export type BusinessHours = {
  weekday: number;
  open: string | null;
  close: string | null;
  closed: boolean;
};

export type Dashboard = {
  newOrders: number;
  preparingOrders: number;
  readyOrders: number;
  todayOrders: number;
  todayGross: number;
  pendingPayout: number;
};

export type EarningsSummary = {
  period: "today" | "week" | "month";
  grossSales: number;
  platformFees: number;
  refunds: number;
  netSales: number;
  orderCount: number;
};