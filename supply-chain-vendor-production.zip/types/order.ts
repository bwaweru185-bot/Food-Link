export type VendorOrderStatus =
  | "new"
  | "accepted"
  | "preparing"
  | "ready_for_pickup"
  | "picked_up"
  | "delivered"
  | "rejected"
  | "cancelled";

export type VendorOrderItem = {
  id: string;
  menuItemId: string;
  name: string;
  quantity: number;
  unitPrice: number;
  lineTotal: number;
  notes?: string;
};

export type VendorOrder = {
  id: string;
  orderNumber: string;
  status: VendorOrderStatus;
  customerName: string;
  customerNote?: string;
  items: VendorOrderItem[];
  subtotal: number;
  tax: number;
  deliveryFee: number;
  total: number;
  currency: string;
  placedAt: string;
  acceptedAt?: string;
  readyAt?: string;
  riderName?: string;
};