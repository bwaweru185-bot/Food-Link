export type VendorUser = {
  id: string;
  vendorId: string;
  name: string;
  email: string;
  role: "owner" | "manager" | "staff";
};

export type AuthTokens = {
  accessToken: string;
  refreshToken: string;
  expiresAt: string;
};

export type LoginResponse = {
  user: VendorUser;
  tokens: AuthTokens;
};