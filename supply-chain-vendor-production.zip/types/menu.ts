export type MenuCategory = {
  id: string;
  name: string;
  sortOrder: number;
  active: boolean;
};

export type MenuItem = {
  id: string;
  categoryId: string;
  name: string;
  description?: string;
  price: number;
  currency: string;
  imageUrl?: string;
  available: boolean;
  sortOrder: number;
  updatedAt: string;
};