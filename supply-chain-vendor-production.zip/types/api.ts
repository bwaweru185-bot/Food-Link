export type ApiError = {
  message: string;
  code?: string;
  fieldErrors?: Record<string, string>;
};

export type ApiResponse<T> = {
  data: T;
  requestId?: string;
};