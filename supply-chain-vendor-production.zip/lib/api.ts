import { getTokens, saveTokens, clearTokens } from "./secure-store";

const BASE_URL = process.env.EXPO_PUBLIC_API_BASE_URL ?? "https://api.example.com";

type Json = Record<string, unknown> | unknown[] | string | number | boolean | null;

async function request<T>(path: string, init: RequestInit = {}, retry = true): Promise<T> {
  const tokens = await getTokens();
  const headers = new Headers(init.headers);
  headers.set("Content-Type", "application/json");
  if (tokens?.accessToken) headers.set("Authorization", `Bearer ${tokens.accessToken}`);

  const response = await fetch(`${BASE_URL}${path}`, { ...init, headers });

  if (response.status === 401 && retry && tokens?.refreshToken) {
    const refresh = await fetch(`${BASE_URL}/v1/auth/vendor/refresh`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ refreshToken: tokens.refreshToken }),
    });
    if (refresh.ok) {
      const body = await refresh.json() as { data: { tokens: { accessToken: string; refreshToken: string; expiresAt: string } } };
      await saveTokens(body.data.tokens);
      return request<T>(path, init, false);
    }
    await clearTokens();
  }

  const body = await response.text();
  let parsed: Json = null;
  try { parsed = body ? JSON.parse(body) as Json : null; } catch { /* non-json response */ }

  if (!response.ok) {
    const message =
      typeof parsed === "object" && parsed !== null && "message" in parsed && typeof parsed.message === "string"
        ? parsed.message
        : `Request failed with status ${response.status}`;
    throw new Error(message);
  }

  if (!body) return undefined as T;
  const json = parsed as { data?: T };
  return json && "data" in json ? (json.data as T) : (parsed as T);
}

export const api = {
  get: <T>(path: string) => request<T>(path),
  post: <T>(path: string, body?: unknown) =>
    request<T>(path, { method: "POST", body: JSON.stringify(body ?? {}) }),
  patch: <T>(path: string, body?: unknown) =>
    request<T>(path, { method: "PATCH", body: JSON.stringify(body ?? {}) }),
};