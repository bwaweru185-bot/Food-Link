import * as SecureStore from "expo-secure-store";

const ACCESS = "vendor.accessToken";
const REFRESH = "vendor.refreshToken";
const EXPIRES = "vendor.expiresAt";

export async function saveTokens(input: {
  accessToken: string;
  refreshToken: string;
  expiresAt: string;
}) {
  await Promise.all([
    SecureStore.setItemAsync(ACCESS, input.accessToken),
    SecureStore.setItemAsync(REFRESH, input.refreshToken),
    SecureStore.setItemAsync(EXPIRES, input.expiresAt),
  ]);
}

export async function getTokens() {
  const [accessToken, refreshToken, expiresAt] = await Promise.all([
    SecureStore.getItemAsync(ACCESS),
    SecureStore.getItemAsync(REFRESH),
    SecureStore.getItemAsync(EXPIRES),
  ]);
  if (!accessToken || !refreshToken || !expiresAt) return null;
  return { accessToken, refreshToken, expiresAt };
}

export async function clearTokens() {
  await Promise.all([
    SecureStore.deleteItemAsync(ACCESS),
    SecureStore.deleteItemAsync(REFRESH),
    SecureStore.deleteItemAsync(EXPIRES),
  ]);
}