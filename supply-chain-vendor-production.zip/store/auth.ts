import { create } from "zustand";
import { clearTokens, getTokens, saveTokens } from "../lib/secure-store";
import type { VendorUser, AuthTokens } from "../types/auth";

type AuthState = {
  user: VendorUser | null;
  hydrated: boolean;
  setSession: (user: VendorUser, tokens: AuthTokens) => Promise<void>;
  hydrate: () => Promise<void>;
  signOut: () => Promise<void>;
};

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  hydrated: false,
  setSession: async (user, tokens) => {
    await saveTokens(tokens);
    set({ user, hydrated: true });
  },
  hydrate: async () => {
    const tokens = await getTokens();
    set({ hydrated: true, user: tokens ? undefined : null });
  },
  signOut: async () => {
    await clearTokens();
    set({ user: null, hydrated: true });
  },
}));