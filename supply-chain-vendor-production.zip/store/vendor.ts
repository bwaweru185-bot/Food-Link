import { create } from "zustand";
import type { VendorStore } from "../types/vendor";

type VendorState = {
  store: VendorStore | null;
  setStore: (store: VendorStore) => void;
  clearStore: () => void;
};

export const useVendorStore = create<VendorState>((set) => ({
  store: null,
  setStore: (store) => set({ store }),
  clearStore: () => set({ store: null }),
}));