export type AdminUser = {
  id: string;
  name: string;
  email: string;
  role: "super_admin" | "operations_admin" | "finance_admin" | "support";
};

export type AuthTokens = {
  accessToken: string;
  refreshToken: string;
  expiresAt: string;
};

export type StoreStatus = "open" | "closed" | "suspended";

export type Vendor = {
  id: string;
  businessName: string;
  ownerName: string;
  email: string;
  phone: string;
  status: "pending" | "active" | "suspended" | "rejected";
  storeStatus: StoreStatus;
  createdAt: string;
};

export type Rider = {
  id: string;
  name: string;
  phone: string;
  status: "pending" | "active" | "suspended";
  availability: "online" | "offline";
  vehicleType: string;
  createdAt: string;
};

export type Customer = {
  id: string;
  name: string;
  email: string;
  phone?: string;
  status: "active" | "blocked";
  createdAt: string;
};

export type OrderStatus =
  | "new"
  | "accepted"
  | "preparing"
  | "ready_for_pickup"
  | "assigned"
  | "picked_up"
  | "delivered"
  | "rejected"
  | "cancelled";

export type Order = {
  id: string;
  orderNumber: string;
  customerName: string;
  vendorName: string;
  riderName?: string;
  status: OrderStatus;
  total: number;
  currency: string;
  placedAt: string;
  updatedAt: string;
};

export type Dashboard = {
  ordersToday: number;
  activeOrders: number;
  activeVendors: number;
  activeRiders: number;
  grossSalesToday: number;
  pendingPayouts: number;
  cancellationsToday: number;
};

export type AuditEvent = {
  id: string;
  actorName: string;
  actorRole: string;
  action: string;
  resourceType: string;
  resourceId: string;
  createdAt: string;
};

export type Payout = {
  id: string;
  vendorName: string;
  amount: number;
  currency: string;
  status: "pending" | "processing" | "paid" | "failed";
  scheduledAt: string;
};