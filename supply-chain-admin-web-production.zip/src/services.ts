import { api } from "./lib/api";
import type { AdminUser, AuditEvent, Customer, Dashboard, Order, Payout, Rider, Vendor } from "./types";

export const authService = {
  login: (email: string, password: string) =>
    api.post<{ user: AdminUser; tokens: { accessToken: string; refreshToken: string } }>("/v1/auth/admin/login", { email, password }),
  logout: () => api.post<void>("/v1/auth/admin/logout"),
};

export const dashboardService = {
  get: () => api.get<Dashboard>("/v1/admin/dashboard"),
};

export const orderService = {
  list: (status?: string) => api.get<Order[]>(status ? `/v1/admin/orders?status=${status}` : "/v1/admin/orders"),
  assignRider: (orderId: string, riderId: string) => api.post<Order>(`/v1/admin/orders/${orderId}/assign-rider`, { riderId }),
  cancel: (orderId: string, reason: string) => api.post<Order>(`/v1/admin/orders/${orderId}/cancel`, { reason }),
};

export const vendorService = {
  list: () => api.get<Vendor[]>("/v1/admin/vendors"),
  approve: (id: string) => api.post<Vendor>(`/v1/admin/vendors/${id}/approve`),
  suspend: (id: string, reason: string) => api.post<Vendor>(`/v1/admin/vendors/${id}/suspend`, { reason }),
};

export const riderService = {
  list: () => api.get<Rider[]>("/v1/admin/riders"),
  approve: (id: string) => api.post<Rider>(`/v1/admin/riders/${id}/approve`),
  suspend: (id: string, reason: string) => api.post<Rider>(`/v1/admin/riders/${id}/suspend`, { reason }),
};

export const customerService = {
  list: () => api.get<Customer[]>("/v1/admin/customers"),
  block: (id: string, reason: string) => api.post<Customer>(`/v1/admin/customers/${id}/block`, { reason }),
  unblock: (id: string) => api.post<Customer>(`/v1/admin/customers/${id}/unblock`),
};

export const payoutService = {
  list: () => api.get<Payout[]>("/v1/admin/payouts"),
  process: (id: string) => api.post<Payout>(`/v1/admin/payouts/${id}/process`),
};

export const auditService = {
  list: () => api.get<AuditEvent[]>("/v1/admin/audit-events"),
};