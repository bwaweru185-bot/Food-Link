import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Store, Check, Ban } from "lucide-react";
import { vendorService } from "../services";
import { Badge, Empty, ErrorState, Loading } from "../components/UI";
import type { Vendor } from "../types";

export function Vendors() {
  const client = useQueryClient();
  const query = useQuery({ queryKey: ["vendors"], queryFn: vendorService.list });
  const approve = useMutation({ mutationFn: vendorService.approve, onSuccess: () => void client.invalidateQueries({ queryKey: ["vendors"] }) });
  const suspend = useMutation({ mutationFn: (id: string) => vendorService.suspend(id, "Suspended by operations admin"), onSuccess: () => void client.invalidateQueries({ queryKey: ["vendors"] }) });
  if (query.isLoading) return <Loading />;
  if (query.error) return <ErrorState message="Unable to load vendors." retry={() => void query.refetch()} />;
  const rows = query.data ?? [];
  return <div className="stack"><div className="page-head"><div><h2>Vendors</h2><p>Approve, monitor and protect the marketplace.</p></div><div className="metric-chip"><Store size={17} /> {rows.filter(v => v.status === "active").length} active</div></div><div className="panel table-wrap">{rows.length === 0 ? <Empty /> : <table><thead><tr><th>Business</th><th>Owner</th><th>Contact</th><th>Status</th><th>Store</th><th>Actions</th></tr></thead><tbody>{rows.map((v: Vendor) => <tr key={v.id}><td><strong>{v.businessName}</strong><small>{new Date(v.createdAt).toLocaleDateString()}</small></td><td>{v.ownerName}</td><td>{v.email}<small>{v.phone}</small></td><td><Badge tone={v.status === "active" ? "green" : v.status === "pending" ? "yellow" : "red"}>{v.status}</Badge></td><td><Badge tone={v.storeStatus === "open" ? "green" : v.storeStatus === "suspended" ? "red" : "neutral"}>{v.storeStatus}</Badge></td><td><div className="row-actions">{v.status === "pending" ? <button className="button small" onClick={() => approve.mutate(v.id)}><Check size={15}/>Approve</button> : null}{v.status === "active" ? <button className="button small danger-outline" onClick={() => { if (confirm("Suspend this vendor?")) suspend.mutate(v.id); }}><Ban size={15}/>Suspend</button> : null}</div></td></tr>)}</tbody></table>}</div></div>;
}