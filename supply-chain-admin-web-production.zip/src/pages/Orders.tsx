import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Bike, Ban } from "lucide-react";
import { orderService, riderService } from "../services";
import { Badge, Empty, ErrorState, Loading, SearchBox } from "../components/UI";
import type { Order, OrderStatus, Rider } from "../types";

const tone: Record<OrderStatus, "green" | "yellow" | "red" | "blue" | "neutral"> = { new: "blue", accepted: "yellow", preparing: "yellow", ready_for_pickup: "yellow", assigned: "blue", picked_up: "blue", delivered: "green", rejected: "red", cancelled: "red" };

export function Orders() {
  const client = useQueryClient();
  const [search, setSearch] = useState("");
  const orders = useQuery({ queryKey: ["orders"], queryFn: () => orderService.list(), refetchInterval: 10_000 });
  const riders = useQuery({ queryKey: ["riders"], queryFn: riderService.list });
  const assign = useMutation({ mutationFn: ({ orderId, riderId }: { orderId: string; riderId: string }) => orderService.assignRider(orderId, riderId), onSuccess: () => void client.invalidateQueries({ queryKey: ["orders"] }) });
  const cancel = useMutation({ mutationFn: (id: string) => orderService.cancel(id, "Cancelled by operations admin"), onSuccess: () => void client.invalidateQueries({ queryKey: ["orders"] }) });
  if (orders.isLoading || riders.isLoading) return <Loading />;
  if (orders.error || riders.error) return <ErrorState message="Unable to load order operations." retry={() => { void orders.refetch(); void riders.refetch(); }} />;
  const rows = (orders.data ?? []).filter((o) => `${o.orderNumber} ${o.customerName} ${o.vendorName}`.toLowerCase().includes(search.toLowerCase()));
  const activeRiders = (riders.data ?? []).filter((r: Rider) => r.status === "active" && r.availability === "online");
  return <div className="stack"><div className="page-head"><div><h2>Orders</h2><p>Monitor and intervene in the delivery lifecycle.</p></div><SearchBox value={search} onChange={setSearch} placeholder="Order, customer or vendor" /></div><div className="panel table-wrap">{rows.length === 0 ? <Empty /> : <table><thead><tr><th>Order</th><th>Customer</th><th>Vendor</th><th>Status</th><th>Total</th><th>Rider</th><th>Actions</th></tr></thead><tbody>{rows.map((o: Order) => <tr key={o.id}><td><strong>#{o.orderNumber}</strong><small>{new Date(o.placedAt).toLocaleString()}</small></td><td>{o.customerName}</td><td>{o.vendorName}</td><td><Badge tone={tone[o.status]}>{o.status.replaceAll("_", " ")}</Badge></td><td>{o.currency} {o.total.toFixed(2)}</td><td>{o.riderName ?? "Unassigned"}</td><td><div className="row-actions"><select defaultValue="" onChange={(e) => { if (e.target.value) assign.mutate({ orderId: o.id, riderId: e.target.value }); }} disabled={o.status === "delivered" || o.status === "cancelled"}><option value="">Assign rider</option>{activeRiders.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}</select>{!["delivered", "cancelled", "rejected"].includes(o.status) ? <button className="icon-btn danger" title="Cancel order" onClick={() => { if (confirm("Cancel this order?")) cancel.mutate(o.id); }}><Ban size={16} /></button> : null}</div></td></tr>)}</tbody></table>}</div><div className="hint"><Bike size={16} /> Rider assignment is server-authorized and should be audited.</div></div>;
}