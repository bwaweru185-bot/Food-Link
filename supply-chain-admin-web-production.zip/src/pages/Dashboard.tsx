import { useQuery } from "@tanstack/react-query";
import { Bike, CircleDollarSign, ShoppingBag, Store, Users } from "lucide-react";
import { dashboardService } from "../services";
import { ErrorState, Loading, Stat } from "../components/UI";
import "./dashboard.css";

export function Dashboard() {
  const query = useQuery({ queryKey: ["dashboard"], queryFn: dashboardService.get, refetchInterval: 15_000 });
  if (query.isLoading) return <Loading />;
  if (query.error || !query.data) return <ErrorState message={query.error instanceof Error ? query.error.message : "Unable to load dashboard."} retry={() => void query.refetch()} />;
  const d = query.data;
  return <div className="stack"><div className="welcome"><div><h2>Good to see you.</h2><p>Monitor orders, partners, riders and cash flow from one place.</p></div><span className="live"><span className="dot" /> Live data</span></div><div className="stats"><Stat label="Orders today" value={d.ordersToday} detail={`${d.activeOrders} currently active`} icon={<ShoppingBag />} /><Stat label="Active vendors" value={d.activeVendors} icon={<Store />} /><Stat label="Active riders" value={d.activeRiders} icon={<Bike />} /><Stat label="Customers" value="—" detail="Open Customers for live count" icon={<Users />} /><Stat label="Gross sales today" value={d.grossSalesToday.toFixed(2)} detail="Server-reported total" icon={<CircleDollarSign />} /></div><div className="panel"><div className="panel-title"><div><h3>Operational health</h3><p>Critical indicators from the backend.</p></div></div><div className="health"><div><span className="health-label">Active orders</span><strong>{d.activeOrders}</strong></div><div><span className="health-label">Cancellations today</span><strong>{d.cancellationsToday}</strong></div><div><span className="health-label">Pending payouts</span><strong>{d.pendingPayouts.toFixed(2)}</strong></div></div></div></div>;
}