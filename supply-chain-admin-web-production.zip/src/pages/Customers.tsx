import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Ban, CheckCircle2 } from "lucide-react";
import { customerService } from "../services";
import { Badge, Empty, ErrorState, Loading, SearchBox } from "../components/UI";
import type { Customer } from "../types";

export function Customers() {
  const client = useQueryClient(); const [search, setSearch] = useState("");
  const query = useQuery({ queryKey: ["customers"], queryFn: customerService.list });
  const block = useMutation({ mutationFn: (id: string) => customerService.block(id, "Blocked by support admin"), onSuccess: () => void client.invalidateQueries({ queryKey: ["customers"] }) });
  const unblock = useMutation({ mutationFn: customerService.unblock, onSuccess: () => void client.invalidateQueries({ queryKey: ["customers"] }) });
  if (query.isLoading) return <Loading />; if (query.error) return <ErrorState message="Unable to load customers." retry={() => void query.refetch()} />;
  const rows = (query.data ?? []).filter(c => `${c.name} ${c.email} ${c.phone ?? ""}`.toLowerCase().includes(search.toLowerCase()));
  return <div className="stack"><div className="page-head"><div><h2>Customers</h2><p>Account support and customer access controls.</p></div><SearchBox value={search} onChange={setSearch} placeholder="Search customers" /></div><div className="panel table-wrap">{rows.length === 0 ? <Empty /> : <table><thead><tr><th>Customer</th><th>Contact</th><th>Status</th><th>Joined</th><th>Actions</th></tr></thead><tbody>{rows.map((c: Customer) => <tr key={c.id}><td><strong>{c.name}</strong></td><td>{c.email}<small>{c.phone ?? "—"}</small></td><td><Badge tone={c.status === "active" ? "green" : "red"}>{c.status}</Badge></td><td>{new Date(c.createdAt).toLocaleDateString()}</td><td>{c.status === "active" ? <button className="button small danger-outline" onClick={() => { if (confirm("Block this customer?")) block.mutate(c.id); }}><Ban size={15}/>Block</button> : <button className="button small" onClick={() => unblock.mutate(c.id)}><CheckCircle2 size={15}/>Unblock</button>}</td></tr>)}</tbody></table>}</div></div>;
}