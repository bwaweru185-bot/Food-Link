import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Bike, Check, Ban } from "lucide-react";
import { riderService } from "../services";
import { Badge, Empty, ErrorState, Loading, SearchBox } from "../components/UI";
import type { Rider } from "../types";

export function Riders() {
  const client = useQueryClient(); const [search, setSearch] = useState("");
  const query = useQuery({ queryKey: ["riders"], queryFn: riderService.list, refetchInterval: 15_000 });
  const approve = useMutation({ mutationFn: riderService.approve, onSuccess: () => void client.invalidateQueries({ queryKey: ["riders"] }) });
  const suspend = useMutation({ mutationFn: (id: string) => riderService.suspend(id, "Suspended by operations admin"), onSuccess: () => void client.invalidateQueries({ queryKey: ["riders"] }) });
  if (query.isLoading) return <Loading />; if (query.error) return <ErrorState message="Unable to load riders." retry={() => void query.refetch()} />;
  const rows = (query.data ?? []).filter(r => `${r.name} ${r.phone} ${r.vehicleType}`.toLowerCase().includes(search.toLowerCase()));
  return <div className="stack"><div className="page-head"><div><h2>Riders</h2><p>Manage courier onboarding and live availability.</p></div><SearchBox value={search} onChange={setSearch} placeholder="Search riders" /></div><div className="panel table-wrap">{rows.length === 0 ? <Empty /> : <table><thead><tr><th>Rider</th><th>Phone</th><th>Status</th><th>Availability</th><th>Vehicle</th><th>Actions</th></tr></thead><tbody>{rows.map((r: Rider) => <tr key={r.id}><td><strong>{r.name}</strong><small>{new Date(r.createdAt).toLocaleDateString()}</small></td><td>{r.phone}</td><td><Badge tone={r.status === "active" ? "green" : r.status === "pending" ? "yellow" : "red"}>{r.status}</Badge></td><td><Badge tone={r.availability === "online" ? "green" : "neutral"}>{r.availability}</Badge></td><td>{r.vehicleType}</td><td><div className="row-actions">{r.status === "pending" ? <button className="button small" onClick={() => approve.mutate(r.id)}><Check size={15}/>Approve</button> : null}{r.status === "active" ? <button className="button small danger-outline" onClick={() => { if (confirm("Suspend this rider?")) suspend.mutate(r.id); }}><Ban size={15}/>Suspend</button> : null}</div></td></tr>)}</tbody></table>}</div><div className="hint"><Bike size={16}/> Availability is supplied by the rider app and should not be manually spoofed from this UI.</div></div>;
}