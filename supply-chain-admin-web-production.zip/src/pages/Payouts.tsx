import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { DollarSign, Play } from "lucide-react";
import { payoutService } from "../services";
import { Badge, Empty, ErrorState, Loading } from "../components/UI";
import type { Payout } from "../types";

export function Payouts() {
  const client = useQueryClient(); const query = useQuery({ queryKey: ["payouts"], queryFn: payoutService.list });
  const process = useMutation({ mutationFn: payoutService.process, onSuccess: () => void client.invalidateQueries({ queryKey: ["payouts"] }) });
  if (query.isLoading) return <Loading />; if (query.error) return <ErrorState message="Unable to load payouts." retry={() => void query.refetch()} />;
  const rows = query.data ?? [];
  return <div className="stack"><div className="page-head"><div><h2>Payouts</h2><p>Review vendor settlements and payout execution.</p></div><div className="metric-chip"><DollarSign size={17}/> Server-controlled</div></div><div className="panel table-wrap">{rows.length === 0 ? <Empty title="No payouts" /> : <table><thead><tr><th>Vendor</th><th>Amount</th><th>Status</th><th>Scheduled</th><th>Action</th></tr></thead><tbody>{rows.map((p: Payout) => <tr key={p.id}><td><strong>{p.vendorName}</strong></td><td>{p.currency} {p.amount.toFixed(2)}</td><td><Badge tone={p.status === "paid" ? "green" : p.status === "failed" ? "red" : "yellow"}>{p.status}</Badge></td><td>{new Date(p.scheduledAt).toLocaleString()}</td><td>{["pending", "failed"].includes(p.status) ? <button className="button small" onClick={() => process.mutate(p.id)}><Play size={15}/>Process</button> : "—"}</td></tr>)}</tbody></table>}</div></div>;
}