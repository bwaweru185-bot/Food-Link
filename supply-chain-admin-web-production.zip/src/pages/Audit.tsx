import { useQuery } from "@tanstack/react-query";
import { ShieldCheck } from "lucide-react";
import { auditService } from "../services";
import { Empty, ErrorState, Loading } from "../components/UI";
import type { AuditEvent } from "../types";

export function Audit() {
  const query = useQuery({ queryKey: ["audit"], queryFn: auditService.list });
  if (query.isLoading) return <Loading />; if (query.error) return <ErrorState message="Unable to load audit events." retry={() => void query.refetch()} />;
  const rows = query.data ?? [];
  return <div className="stack"><div className="page-head"><div><h2>Audit log</h2><p>Immutable operational activity should be visible here.</p></div><ShieldCheck size={25}/></div><div className="panel table-wrap">{rows.length === 0 ? <Empty title="No audit events" detail="Events will appear once the backend records operational actions." /> : <table><thead><tr><th>Actor</th><th>Action</th><th>Resource</th><th>Time</th></tr></thead><tbody>{rows.map((e: AuditEvent) => <tr key={e.id}><td><strong>{e.actorName}</strong><small>{e.actorRole}</small></td><td>{e.action}</td><td>{e.resourceType} · {e.resourceId}</td><td>{new Date(e.createdAt).toLocaleString()}</td></tr>)}</tbody></table>}</div></div>;
}