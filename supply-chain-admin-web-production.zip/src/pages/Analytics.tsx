import { BarChart3 } from "lucide-react";
import { Empty } from "../components/UI";

export function Analytics() {
  return <div className="stack"><div className="page-head"><div><h2>Analytics</h2><p>Reserved for server-backed operational and financial reporting.</p></div><BarChart3 size={25}/></div><div className="panel"><Empty title="Analytics endpoint not connected" detail="Connect your reporting/warehouse API here rather than shipping fabricated metrics." /></div></div>;
}