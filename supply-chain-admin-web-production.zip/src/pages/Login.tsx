import { FormEvent, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ShieldCheck } from "lucide-react";
import { authService } from "../services";
import { useAuthStore } from "../store/auth";
import "./auth.css";

export function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  async function submit(e: FormEvent) {
    e.preventDefault(); setError(""); setBusy(true);
    try {
      const result = await authService.login(email.trim().toLowerCase(), password);
      useAuthStore.getState().setSession(result.user, result.tokens);
      navigate("/", { replace: true });
    } catch (err) { setError(err instanceof Error ? err.message : "Unable to sign in."); }
    finally { setBusy(false); }
  }

  return <div className="login-page"><div className="login-card"><div className="login-logo"><ShieldCheck size={30} /></div><h1>Admin Console</h1><p>Secure operations management for the supply-chain platform.</p><form onSubmit={(e) => void submit(e)}><label>Email<input value={email} onChange={(e) => setEmail(e.target.value)} type="email" autoComplete="username" required /></label><label>Password<input value={password} onChange={(e) => setPassword(e.target.value)} type="password" autoComplete="current-password" required /></label>{error ? <div className="form-error">{error}</div> : null}<button className="button primary full" disabled={busy}>{busy ? "Signing in…" : "Sign in"}</button></form><small>Use your provisioned admin account. No demo credentials are included.</small></div></div>;
}