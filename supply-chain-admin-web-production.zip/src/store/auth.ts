import { create } from "zustand";
import { clearAuthTokens, setAuthTokens } from "../lib/api";
import type { AdminUser } from "../types";

type AuthState = {
  user: AdminUser | null;
  setSession: (user: AdminUser, tokens: { accessToken: string; refreshToken: string }) => void;
  signOut: () => void;
};

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  setSession: (user, tokens) => {
    setAuthTokens(tokens);
    set({ user });
  },
  signOut: () => {
    clearAuthTokens();
    set({ user: null });
  },
}));