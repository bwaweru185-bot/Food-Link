import type { ReactNode } from "react";
import { AlertCircle, CheckCircle2, LoaderCircle, Search } from "lucide-react";

export function Loading() { return <div className="state"><LoaderCircle className="spin" /><span>Loading…</span></div>; }
export function ErrorState({ message, retry }: { message: string; retry: () => void }) { return <div className="state"><AlertCircle /><strong>{message}</strong><button className="button secondary" onClick={retry}>Retry</button></div>; }
export function Empty({ title = "No records found", detail = "There is nothing to show here yet." }) { return <div className="empty"><strong>{title}</strong><span>{detail}</span></div>; }
export function SearchBox({ value, onChange, placeholder = "Search…" }: { value: string; onChange: (v: string) => void; placeholder?: string }) { return <label className="search"><Search size={17} /><input value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} /></label>; }
export function Badge({ children, tone = "neutral" }: { children: ReactNode; tone?: "green" | "yellow" | "red" | "blue" | "neutral" }) { return <span className={`badge ${tone}`}>{children}</span>; }
export function Stat({ label, value, detail, icon }: { label: string; value: string | number; detail?: string; icon: ReactNode }) { return <div className="stat"><div className="stat-top"><span>{label}</span><div className="stat-icon">{icon}</div></div><strong>{value}</strong>{detail ? <small>{detail}</small> : null}</div>; }
export function Success({ children }: { children: ReactNode }) { return <span className="success"><CheckCircle2 size={15} />{children}</span>; }