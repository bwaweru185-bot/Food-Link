import { NavLink, Outlet } from "react-router-dom";
import { Activity, BarChart3, Bike, ClipboardList, DollarSign, LayoutDashboard, LogOut, Store, Users } from "lucide-react";
import { useAuthStore } from "../store/auth";
import { authService } from "../services";
import "./layout.css";

const nav = [
  ["/", "Dashboard", LayoutDashboard],
  ["/orders", "Orders", ClipboardList],
  ["/vendors", "Vendors", Store],
  ["/riders", "Riders", Bike],
  ["/customers", "Customers", Users],
  ["/payouts", "Payouts", DollarSign],
  ["/audit", "Audit log", Activity],
  ["/analytics", "Analytics", BarChart3],
] as const;

export function Layout() {
  const user = useAuthStore((s) => s.user);
  async function logout() {
    try { await authService.logout(); } finally { useAuthStore.getState().signOut(); }
  }

  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="brand"><div className="brand-mark">SC</div><div><strong>SupplyChain</strong><span>Admin Console</span></div></div>
        <nav>
          {nav.map(([to, label, Icon]) => <NavLink key={to} to={to} end={to === "/"} className={({ isActive }) => isActive ? "nav active" : "nav"}><Icon size={18} /><span>{label}</span></NavLink>)}
        </nav>
        <div className="sidebar-bottom"><div className="user-mini"><div className="avatar">{user?.name.slice(0, 1).toUpperCase() ?? "A"}</div><div><strong>{user?.name ?? "Admin"}</strong><span>{user?.role ?? "admin"}</span></div></div><button className="icon-btn" onClick={() => void logout()} title="Sign out"><LogOut size={18} /></button></div>
      </aside>
      <main className="main"><header className="topbar"><div><span className="eyebrow">OPERATIONS</span><h1>Control Center</h1></div><div className="live"><span className="dot" /> System connected</div></header><section className="page"><Outlet /></section></main>
    </div>
  );
}