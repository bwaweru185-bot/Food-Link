const BASE_URL = import.meta.env.VITE_API_BASE_URL ?? "https://api.example.com";

let accessToken: string | null = null;
let refreshToken: string | null = null;

export function setAuthTokens(tokens: { accessToken: string; refreshToken: string }) {
  accessToken = tokens.accessToken;
  refreshToken = tokens.refreshToken;
}

export function clearAuthTokens() {
  accessToken = null;
  refreshToken = null;
}

async function request<T>(path: string, init: RequestInit = {}, retry = true): Promise<T> {
  const headers = new Headers(init.headers);
  headers.set("Content-Type", "application/json");
  if (accessToken) headers.set("Authorization", `Bearer ${accessToken}`);

  const response = await fetch(`${BASE_URL}${path}`, { ...init, headers });

  if (response.status === 401 && retry && refreshToken) {
    const refresh = await fetch(`${BASE_URL}/v1/auth/admin/refresh`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ refreshToken }),
    });
    if (refresh.ok) {
      const body = await refresh.json() as { data: { tokens: { accessToken: string; refreshToken: string } } };
      setAuthTokens(body.data.tokens);
      return request<T>(path, init, false);
    }
    clearAuthTokens();
  }

  const text = await response.text();
  let body: unknown = null;
  try { body = text ? JSON.parse(text) : null; } catch { /* non-json */ }

  if (!response.ok) {
    const message = typeof body === "object" && body !== null && "message" in body && typeof body.message === "string"
      ? body.message : `Request failed with status ${response.status}`;
    throw new Error(message);
  }

  if (!text) return undefined as T;
  if (typeof body === "object" && body !== null && "data" in body) {
    return (body as { data: T }).data;
  }
  return body as T;
}

export const api = {
  get: <T>(path: string) => request<T>(path),
  post: <T>(path: string, body?: unknown) => request<T>(path, { method: "POST", body: JSON.stringify(body ?? {}) }),
  patch: <T>(path: string, body?: unknown) => request<T>(path, { method: "PATCH", body: JSON.stringify(body ?? {}) }),
};