import { Navigate, Route, Routes } from "react-router-dom";
import { Layout } from "./components/Layout";
import { Login } from "./pages/Login";
import { Dashboard } from "./pages/Dashboard";
import { Orders } from "./pages/Orders";
import { Vendors } from "./pages/Vendors";
import { Riders } from "./pages/Riders";
import { Customers } from "./pages/Customers";
import { Payouts } from "./pages/Payouts";
import { Audit } from "./pages/Audit";
import { Analytics } from "./pages/Analytics";
import { useAuthStore } from "./store/auth";

function Protected() {
  const user = useAuthStore((s) => s.user);
  return user ? <Layout /> : <Navigate to="/login" replace />;
}

export default function App() {
  return <Routes><Route path="/login" element={<Login />} /><Route element={<Protected />}><Route element={<Layout />}><Route index element={<Dashboard />} /><Route path="orders" element={<Orders />} /><Route path="vendors" element={<Vendors />} /><Route path="riders" element={<Riders />} /><Route path="customers" element={<Customers />} /><Route path="payouts" element={<Payouts />} /><Route path="audit" element={<Audit />} /><Route path="analytics" element={<Analytics />} /></Route></Route><Route path="*" element={<Navigate to="/" replace />} /></Routes>;
}