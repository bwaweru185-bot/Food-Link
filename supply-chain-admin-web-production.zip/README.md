# Supply Chain Admin Web

Production-oriented operations console for the food/logistics supply-chain platform.

## Stack

- React 19
- TypeScript strict mode
- Vite
- React Router
- TanStack Query
- Zustand
- Lucide icons

## Modules included

- Secure admin login/logout
- Dashboard / operational KPIs
- Orders monitoring
- Rider assignment
- Order cancellation command
- Vendor approval/suspension
- Rider approval/suspension
- Customer block/unblock
- Payout review/process command
- Immutable audit-log viewer
- Analytics integration placeholder without fake data
- Search/filter-ready operational tables
- Server polling for operational data
- Responsive desktop/tablet/mobile layout

## API contract

Auth:
- POST `/v1/auth/admin/login`
- POST `/v1/auth/admin/refresh`
- POST `/v1/auth/admin/logout`

Dashboard:
- GET `/v1/admin/dashboard`

Orders:
- GET `/v1/admin/orders`
- POST `/v1/admin/orders/:id/assign-rider`
- POST `/v1/admin/orders/:id/cancel`

Vendors:
- GET `/v1/admin/vendors`
- POST `/v1/admin/vendors/:id/approve`
- POST `/v1/admin/vendors/:id/suspend`

Riders:
- GET `/v1/admin/riders`
- POST `/v1/admin/riders/:id/approve`
- POST `/v1/admin/riders/:id/suspend`

Customers:
- GET `/v1/admin/customers`
- POST `/v1/admin/customers/:id/block`
- POST `/v1/admin/customers/:id/unblock`

Payouts:
- GET `/v1/admin/payouts`
- POST `/v1/admin/payouts/:id/process`

Audit:
- GET `/v1/admin/audit-events`

## Run

Node 22+ recommended.

```bash
npm install
cp .env.example .env
npm run typecheck
npm run build
npm run dev
```

Set `VITE_API_BASE_URL` to the actual API.

## Production security requirements

- Enforce RBAC on every endpoint; never trust hidden UI controls.
- Prefer httpOnly secure cookies for browser sessions in the final deployment if compatible with the backend architecture. Do not put long-lived admin secrets in localStorage.
- Require MFA for privileged roles.
- Add CSRF protection when cookie authentication is used.
- Record every administrative mutation in an append-only audit stream.
- Require idempotency keys for payout and order mutation commands.
- Enforce server-side order-state transitions and vendor/rider ownership.
- Protect payout processing with approval rules and reconciliation.
- Add pagination/cursors for large tables.
- Add server-side filtering rather than loading unbounded datasets.
- Add request IDs, structured errors, rate limiting and observability.
- Add automated authorization, workflow and financial tests before production rollout.

## Important

This is the production-oriented admin frontend foundation. It does not pretend that a frontend alone provides production security or business correctness. The API, identity provider, database, payments, audit infrastructure, CI/CD, secrets and observability must be connected and hardened before launch.
