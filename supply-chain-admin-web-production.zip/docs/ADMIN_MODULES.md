# Admin modules

## Core operations
- Dashboard
- Orders
- Vendors
- Riders
- Customers
- Payouts
- Audit log
- Analytics

## Recommended next modules
- Vendor detail + menu moderation
- Rider detail + document verification
- Customer support timeline
- Order detail + full event timeline
- Dispatch board / live rider map
- Refunds and payment disputes
- Promotions/coupons
- Inventory and catalog moderation
- Service areas/geofencing
- Notification center
- Role/permission management
- Feature flags
- System configuration
- Fraud/risk queue
- Reconciliation

## Shared domain rule

Customer, vendor, rider and admin apps must consume one backend order state machine. Admin commands may intervene only where the policy allows, and every intervention must create an audit event.
