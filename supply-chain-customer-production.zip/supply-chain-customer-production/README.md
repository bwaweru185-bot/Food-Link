# Supply Chain Customer App

Production customer mobile application for food transportation.

## Principles

This repository intentionally contains **no fake orders, fake payments, fake riders, or demo API responses**. The UI is backed by typed API contracts and explicit loading/error/empty states.

### Stack

- Expo + Expo Router
- TypeScript with strict mode
- TanStack Query for server state
- Zustand for auth/session state
- React Hook Form + Zod for validated forms
- Expo Secure Store for credentials
- Central API client with refresh-token handling

## Run

```bash
npm install
cp .env.example .env
npm run typecheck
npm run lint
npm start
```

Set `EXPO_PUBLIC_API_URL` to the deployed HTTPS API.

## Backend contract expected by this app

```text
POST /v1/auth/customer/login
POST /v1/auth/customer/register
POST /v1/auth/customer/refresh
POST /v1/auth/customer/logout
GET  /v1/customer/me

GET  /v1/customer/orders
GET  /v1/customer/orders/:id
POST /v1/customer/orders
POST /v1/customer/orders/:id/cancel

GET  /v1/customer/addresses
POST /v1/customer/addresses
PATCH /v1/customer/addresses/:id
DELETE /v1/customer/addresses/:id

POST /v1/customer/orders/:id/payment-intent
GET  /v1/customer/orders/:id/tracking

POST /v1/customer/orders/:id/rating
```

### Authentication response

```json
{
  "accessToken": "access-token",
  "refreshToken": "refresh-token",
  "user": {
    "id": "usr_123",
    "name": "Akosua Mensah",
    "phone": "+233249876543"
  }
}
```

### Important

The backend is the source of truth for:

- order totals
- delivery fees
- order status
- payment state
- rider assignment
- ETA
- customer authorization

Do not move those decisions into the mobile client.

## Production checklist

Before store release, configure:

- real API URL
- Android/iOS bundle identifiers
- Apple/Google credentials
- push notification credentials
- deep links
- crash/error monitoring
- privacy policy URL
- terms URL
- analytics consent
- production payment provider
- production maps provider
- backend rate limiting and audit logs
