import { create } from "zustand";
import type { User } from "@/types/auth";
import { clearTokens, getAccessToken, setTokens } from "@/lib/secure-store";
import { api } from "@/lib/api";

type AuthState = {
  hydrated: boolean;
  token: string | null;
  user: User | null;
  bootstrap: () => Promise<void>;
  setSession: (accessToken: string, refreshToken: string, user: User) => Promise<void>;
  logout: () => Promise<void>;
};

export const useAuthStore = create<AuthState>((set) => ({
  hydrated: false,
  token: null,
  user: null,

  bootstrap: async () => {
    const token = await getAccessToken();
    if (!token) {
      set({ hydrated: true, token: null, user: null });
      return;
    }

    try {
      const user = await api<User>("/v1/customer/me", { auth: true });
      set({ hydrated: true, token, user });
    } catch {
      await clearTokens();
      set({ hydrated: true, token: null, user: null });
    }
  },

  setSession: async (accessToken, refreshToken, user) => {
    await setTokens(accessToken, refreshToken);
    set({ token: accessToken, user, hydrated: true });
  },

  logout: async () => {
    try {
      await api("/v1/auth/customer/logout", { method: "POST" });
    } catch {
      // Local logout must still succeed if the network is unavailable.
    }
    await clearTokens();
    set({ token: null, user: null, hydrated: true });
  },
}));
