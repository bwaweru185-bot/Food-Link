import { Redirect } from "expo-router";
import { ActivityIndicator, View } from "react-native";
import { useEffect } from "react";
import { colors } from "@/constants/theme";
import { useAuthStore } from "@/store/auth";

export default function Entry() {
  const hydrated = useAuthStore((s) => s.hydrated);
  const token = useAuthStore((s) => s.token);
  const bootstrap = useAuthStore((s) => s.bootstrap);

  useEffect(() => {
    bootstrap();
  }, [bootstrap]);

  if (!hydrated) {
    return (
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
        <ActivityIndicator color={colors.primary} />
      </View>
    );
  }

  return <Redirect href={token ? "/(customer)" : "/(auth)/welcome"} />;
}
