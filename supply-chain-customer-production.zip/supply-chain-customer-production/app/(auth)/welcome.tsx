import { router } from "expo-router";
import { StyleSheet, Text, View } from "react-native";
import { Button } from "@/components/ui/Button";
import { colors, spacing } from "@/constants/theme";

export default function Welcome() {
  return (
    <View style={styles.container}>
      <View style={styles.brand}>
        <View style={styles.logo}><Text style={styles.truck}>🚚</Text></View>
        <Text style={styles.title}>SUPPLY CHAIN</Text>
        <Text style={styles.subtitle}>Food Transportation</Text>
        <Text style={styles.tagline}>Safe. Fast. Reliable.</Text>
      </View>
      <View style={styles.actions}>
        <Button title="Get Started" onPress={() => router.push("/(auth)/login")} />
        <Button title="Login" variant="secondary" onPress={() => router.push("/(auth)/login")} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.primaryDark, padding: spacing.xl, justifyContent: "space-between" },
  brand: { alignItems: "center", marginTop: 100 },
  logo: { width: 110, height: 110, borderRadius: 55, backgroundColor: colors.white, justifyContent: "center", alignItems: "center", marginBottom: 22 },
  truck: { fontSize: 52 },
  title: { color: colors.white, fontSize: 25, fontWeight: "900" },
  subtitle: { color: colors.white, fontSize: 16, marginTop: 5 },
  tagline: { color: "#D7EEE1", fontSize: 13, marginTop: 4 },
  actions: { gap: 12, marginBottom: 16 },
});
