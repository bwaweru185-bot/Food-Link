import { zodResolver } from "@hookform/resolvers/zod";
import { router } from "expo-router";
import { Controller, useForm } from "react-hook-form";
import { Alert, StyleSheet, Text, View } from "react-native";
import { z } from "zod";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { Screen } from "@/components/ui/Screen";
import { colors, spacing } from "@/constants/theme";
import { login } from "@/services/auth";
import { useAuthStore } from "@/store/auth";

const schema = z.object({
  phone: z.string().min(9, "Enter a valid phone number."),
  password: z.string().min(8, "Password must be at least 8 characters."),
});
type Form = z.infer<typeof schema>;

export default function Login() {
  const setSession = useAuthStore((s) => s.setSession);
  const { control, handleSubmit, formState: { errors, isSubmitting } } = useForm<Form>({
    resolver: zodResolver(schema),
    defaultValues: { phone: "", password: "" },
  });

  const submit = async (values: Form) => {
    try {
      const result = await login(values);
      await setSession(result.accessToken, result.refreshToken, result.user);
      router.replace("/(customer)");
    } catch (error) {
      Alert.alert("Login failed", error instanceof Error ? error.message : "Please try again.");
    }
  };

  return (
    <Screen>
      <View style={styles.header}>
        <Text style={styles.title}>Welcome Back!</Text>
        <Text style={styles.subtitle}>Login to continue</Text>
      </View>
      <View style={styles.form}>
        <Controller control={control} name="phone" render={({ field: { onChange, value } }) =>
          <Input label="Phone Number" placeholder="+233 24 123 4567" keyboardType="phone-pad" value={value} onChangeText={onChange} error={errors.phone?.message} />
        } />
        <Controller control={control} name="password" render={({ field: { onChange, value } }) =>
          <Input label="Password" placeholder="••••••••" secureTextEntry value={value} onChangeText={onChange} error={errors.password?.message} />
        } />
        <Text style={styles.forgot}>Forgot Password?</Text>
        <Button title="Login" loading={isSubmitting} onPress={handleSubmit(submit)} />
        <Button title="Continue with Google" variant="secondary" onPress={() => Alert.alert("Not configured", "Connect your production identity provider before enabling social login.")} />
        <Text style={styles.register}>Don't have an account? <Text style={styles.link}>Register</Text></Text>
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  header: { marginTop: spacing.xl, gap: 5 },
  title: { color: colors.text, fontSize: 26, fontWeight: "900" },
  subtitle: { color: colors.muted },
  form: { gap: spacing.lg, marginTop: 12 },
  forgot: { color: colors.primary, alignSelf: "flex-end", fontSize: 12, fontWeight: "700" },
  register: { color: colors.muted, textAlign: "center", marginTop: 10 },
  link: { color: colors.primary, fontWeight: "800" },
});
