import { zodResolver } from "@hookform/resolvers/zod";
import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import { Controller, useForm } from "react-hook-form";
import { Alert, Pressable, StyleSheet, Text, View } from "react-native";
import { z } from "zod";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { Screen } from "@/components/ui/Screen";
import { colors, radius, spacing } from "@/constants/theme";
import { createOrder } from "@/services/orders";
import { listAddresses } from "@/services/addresses";
import { useQueryClient } from "@tanstack/react-query";

const schema = z.object({
  foodType: z.string().min(2, "Enter the food type."),
  quantity: z.string().min(1, "Enter quantity or weight."),
  pickupAddressId: z.string().min(1, "Select a pickup address."),
  deliveryAddressId: z.string().min(1, "Select a delivery address."),
  pickupAt: z.string().min(1, "Select a pickup time."),
  contactPhone: z.string().min(9, "Enter a valid phone number."),
  specialInstructions: z.string().max(500).optional(),
});
type Form = z.infer<typeof schema>;

export default function Send() {
  const client = useQueryClient();
  const addresses = useQuery({ queryKey: ["addresses"], queryFn: listAddresses });
  const { control, handleSubmit, setValue, watch, formState: { errors, isSubmitting } } = useForm<Form>({
    resolver: zodResolver(schema),
    defaultValues: { foodType: "", quantity: "", pickupAddressId: "", deliveryAddressId: "", pickupAt: "", contactPhone: "", specialInstructions: "" },
  });

  const pickupId = watch("pickupAddressId");
  const deliveryId = watch("deliveryAddressId");

  const submit = async (values: Form) => {
    try {
      const order = await createOrder(values);
      await client.invalidateQueries({ queryKey: ["orders"] });
      router.replace({ pathname: "/(customer)/order/[id]", params: { id: order.id } });
    } catch (error) {
      Alert.alert("Couldn't create order", error instanceof Error ? error.message : "Please try again.");
    }
  };

  return (
    <Screen>
      <View style={styles.header}>
        <View><Text style={styles.title}>Send Food</Text><Text style={styles.subtitle}>Enter the details for your delivery.</Text></View>
        <View style={styles.icon}><Ionicons name="paper-plane" size={20} color={colors.primary} /></View>
      </View>

      <View style={styles.progress}>
        {["Food", "Delivery", "Payment"].map((label, i) => <View key={label} style={styles.progressItem}>
          <View style={[styles.dot, i === 0 && styles.activeDot]}><Text style={styles.dotText}>{i + 1}</Text></View>
          <Text style={[styles.progressText, i === 0 && styles.activeText]}>{label}</Text>
        </View>)}
      </View>

      <View style={styles.card}>
        <Text style={styles.section}>Food details</Text>
        <Controller control={control} name="foodType" render={({ field: { onChange, value } }) =>
          <Input label="Food Type" placeholder="Fufu & Light Soup" value={value} onChangeText={onChange} error={errors.foodType?.message} />} />
        <Controller control={control} name="quantity" render={({ field: { onChange, value } }) =>
          <Input label="Quantity / Weight" placeholder="e.g. 2 kg" value={value} onChangeText={onChange} error={errors.quantity?.message} />} />
        <Controller control={control} name="contactPhone" render={({ field: { onChange, value } }) =>
          <Input label="Recipient Phone" placeholder="+233 24 987 6543" keyboardType="phone-pad" value={value} onChangeText={onChange} error={errors.contactPhone?.message} />} />
        <Controller control={control} name="pickupAt" render={({ field: { onChange, value } }) =>
          <Input label="Pickup Date & Time" placeholder="2026-09-05T14:00:00+03:00" value={value} onChangeText={onChange} error={errors.pickupAt?.message} />} />

        <Text style={styles.label}>Pickup Address</Text>
        {addresses.data?.map((address) => (
          <AddressOption key={address.id} selected={pickupId === address.id} title={address.label} subtitle={`${address.line1}, ${address.city}`} onPress={() => setValue("pickupAddressId", address.id, { shouldValidate: true })} />
        ))}
        {errors.pickupAddressId ? <Text style={styles.error}>{errors.pickupAddressId.message}</Text> : null}

        <Text style={styles.label}>Delivery Address</Text>
        {addresses.data?.map((address) => (
          <AddressOption key={address.id} selected={deliveryId === address.id} title={address.label} subtitle={`${address.line1}, ${address.city}`} onPress={() => setValue("deliveryAddressId", address.id, { shouldValidate: true })} />
        ))}
        {errors.deliveryAddressId ? <Text style={styles.error}>{errors.deliveryAddressId.message}</Text> : null}

        <Controller control={control} name="specialInstructions" render={({ field: { onChange, value } }) =>
          <Input label="Special Instructions (optional)" multiline value={value} onChangeText={onChange} error={errors.specialInstructions?.message} />} />
      </View>

      <Button title="Review & Continue" loading={isSubmitting} onPress={handleSubmit(submit)} />
    </Screen>
  );
}

function AddressOption({ selected, title, subtitle, onPress }: { selected: boolean; title: string; subtitle: string; onPress: () => void }) {
  return <Pressable onPress={onPress} style={[styles.option, selected && styles.selected]}>
    <Ionicons name={selected ? "radio-button-on" : "radio-button-off"} size={20} color={selected ? colors.primary : colors.muted} />
    <View style={{ flex: 1 }}><Text style={styles.optionTitle}>{title}</Text><Text style={styles.optionSub}>{subtitle}</Text></View>
  </Pressable>;
}

const styles = StyleSheet.create({
  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  title: { color: colors.text, fontSize: 26, fontWeight: "900" },
  subtitle: { color: colors.muted, fontSize: 13, marginTop: 4, maxWidth: 290 },
  icon: { width: 44, height: 44, borderRadius: 22, backgroundColor: colors.primarySoft, alignItems: "center", justifyContent: "center" },
  progress: { flexDirection: "row", justifyContent: "space-between", backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: 12 },
  progressItem: { flex: 1, alignItems: "center", gap: 5 },
  dot: { width: 28, height: 28, borderRadius: 14, backgroundColor: colors.background, alignItems: "center", justifyContent: "center" },
  activeDot: { backgroundColor: colors.primary },
  dotText: { color: colors.muted, fontSize: 11, fontWeight: "800" },
  progressText: { color: colors.muted, fontSize: 10 },
  activeText: { color: colors.primary, fontWeight: "800" },
  card: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: radius.lg, padding: spacing.lg, gap: spacing.lg },
  section: { color: colors.text, fontSize: 17, fontWeight: "900" },
  label: { color: colors.text, fontSize: 13, fontWeight: "800", marginBottom: -8 },
  option: { minHeight: 58, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: 12, flexDirection: "row", alignItems: "center", gap: 10 },
  selected: { borderColor: colors.primary, backgroundColor: colors.primarySoft },
  optionTitle: { color: colors.text, fontWeight: "800", fontSize: 13 },
  optionSub: { color: colors.muted, fontSize: 11, marginTop: 3 },
  error: { color: colors.danger, fontSize: 11, marginTop: -12 },
});
