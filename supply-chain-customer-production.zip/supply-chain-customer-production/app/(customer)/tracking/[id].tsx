import { Ionicons } from "@expo/vector-icons";
import { useQuery } from "@tanstack/react-query";
import { router, useLocalSearchParams } from "expo-router";
import { ActivityIndicator, StyleSheet, Text, View } from "react-native";
import { Button } from "@/components/ui/Button";
import { ErrorState } from "@/components/ui/ErrorState";
import { Screen } from "@/components/ui/Screen";
import { colors, radius, spacing } from "@/constants/theme";
import { getTracking } from "@/services/orders";

export default function Tracking() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const query = useQuery({
    queryKey: ["tracking", id],
    queryFn: () => getTracking(id!),
    enabled: Boolean(id),
    refetchInterval: 15_000,
  });

  if (query.isPending) return <Screen><ActivityIndicator color={colors.primary} /></Screen>;
  if (query.isError || !query.data) return <Screen><ErrorState onRetry={() => query.refetch()} /></Screen>;

  return (
    <Screen>
      <View><Text style={styles.title}>Track Order</Text><Text style={styles.muted}>Order #{id}</Text></View>

      <View style={styles.status}>
        <View style={styles.check}><Ionicons name="checkmark" size={18} color={colors.white} /></View>
        <View style={{ flex: 1 }}><Text style={styles.statusTitle}>In Transit</Text><Text style={styles.muted}>Your food is on the way.</Text></View>
        <Text style={styles.eta}>{query.data.etaMinutes != null ? `${query.data.etaMinutes} min` : "Updating"}</Text>
      </View>

      <View style={styles.map}>
        <Ionicons name="map-outline" size={58} color={colors.primary} />
        <Text style={styles.mapTitle}>Live map</Text>
        <Text style={styles.muted}>Connect the production maps provider here.</Text>
        {query.data.latitude != null && query.data.longitude != null
          ? <Text style={styles.coordinates}>{query.data.latitude.toFixed(5)}, {query.data.longitude.toFixed(5)}</Text>
          : null}
      </View>

      {query.data.rider ? <View style={styles.rider}>
        <View style={styles.avatar}><Ionicons name="person" size={22} color={colors.primary} /></View>
        <View style={{ flex: 1 }}><Text style={styles.riderName}>{query.data.rider.name}</Text><Text style={styles.muted}>★ {query.data.rider.rating.toFixed(1)}</Text></View>
        <Ionicons name="call-outline" size={22} color={colors.primary} />
        <Ionicons name="chatbubble-outline" size={22} color={colors.primary} />
      </View> : null}

      <Button title="Back to order" variant="secondary" onPress={() => router.back()} />
    </Screen>
  );
}

const styles = StyleSheet.create({
  title: { color: colors.text, fontSize: 25, fontWeight: "900" },
  muted: { color: colors.muted, fontSize: 12 },
  status: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.md, flexDirection: "row", alignItems: "center", gap: 12 },
  check: { width: 40, height: 40, borderRadius: 20, backgroundColor: colors.success, alignItems: "center", justifyContent: "center" },
  statusTitle: { color: colors.text, fontWeight: "900" },
  eta: { color: colors.primary, fontWeight: "900" },
  map: { height: 330, borderRadius: radius.md, backgroundColor: "#EAF0ED", alignItems: "center", justifyContent: "center", gap: 7, borderWidth: 1, borderColor: colors.border },
  mapTitle: { color: colors.text, fontWeight: "900" },
  coordinates: { color: colors.primary, fontSize: 11, fontWeight: "700" },
  rider: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.md, flexDirection: "row", alignItems: "center", gap: 12 },
  avatar: { width: 46, height: 46, borderRadius: 23, backgroundColor: colors.primarySoft, alignItems: "center", justifyContent: "center" },
  riderName: { color: colors.text, fontWeight: "900" },
});
