import { Redirect, Stack } from "expo-router";
import { useAuthStore } from "@/store/auth";

export default function CustomerLayout() {
  const token = useAuthStore((s) => s.token);
  if (!token) return <Redirect href="/(auth)/login" />;
  return <Stack screenOptions={{ headerShown: false }} />;
}
