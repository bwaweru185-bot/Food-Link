import { Ionicons } from "@expo/vector-icons";
import { useQuery } from "@tanstack/react-query";
import { router, useLocalSearchParams } from "expo-router";
import { ActivityIndicator, StyleSheet, Text, View } from "react-native";
import { Button } from "@/components/ui/Button";
import { ErrorState } from "@/components/ui/ErrorState";
import { Screen } from "@/components/ui/Screen";
import { colors, radius, spacing } from "@/constants/theme";
import { getOrder } from "@/services/orders";

export default function OrderDetails() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const query = useQuery({ queryKey: ["order", id], queryFn: () => getOrder(id!), enabled: Boolean(id) });
  if (query.isPending) return <Screen><ActivityIndicator color={colors.primary} /></Screen>;
  if (query.isError || !query.data) return <Screen><ErrorState onRetry={() => query.refetch()} /></Screen>;
  const order = query.data;

  return (
    <Screen>
      <View><Text style={styles.title}>Order {order.reference}</Text><Text style={styles.muted}>{order.foodType} · {order.quantity}</Text></View>

      <View style={styles.status}>
        <View style={styles.statusIcon}><Ionicons name={order.status === "delivered" ? "checkmark" : "time"} size={20} color={colors.white} /></View>
        <View><Text style={styles.statusTitle}>{format(order.status)}</Text><Text style={styles.muted}>{statusText(order.status)}</Text></View>
      </View>

      <View style={styles.card}>
        <Row label="Pickup" value={`${order.pickupAddress.line1}, ${order.pickupAddress.city}`} />
        <Row label="Delivery" value={`${order.deliveryAddress.line1}, ${order.deliveryAddress.city}`} />
        <Row label="Pickup time" value={new Date(order.pickupAt).toLocaleString()} />
        <Row label="Total" value={`${order.pricing.currency} ${order.pricing.total.toFixed(2)}`} />
      </View>

      {order.rider ? <View style={styles.card}>
        <Text style={styles.section}>Your rider</Text>
        <Row label="Name" value={order.rider.name} />
        <Row label="Rating" value={`★ ${order.rider.rating.toFixed(1)}`} />
        <Button title="Track delivery" onPress={() => router.push({ pathname: "/(customer)/tracking/[id]", params: { id: order.id } })} />
      </View> : null}
    </Screen>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return <View style={styles.row}><Text style={styles.muted}>{label}</Text><Text style={styles.value}>{value}</Text></View>;
}
function format(v: string) { return v.replaceAll("_", " ").replace(/\b\w/g, c => c.toUpperCase()); }
function statusText(v: string) { return v === "delivered" ? "Your food has been delivered." : "Your order is being processed."; }

const styles = StyleSheet.create({
  title: { color: colors.text, fontSize: 24, fontWeight: "900" },
  muted: { color: colors.muted, fontSize: 12 },
  status: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.lg, flexDirection: "row", alignItems: "center", gap: 12 },
  statusIcon: { width: 40, height: 40, borderRadius: 20, backgroundColor: colors.success, alignItems: "center", justifyContent: "center" },
  statusTitle: { color: colors.text, fontWeight: "900" },
  card: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.lg, gap: spacing.md },
  section: { color: colors.text, fontSize: 16, fontWeight: "900" },
  row: { gap: 4, borderBottomWidth: 1, borderBottomColor: colors.border, paddingBottom: 10 },
  value: { color: colors.text, fontWeight: "700", fontSize: 13 },
});
