import { useQuery } from "@tanstack/react-query";
import { ActivityIndicator, StyleSheet, Text, View } from "react-native";
import { Screen } from "@/components/ui/Screen";
import { ErrorState } from "@/components/ui/ErrorState";
import { EmptyState } from "@/components/ui/EmptyState";
import { OrderCard } from "@/components/order/OrderCard";
import { colors, spacing } from "@/constants/theme";
import { listOrders } from "@/services/orders";

export default function Orders() {
  const query = useQuery({ queryKey: ["orders", 1], queryFn: () => listOrders(1) });

  return (
    <Screen>
      <Text style={styles.title}>Orders</Text>
      <Text style={styles.subtitle}>Track active deliveries and review previous orders.</Text>
      {query.isPending ? <ActivityIndicator color={colors.primary} /> :
       query.isError ? <ErrorState onRetry={() => query.refetch()} /> :
       query.data.items.length === 0 ? <EmptyState title="No orders yet" text="Start your first food delivery from the Send tab." /> :
       <View style={styles.list}>{query.data.items.map((order) => <OrderCard key={order.id} order={order} />)}</View>}
    </Screen>
  );
}

const styles = StyleSheet.create({
  title: { color: colors.text, fontSize: 26, fontWeight: "900" },
  subtitle: { color: colors.muted, marginTop: -10 },
  list: { gap: spacing.md },
});
