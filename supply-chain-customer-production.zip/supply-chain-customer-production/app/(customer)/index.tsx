import { Ionicons } from "@expo/vector-icons";
import { useQuery } from "@tanstack/react-query";
import { router } from "expo-router";
import { ActivityIndicator, Pressable, StyleSheet, Text, View } from "react-native";
import { Screen } from "@/components/ui/Screen";
import { ErrorState } from "@/components/ui/ErrorState";
import { EmptyState } from "@/components/ui/EmptyState";
import { OrderCard } from "@/components/order/OrderCard";
import { colors, radius, spacing } from "@/constants/theme";
import { listOrders } from "@/services/orders";
import { useAuthStore } from "@/store/auth";

export default function Home() {
  const user = useAuthStore((s) => s.user);
  const query = useQuery({ queryKey: ["orders", 1], queryFn: () => listOrders(1) });

  return (
    <Screen>
      <View style={styles.header}>
        <View>
          <Text style={styles.greeting}>Hello, {user?.name?.split(" ")[0] ?? "there"} 👋</Text>
          <Text style={styles.sub}>What would you like to do?</Text>
        </View>
        <Pressable onPress={() => router.push("/(customer)/profile")} style={styles.avatar}>
          <Ionicons name="person" size={20} color={colors.primary} />
        </Pressable>
      </View>

      <View style={styles.actions}>
        <Action title="Send Food" icon="paper-plane" onPress={() => router.push("/(customer)/send")} />
        <Action title="Track Order" icon="location" onPress={() => router.push("/(customer)/orders")} dark />
      </View>

      <View style={styles.banner}>
        <View style={styles.check}><Ionicons name="checkmark" size={19} color={colors.white} /></View>
        <View style={{ flex: 1 }}>
          <Text style={styles.bannerTitle}>Safe, fast food transportation</Text>
          <Text style={styles.bannerText}>Book a pickup and track your delivery.</Text>
        </View>
      </View>

      <View style={styles.sectionRow}>
        <Text style={styles.section}>Recent Orders</Text>
        <Pressable onPress={() => router.push("/(customer)/orders")}><Text style={styles.view}>View all</Text></Pressable>
      </View>

      {query.isPending ? <ActivityIndicator color={colors.primary} /> :
       query.isError ? <ErrorState onRetry={() => query.refetch()} /> :
       query.data.items.length === 0 ? <EmptyState title="No orders yet" text="Your completed and active deliveries will appear here." /> :
       <View style={{ gap: 12 }}>{query.data.items.slice(0, 3).map((o) => <OrderCard key={o.id} order={o} />)}</View>}
    </Screen>
  );
}

function Action({ title, icon, onPress, dark = false }: { title: string; icon: keyof typeof Ionicons.glyphMap; onPress: () => void; dark?: boolean }) {
  return (
    <Pressable onPress={onPress} style={[styles.action, dark && { backgroundColor: colors.primaryDark }]}>
      <Ionicons name={icon} size={22} color={colors.white} />
      <Text style={styles.actionText}>{title}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  greeting: { color: colors.text, fontSize: 20, fontWeight: "900" },
  sub: { color: colors.muted, marginTop: 4, fontSize: 13 },
  avatar: { width: 42, height: 42, borderRadius: 21, backgroundColor: colors.primarySoft, alignItems: "center", justifyContent: "center" },
  actions: { flexDirection: "row", gap: 12 },
  action: { flex: 1, minHeight: 84, borderRadius: radius.md, backgroundColor: colors.primary, padding: 14, justifyContent: "space-between" },
  actionText: { color: colors.white, fontWeight: "900", fontSize: 13 },
  banner: { flexDirection: "row", alignItems: "center", gap: 12, padding: 14, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md },
  check: { width: 38, height: 38, borderRadius: 19, backgroundColor: colors.success, alignItems: "center", justifyContent: "center" },
  bannerTitle: { color: colors.text, fontWeight: "800", fontSize: 13 },
  bannerText: { color: colors.muted, fontSize: 11, marginTop: 3 },
  sectionRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  section: { color: colors.text, fontSize: 17, fontWeight: "900" },
  view: { color: colors.primary, fontSize: 12, fontWeight: "800" },
});
