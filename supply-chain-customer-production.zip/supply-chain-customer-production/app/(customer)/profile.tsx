import { router } from "expo-router";
import { Alert, StyleSheet, Text, View } from "react-native";
import { Button } from "@/components/ui/Button";
import { Screen } from "@/components/ui/Screen";
import { colors, radius, spacing } from "@/constants/theme";
import { useAuthStore } from "@/store/auth";

export default function Profile() {
  const user = useAuthStore((s) => s.user);
  const logout = useAuthStore((s) => s.logout);

  const signOut = () => {
    Alert.alert("Log out", "Are you sure you want to log out?", [
      { text: "Cancel", style: "cancel" },
      { text: "Log out", style: "destructive", onPress: async () => { await logout(); router.replace("/(auth)/login"); } },
    ]);
  };

  return (
    <Screen>
      <View style={styles.profile}>
        <View style={styles.avatar}><Text style={styles.initial}>{user?.name?.charAt(0).toUpperCase() ?? "C"}</Text></View>
        <Text style={styles.name}>{user?.name ?? "Customer"}</Text>
        <Text style={styles.phone}>{user?.phone ?? ""}</Text>
      </View>
      {["Personal Information", "Saved Addresses", "Payment Methods", "Notifications", "Privacy & Security"].map((item) =>
        <View key={item} style={styles.row}><Text style={styles.rowText}>{item}</Text><Text style={styles.chevron}>›</Text></View>
      )}
      <Button title="Log out" variant="secondary" onPress={signOut} />
    </Screen>
  );
}

const styles = StyleSheet.create({
  profile: { alignItems: "center", gap: 6, paddingVertical: 18 },
  avatar: { width: 84, height: 84, borderRadius: 42, backgroundColor: colors.primarySoft, alignItems: "center", justifyContent: "center" },
  initial: { color: colors.primary, fontSize: 30, fontWeight: "900" },
  name: { color: colors.text, fontSize: 20, fontWeight: "900" },
  phone: { color: colors.muted },
  row: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.lg, flexDirection: "row", justifyContent: "space-between" },
  rowText: { color: colors.text, fontWeight: "700" },
  chevron: { color: colors.muted, fontSize: 22 },
});
