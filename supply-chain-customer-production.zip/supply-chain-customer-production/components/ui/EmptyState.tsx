import { StyleSheet, Text, View } from "react-native";
import { colors } from "@/constants/theme";

export function EmptyState({ title, text }: { title: string; text: string }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>{title}</Text>
      <Text style={styles.text}>{text}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { alignItems: "center", paddingVertical: 48, gap: 8 },
  title: { color: colors.text, fontWeight: "800", fontSize: 16 },
  text: { color: colors.muted, textAlign: "center", maxWidth: 280 },
});
