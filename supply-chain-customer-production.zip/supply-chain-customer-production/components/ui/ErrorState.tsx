import { StyleSheet, Text, View } from "react-native";
import { Button } from "@/components/ui/Button";
import { colors, spacing } from "@/constants/theme";

export function ErrorState({ onRetry }: { onRetry: () => void }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>We couldn't load this</Text>
      <Text style={styles.text}>Check your connection and try again.</Text>
      <Button title="Try again" onPress={onRetry} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { alignItems: "center", gap: spacing.md, paddingVertical: 48 },
  title: { color: colors.text, fontSize: 17, fontWeight: "800" },
  text: { color: colors.muted, textAlign: "center" },
});
