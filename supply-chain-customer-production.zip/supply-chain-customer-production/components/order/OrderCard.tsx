import { Ionicons } from "@expo/vector-icons";
import { Pressable, StyleSheet, Text, View } from "react-native";
import type { Order } from "@/types/order";
import { colors, radius, spacing } from "@/constants/theme";

export function OrderCard({ order, onPress }: { order: Order; onPress?: () => void }) {
  const delivered = order.status === "delivered";
  return (
    <Pressable onPress={onPress} style={styles.card}>
      <View style={styles.top}>
        <View style={styles.icon}><Ionicons name="fast-food-outline" size={21} color={colors.primary} /></View>
        <View style={styles.body}>
          <Text style={styles.title}>{order.foodType}</Text>
          <Text style={styles.meta}>{order.quantity} · {order.reference}</Text>
        </View>
        <Text style={styles.total}>{order.pricing.currency} {order.pricing.total.toFixed(2)}</Text>
      </View>
      <View style={styles.bottom}>
        <View style={[styles.badge, { backgroundColor: delivered ? colors.primarySoft : colors.orangeSoft }]}>
          <Text style={styles.badgeText}>{formatStatus(order.status)}</Text>
        </View>
        <Text style={styles.route} numberOfLines={1}>{order.deliveryAddress.city}, {order.deliveryAddress.region ?? ""}</Text>
      </View>
    </Pressable>
  );
}

function formatStatus(value: Order["status"]) {
  return value.replaceAll("_", " ").replace(/\b\w/g, (c) => c.toUpperCase());
}

const styles = StyleSheet.create({
  card: { backgroundColor: colors.surface, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border, padding: spacing.md, gap: spacing.md },
  top: { flexDirection: "row", alignItems: "center", gap: spacing.md },
  icon: { width: 46, height: 46, borderRadius: radius.md, backgroundColor: colors.primarySoft, alignItems: "center", justifyContent: "center" },
  body: { flex: 1, gap: 3 },
  title: { color: colors.text, fontWeight: "800", fontSize: 14 },
  meta: { color: colors.muted, fontSize: 11 },
  total: { color: colors.text, fontWeight: "900", fontSize: 13 },
  bottom: { flexDirection: "row", alignItems: "center", gap: 8 },
  badge: { paddingHorizontal: 9, paddingVertical: 5, borderRadius: radius.pill },
  badgeText: { color: colors.primary, fontSize: 10, fontWeight: "900" },
  route: { flex: 1, color: colors.muted, fontSize: 11 },
});
