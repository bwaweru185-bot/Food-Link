export interface User {
  id: string;
  name: string;
  phone: string;
  email?: string;
  avatarUrl?: string;
}

export interface LoginInput {
  phone: string;
  password: string;
}

export interface RegisterInput {
  name: string;
  phone: string;
  password: string;
}

export interface AuthResponse {
  accessToken: string;
  refreshToken: string;
  user: User;
}
