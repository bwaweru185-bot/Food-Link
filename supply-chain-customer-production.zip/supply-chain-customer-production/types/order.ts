export type OrderStatus =
  | "created"
  | "accepted"
  | "preparing"
  | "ready_for_pickup"
  | "picked_up"
  | "in_transit"
  | "delivered"
  | "cancelled";

export interface Address {
  id: string;
  label: string;
  recipientName?: string;
  phone?: string;
  line1: string;
  city: string;
  region?: string;
  latitude?: number;
  longitude?: number;
  isDefault: boolean;
}

export interface OrderPricing {
  pickupFee: number;
  deliveryFee: number;
  serviceFee: number;
  total: number;
  currency: string;
}

export interface Rider {
  id: string;
  name: string;
  phone: string;
  rating: number;
  avatarUrl?: string;
  vehicle?: string;
}

export interface Order {
  id: string;
  reference: string;
  foodType: string;
  quantity: string;
  specialInstructions?: string;
  pickupAddress: Address;
  deliveryAddress: Address;
  pickupAt: string;
  status: OrderStatus;
  pricing: OrderPricing;
  rider?: Rider;
  createdAt: string;
  updatedAt: string;
}

export interface CreateOrderInput {
  foodType: string;
  quantity: string;
  pickupAddressId: string;
  deliveryAddressId: string;
  pickupAt: string;
  contactPhone: string;
  specialInstructions?: string;
}
