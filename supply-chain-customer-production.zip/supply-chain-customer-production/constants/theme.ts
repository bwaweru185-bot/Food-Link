export const colors = {
  primary: "#087F3B",
  primaryDark: "#005E2D",
  primarySoft: "#E8F6EE",
  orange: "#E87500",
  orangeSoft: "#FFF1E2",
  background: "#F7F9F8",
  surface: "#FFFFFF",
  text: "#102A22",
  muted: "#718078",
  border: "#DDE5E0",
  danger: "#D92D20",
  dangerSoft: "#FEECEB",
  success: "#159447",
  white: "#FFFFFF",
  black: "#000000",
} as const;

export const spacing = {
  xs: 4, sm: 8, md: 12, lg: 16, xl: 24, xxl: 32,
} as const;

export const radius = {
  sm: 8, md: 12, lg: 18, pill: 999,
} as const;
