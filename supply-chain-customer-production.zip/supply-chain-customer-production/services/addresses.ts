import { api } from "@/lib/api";
import type { Address } from "@/types/order";

export const listAddresses = () => api<Address[]>("/v1/customer/addresses");

export const createAddress = (input: Omit<Address, "id">) =>
  api<Address>("/v1/customer/addresses", { method: "POST", body: input });
