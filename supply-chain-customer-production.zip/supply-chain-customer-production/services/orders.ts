import { api } from "@/lib/api";
import type { CreateOrderInput, Order } from "@/types/order";
import type { Paginated } from "@/types/api";

export const listOrders = (page = 1) =>
  api<Paginated<Order>>(`/v1/customer/orders?page=${page}&pageSize=20`);

export const getOrder = (id: string) =>
  api<Order>(`/v1/customer/orders/${encodeURIComponent(id)}`);

export const createOrder = (input: CreateOrderInput) =>
  api<Order>("/v1/customer/orders", { method: "POST", body: input });

export const cancelOrder = (id: string) =>
  api<Order>(`/v1/customer/orders/${encodeURIComponent(id)}/cancel`, { method: "POST" });

export const getTracking = (id: string) =>
  api<{
    orderId: string;
    latitude?: number;
    longitude?: number;
    etaMinutes?: number;
    rider?: Order["rider"];
  }>(`/v1/customer/orders/${encodeURIComponent(id)}/tracking`);
