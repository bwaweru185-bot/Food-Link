import { api } from "@/lib/api";
import type { AuthResponse, LoginInput, RegisterInput } from "@/types/auth";

export const login = (input: LoginInput) =>
  api<AuthResponse>("/v1/auth/customer/login", { method: "POST", auth: false, body: input });

export const register = (input: RegisterInput) =>
  api<AuthResponse>("/v1/auth/customer/register", { method: "POST", auth: false, body: input });
