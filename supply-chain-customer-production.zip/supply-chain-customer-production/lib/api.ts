import { getAccessToken, getRefreshToken, setTokens, clearTokens } from "@/lib/secure-store";

const API_URL = process.env.EXPO_PUBLIC_API_URL;

if (!API_URL && !__DEV__) {
  throw new Error("EXPO_PUBLIC_API_URL is required in production.");
}

export class ApiError extends Error {
  constructor(
    public readonly status: number,
    message: string,
    public readonly code?: string,
    public readonly details?: unknown,
  ) {
    super(message);
    this.name = "ApiError";
  }
}

type Options = Omit<RequestInit, "body"> & {
  body?: unknown;
  auth?: boolean;
  retry?: boolean;
};

let refreshPromise: Promise<string | null> | null = null;

async function refreshAccessToken(): Promise<string | null> {
  if (refreshPromise) return refreshPromise;

  refreshPromise = (async () => {
    const refreshToken = await getRefreshToken();
    if (!refreshToken) return null;

    const baseUrl = API_URL ?? "http://localhost:3000";
    const response = await fetch(`${baseUrl}/v1/auth/customer/refresh`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({ refreshToken }),
    });

    if (!response.ok) {
      await clearTokens();
      return null;
    }

    const data = (await response.json()) as {
      accessToken: string;
      refreshToken?: string;
    };

    await setTokens(data.accessToken, data.refreshToken ?? refreshToken);
    return data.accessToken;
  })().finally(() => {
    refreshPromise = null;
  });

  return refreshPromise;
}

export async function api<T>(
  path: string,
  options: Options = {},
): Promise<T> {
  const baseUrl = API_URL ?? "http://localhost:3000";
  const auth = options.auth ?? true;
  const retry = options.retry ?? true;
  let token = auth ? await getAccessToken() : null;

  const execute = async () => {
    const { body, auth: _auth, retry: _retry, headers, ...request } = options;
    return fetch(`${baseUrl}${path}`, {
      ...request,
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        ...(auth && token ? { Authorization: `Bearer ${token}` } : {}),
        ...headers,
      },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
  };

  let response = await execute();

  if (response.status === 401 && auth && retry) {
    token = await refreshAccessToken();
    if (token) response = await execute();
  }

  const text = await response.text();
  let data: unknown = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = { message: text || "Unexpected server response." };
  }

  if (!response.ok) {
    const body = (data ?? {}) as { message?: string; code?: string; details?: unknown };
    throw new ApiError(
      response.status,
      body.message ?? "Request failed.",
      body.code,
      body.details,
    );
  }

  return data as T;
}
