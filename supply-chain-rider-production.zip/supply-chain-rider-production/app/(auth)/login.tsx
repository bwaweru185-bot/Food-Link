import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import { useState } from "react";
import { Alert, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { Button } from "@/components/ui/Button";
import { colors, radius, spacing } from "@/constants/theme";
import { login } from "@/services/auth";
import { useAuthStore } from "@/store/auth";

export default function Login() {
  const setSession = useAuthStore(s => s.setSession);
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async () => {
    if (phone.trim().length < 9 || password.length < 8) {
      Alert.alert("Check your details", "Enter a valid phone number and a password of at least 8 characters.");
      return;
    }
    setLoading(true);
    try {
      const result = await login({ phone: phone.trim(), password });
      await setSession(result.accessToken, result.refreshToken, result.user);
      router.replace("/(rider)");
    } catch (e) {
      Alert.alert("Login failed", e instanceof Error ? e.message : "Please try again.");
    } finally { setLoading(false); }
  };

  return <View style={styles.container}>
    <View style={styles.brand}>
      <View style={styles.logo}><Ionicons name="car" size={34} color={colors.white} /></View>
      <Text style={styles.title}>RIDER LOGIN</Text>
      <Text style={styles.subtitle}>Login to your account</Text>
    </View>

    <View style={styles.form}>
      <Field label="Phone Number" value={phone} onChangeText={setPhone} placeholder="+233 24 111 2222" keyboardType="phone-pad" />
      <Field label="Password" value={password} onChangeText={setPassword} placeholder="••••••••" secureTextEntry />
      <Pressable><Text style={styles.forgot}>Forgot Password?</Text></Pressable>
      <Button title="Login" loading={loading} onPress={submit} />
      <Text style={styles.register}>Don't have an account? <Text style={{ color: colors.primary, fontWeight: "800" }}>Register</Text></Text>
    </View>
  </View>;
}

function Field(props: React.ComponentProps<typeof TextInput> & { label: string }) {
  return <View style={{ gap: 6 }}>
    <Text style={styles.label}>{props.label}</Text>
    <TextInput {...props} placeholderTextColor={colors.muted} style={styles.input} />
  </View>;
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: spacing.xl, justifyContent: "center", gap: 40 },
  brand: { alignItems: "center", gap: 7 },
  logo: { width: 78, height: 78, borderRadius: 39, backgroundColor: colors.primary, alignItems: "center", justifyContent: "center", marginBottom: 10 },
  title: { color: colors.text, fontWeight: "900", fontSize: 22 },
  subtitle: { color: colors.muted, fontSize: 13 },
  form: { gap: spacing.lg },
  label: { color: colors.text, fontWeight: "800", fontSize: 13 },
  input: { minHeight: 50, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surface, borderRadius: radius.md, paddingHorizontal: 14, color: colors.text },
  forgot: { color: colors.primary, fontWeight: "800", fontSize: 12, textAlign: "right" },
  register: { color: colors.muted, textAlign: "center" },
});
