import { useQuery } from "@tanstack/react-query";
import { ActivityIndicator, StyleSheet, Text, View } from "react-native";
import { Screen } from "@/components/ui/Screen";
import { ErrorState } from "@/components/ui/ErrorState";
import { colors, radius, spacing } from "@/constants/theme";
import { getEarnings, getTrips } from "@/services/earnings";

export default function Earnings() {
  const earnings = useQuery({ queryKey: ["earnings"], queryFn: getEarnings, refetchInterval: 60_000 });
  const trips = useQuery({ queryKey: ["trips"], queryFn: getTrips });

  return <Screen>
    <Text style={styles.title}>Earnings</Text>
    {earnings.isPending ? <ActivityIndicator color={colors.primary} /> : earnings.isError ? <ErrorState onRetry={() => earnings.refetch()} /> : earnings.data ? <View style={styles.hero}><Text style={styles.muted}>Today</Text><Text style={styles.amount}>{earnings.data.currency} {earnings.data.today.toFixed(2)}</Text><Text style={styles.trips}>{earnings.data.completedTrips} trips completed</Text></View> : null}

    {earnings.data ? <View style={styles.card}>
      <Row label="Trip Earnings" value={`${earnings.data.currency} ${earnings.data.tripEarnings.toFixed(2)}`} />
      <Row label="Tips" value={`${earnings.data.currency} ${earnings.data.tips.toFixed(2)}`} />
      <Row label="Bonuses" value={`${earnings.data.currency} ${earnings.data.bonuses.toFixed(2)}`} />
    </View> : null}

    <Text style={styles.section}>Recent Trips</Text>
    {trips.isPending ? <ActivityIndicator color={colors.primary} /> : trips.isError ? <ErrorState onRetry={() => trips.refetch()} /> :
      <View style={{ gap: 10 }}>{trips.data.items.map(t => <View key={t.id} style={styles.trip}><View style={{ flex: 1 }}><Text style={styles.tripRef}>{t.reference}</Text><Text style={styles.muted}>{new Date(t.completedAt).toLocaleString()}</Text></View><Text style={styles.tripAmount}>{t.currency} {t.amount.toFixed(2)}</Text></View>)}</View>}
  </Screen>;
}
function Row({ label, value }: { label: string; value: string }) { return <View style={styles.row}><Text style={styles.muted}>{label}</Text><Text style={styles.value}>{value}</Text></View>; }

const styles = StyleSheet.create({
  title: { color: colors.text, fontSize: 26, fontWeight: "900" }, hero: { backgroundColor: colors.primary, borderRadius: radius.lg, padding: spacing.xl, gap: 5 },
  muted: { color: colors.muted, fontSize: 11 }, hero: { backgroundColor: colors.primary, borderRadius: radius.lg, padding: spacing.xl, gap: 5 },
  amount: { color: colors.white, fontSize: 34, fontWeight: "900" }, trips: { color: "#FFF2E7", fontSize: 12 },
  card: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.lg, gap: spacing.lg },
  row: { flexDirection: "row", justifyContent: "space-between" }, value: { color: colors.text, fontWeight: "800" }, section: { color: colors.text, fontSize: 18, fontWeight: "900" },
  trip: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.md, flexDirection: "row", alignItems: "center" }, tripRef: { color: colors.text, fontWeight: "800" }, tripAmount: { color: colors.text, fontWeight: "900" },
});
