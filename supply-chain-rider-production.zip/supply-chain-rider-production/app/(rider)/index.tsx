import { Ionicons } from "@expo/vector-icons";
import { useQuery } from "@tanstack/react-query";
import { router } from "expo-router";
import { ActivityIndicator, Pressable, StyleSheet, Switch, Text, View } from "react-native";
import { Screen } from "@/components/ui/Screen";
import { ErrorState } from "@/components/ui/ErrorState";
import { JobCard } from "@/components/job/JobCard";
import { colors, radius, spacing } from "@/constants/theme";
import { listJobs } from "@/services/jobs";
import { useAuthStore } from "@/store/auth";
import { useRiderLocation } from "@/hooks/useRiderLocation";
import { useState } from "react";

export default function Dashboard() {
  const rider = useAuthStore(s => s.rider);
  const [online, setOnline] = useState(Boolean(rider?.online));
  useRiderLocation(online);

  const jobs = useQuery({ queryKey: ["rider-jobs"], queryFn: () => listJobs("offered"), refetchInterval: online ? 15_000 : false });

  return <Screen>
    <View style={styles.header}>
      <View>
        <Text style={styles.greeting}>Good Morning,</Text>
        <Text style={styles.name}>{rider?.name ?? "Rider"}</Text>
      </View>
      <Pressable onPress={() => router.push("/(rider)/profile")} style={styles.profile}><Ionicons name="person" size={19} color={colors.primary} /></Pressable>
    </View>

    <View style={styles.onlineCard}>
      <View style={styles.live}><View style={[styles.dot, online && styles.dotOn]} /><View><Text style={styles.liveTitle}>{online ? "Online" : "Offline"}</Text><Text style={styles.muted}>{online ? "You can receive new orders" : "Go online to receive orders"}</Text></View></View>
      <Switch value={online} onValueChange={setOnline} trackColor={{ false: colors.border, true: colors.successSoft }} thumbColor={online ? colors.success : colors.muted} />
    </View>

    <View style={styles.statRow}>
      <Stat title="Today's Earnings" value="View" icon="wallet-outline" onPress={() => router.push("/(rider)/earnings")} />
      <Stat title="Completed Trips" value="History" icon="receipt-outline" onPress={() => router.push("/(rider)/earnings")} />
    </View>

    <View style={styles.sectionRow}><Text style={styles.section}>New Orders</Text><Pressable onPress={() => jobs.refetch()}><Ionicons name="refresh" size={19} color={colors.primary} /></Pressable></View>

    {jobs.isPending ? <ActivityIndicator color={colors.primary} /> :
      jobs.isError ? <ErrorState onRetry={() => jobs.refetch()} /> :
      jobs.data.items.length === 0 ? <View style={styles.empty}><Ionicons name="checkmark-circle-outline" size={42} color={colors.success} /><Text style={styles.emptyTitle}>No new orders</Text><Text style={styles.muted}>We'll notify you when a delivery is available.</Text></View> :
      <View style={{ gap: spacing.md }}>{jobs.data.items.map(job => <JobCard key={job.id} job={job} onPress={() => router.push({ pathname: "/(rider)/job/[id]", params: { id: job.id } })} />)}</View>}
  </Screen>;
}

function Stat({ title, value, icon, onPress }: { title: string; value: string; icon: keyof typeof Ionicons.glyphMap; onPress: () => void }) {
  return <Pressable onPress={onPress} style={styles.stat}><Ionicons name={icon} size={22} color={colors.primary} /><Text style={styles.statTitle}>{title}</Text><Text style={styles.statValue}>{value} ›</Text></Pressable>;
}

const styles = StyleSheet.create({
  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  greeting: { color: colors.muted, fontSize: 12 }, name: { color: colors.text, fontSize: 21, fontWeight: "900", marginTop: 2 },
  profile: { width: 42, height: 42, borderRadius: 21, backgroundColor: "#FFF1E2", alignItems: "center", justifyContent: "center" },
  onlineCard: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.md, flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  live: { flexDirection: "row", gap: 10, alignItems: "center" }, dot: { width: 10, height: 10, borderRadius: 5, backgroundColor: colors.muted }, dotOn: { backgroundColor: colors.success },
  liveTitle: { color: colors.text, fontWeight: "900" }, muted: { color: colors.muted, fontSize: 11, marginTop: 2 },
  statRow: { flexDirection: "row", gap: 12 }, stat: { flex: 1, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.md, gap: 7 },
  statTitle: { color: colors.muted, fontSize: 10 }, statValue: { color: colors.text, fontWeight: "900", fontSize: 13 },
  sectionRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" }, section: { color: colors.text, fontSize: 18, fontWeight: "900" },
  empty: { alignItems: "center", paddingVertical: 45, gap: 8 }, emptyTitle: { color: colors.text, fontWeight: "900", fontSize: 16 },
});
