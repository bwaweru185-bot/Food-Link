import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import { Alert, StyleSheet, Text, View } from "react-native";
import { Button } from "@/components/ui/Button";
import { Screen } from "@/components/ui/Screen";
import { colors, radius, spacing } from "@/constants/theme";
import { useAuthStore } from "@/store/auth";

export default function Profile() {
  const rider = useAuthStore(s => s.rider);
  const logout = useAuthStore(s => s.logout);

  const signOut = () => Alert.alert("Log out", "Are you sure you want to log out?", [
    { text: "Cancel", style: "cancel" },
    { text: "Log out", style: "destructive", onPress: async () => { await logout(); router.replace("/(auth)/login"); } }
  ]);

  return <Screen>
    <View style={styles.profile}>
      <View style={styles.avatar}><Ionicons name="person" size={32} color={colors.primary} /></View>
      <Text style={styles.name}>{rider?.name ?? "Rider"}</Text>
      <Text style={styles.muted}>{rider?.phone ?? ""}</Text>
      <Text style={styles.rating}>★ {rider?.rating?.toFixed(1) ?? "—"}</Text>
    </View>
    {["My Vehicle", "My Documents", "Earnings", "Settings"].map(item =>
      <View key={item} style={styles.row}><Text style={styles.rowText}>{item}</Text><Text style={styles.arrow}>›</Text></View>
    )}
    <Button title="Log out" variant="secondary" onPress={signOut} />
  </Screen>;
}
const styles = StyleSheet.create({
  profile: { alignItems: "center", gap: 6, paddingVertical: 14 }, avatar: { width: 86, height: 86, borderRadius: 43, backgroundColor: "#FFF1E2", alignItems: "center", justifyContent: "center" },
  name: { color: colors.text, fontSize: 20, fontWeight: "900" }, muted: { color: colors.muted, fontSize: 12 }, rating: { color: colors.primary, fontWeight: "900" },
  row: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.lg, flexDirection: "row", justifyContent: "space-between" },
  rowText: { color: colors.text, fontWeight: "800" }, arrow: { color: colors.muted, fontSize: 22 },
});
