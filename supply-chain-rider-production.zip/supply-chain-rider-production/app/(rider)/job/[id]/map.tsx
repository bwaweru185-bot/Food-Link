import { Ionicons } from "@expo/vector-icons";
import { useQuery } from "@tanstack/react-query";
import { router, useLocalSearchParams } from "expo-router";
import { ActivityIndicator, StyleSheet, Text, View } from "react-native";
import { Button } from "@/components/ui/Button";
import { ErrorState } from "@/components/ui/ErrorState";
import { Screen } from "@/components/ui/Screen";
import { colors, radius, spacing } from "@/constants/theme";
import { getJob } from "@/services/jobs";
import { useRiderLocation } from "@/hooks/useRiderLocation";

export default function DeliveryMap() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const query = useQuery({ queryKey: ["job", id], queryFn: () => getJob(id!), enabled: Boolean(id), refetchInterval: 15_000 });
  useRiderLocation(true);

  if (query.isPending) return <Screen><ActivityIndicator color={colors.primary} /></Screen>;
  if (query.isError || !query.data) return <Screen><ErrorState onRetry={() => query.refetch()} /></Screen>;

  return <Screen>
    <View><Text style={styles.title}>In Transit</Text><Text style={styles.muted}>Delivery to {query.data.delivery.city}</Text></View>
    <View style={styles.map}>
      <Ionicons name="map-outline" size={60} color={colors.primary} />
      <Text style={styles.mapTitle}>Live navigation</Text>
      <Text style={styles.muted}>Connect the production maps/navigation SDK here.</Text>
      {query.data.delivery.latitude != null && query.data.delivery.longitude != null
        ? <Text style={styles.coordinates}>{query.data.delivery.latitude.toFixed(5)}, {query.data.delivery.longitude.toFixed(5)}</Text> : null}
    </View>
    <View style={styles.card}><Text style={styles.section}>Drop off</Text><Text style={styles.address}>{query.data.delivery.line1}, {query.data.delivery.city}</Text><Text style={styles.muted}>{query.data.customer.name} · {query.data.customer.phone}</Text></View>
    <Button title="Back to Order" variant="secondary" onPress={() => router.back()} />
  </Screen>;
}

const styles = StyleSheet.create({
  title: { color: colors.text, fontSize: 25, fontWeight: "900" }, muted: { color: colors.muted, fontSize: 11 },
  map: { height: 390, backgroundColor: "#EAF0ED", borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, alignItems: "center", justifyContent: "center", gap: 7 },
  mapTitle: { color: colors.text, fontWeight: "900" }, coordinates: { color: colors.primary, fontSize: 11, fontWeight: "800" },
  card: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.lg, gap: 8 },
  section: { color: colors.text, fontSize: 16, fontWeight: "900" }, address: { color: colors.text, fontSize: 14, fontWeight: "800" },
});
