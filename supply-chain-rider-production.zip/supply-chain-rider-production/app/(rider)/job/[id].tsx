import { Ionicons } from "@expo/vector-icons";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { router, useLocalSearchParams } from "expo-router";
import { Alert, StyleSheet, Text, View } from "react-native";
import { Button } from "@/components/ui/Button";
import { ErrorState } from "@/components/ui/ErrorState";
import { Screen } from "@/components/ui/Screen";
import { colors, radius, spacing } from "@/constants/theme";
import { getJob, transitionJob } from "@/services/jobs";
import type { JobStatus } from "@/types/job";

export default function JobDetails() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const client = useQueryClient();
  const query = useQuery({ queryKey: ["job", id], queryFn: () => getJob(id!), enabled: Boolean(id), refetchInterval: 15_000 });
  const mutation = useMutation({
    mutationFn: (action: Parameters<typeof transitionJob>[1]) => transitionJob(id!, action),
    onSuccess: async () => { await client.invalidateQueries({ queryKey: ["job", id] }); await client.invalidateQueries({ queryKey: ["rider-jobs"] }); },
    onError: e => Alert.alert("Action failed", e instanceof Error ? e.message : "Please try again."),
  });

  if (query.isPending) return <Screen><Text>Loading...</Text></Screen>;
  if (query.isError || !query.data) return <Screen><ErrorState onRetry={() => query.refetch()} /></Screen>;

  const job = query.data;
  const next = nextAction(job.status);

  return <Screen>
    <View><Text style={styles.title}>Order Accepted</Text><Text style={styles.muted}>#{job.reference}</Text></View>

    <View style={styles.card}>
      <Row icon="cube-outline" label="Pick up" value={`${job.pickup.line1}, ${job.pickup.city}`} />
      <Row icon="location-outline" label="Deliver to" value={`${job.delivery.line1}, ${job.delivery.city}`} />
      <Row icon="person-outline" label="Customer" value={`${job.customer.name} · ${job.customer.phone}`} />
      <Row icon="cash-outline" label="Payment" value={`${job.currency} ${job.paymentAmount.toFixed(2)}`} />
    </View>

    <View style={styles.card}>
      <Text style={styles.section}>Delivery status</Text>
      <Timeline status={job.status} />
    </View>

    {job.notes ? <View style={styles.note}><Text style={styles.noteTitle}>Special instructions</Text><Text style={styles.muted}>{job.notes}</Text></View> : null}

    {next ? <Button title={next.label} loading={mutation.isPending} onPress={() => mutation.mutate(next.action)} /> : null}
    {job.status === "accepted" ? <Button title="Reject order" variant="secondary" onPress={() => Alert.alert("Reject order", "This will return the job to the dispatch pool.", [{ text: "Cancel", style: "cancel" }, { text: "Reject", style: "destructive", onPress: () => mutation.mutate("reject") }])} /> : null}
    {job.status === "in_transit" ? <Button title="Open delivery tracking" variant="secondary" onPress={() => router.push({ pathname: "/(rider)/job/[id]/map", params: { id: job.id } })} /> : null}
  </Screen>;
}

function Row({ icon, label, value }: { icon: keyof typeof Ionicons.glyphMap; label: string; value: string }) {
  return <View style={styles.row}><View style={styles.rowIcon}><Ionicons name={icon} size={18} color={colors.primary} /></View><View style={{ flex: 1 }}><Text style={styles.muted}>{label}</Text><Text style={styles.value}>{value}</Text></View></View>;
}
function Timeline({ status }: { status: JobStatus }) {
  const steps: Array<[string, JobStatus]> = [["Order accepted", "accepted"], ["Arrived at pickup", "arrived_pickup"], ["Picked up", "picked_up"], ["In transit", "in_transit"], ["Delivered", "delivered"]];
  const rank = (s: JobStatus) => ["offered","accepted","arrived_pickup","picked_up","in_transit","delivered"].indexOf(s);
  return <View style={{ gap: 10 }}>{steps.map(([label, step]) => {
    const complete = rank(status) >= rank(step);
    return <View key={step} style={styles.timeline}><View style={[styles.timelineDot, complete && styles.complete]}><Ionicons name={complete ? "checkmark" : "ellipse-outline"} size={12} color={complete ? colors.white : colors.primary} /></View><Text style={[styles.timelineText, complete && styles.timelineComplete]}>{label}</Text></View>;
  })}</View>;
}
function nextAction(status: JobStatus) {
  const map: Partial<Record<JobStatus, { label: string; action: Parameters<typeof transitionJob>[1] }>> = {
    offered: { label: "Accept Order", action: "accept" },
    accepted: { label: "Start Pickup", action: "arrived-pickup" },
    arrived_pickup: { label: "Confirm Pickup", action: "confirm-pickup" },
    picked_up: { label: "Start Transit", action: "start-transit" },
    in_transit: { label: "Confirm Delivery", action: "confirm-delivery" },
  };
  return map[status];
}

const styles = StyleSheet.create({
  title: { color: colors.text, fontSize: 25, fontWeight: "900" }, muted: { color: colors.muted, fontSize: 11 },
  card: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.lg, gap: spacing.lg },
  row: { flexDirection: "row", gap: 12, alignItems: "center" }, rowIcon: { width: 36, height: 36, borderRadius: 18, backgroundColor: "#FFF1E2", alignItems: "center", justifyContent: "center" },
  value: { color: colors.text, fontSize: 13, fontWeight: "800", marginTop: 3 }, section: { color: colors.text, fontSize: 16, fontWeight: "900" },
  timeline: { flexDirection: "row", alignItems: "center", gap: 10 }, timelineDot: { width: 25, height: 25, borderRadius: 13, borderWidth: 1, borderColor: colors.primary, alignItems: "center", justifyContent: "center" },
  complete: { backgroundColor: colors.primary, borderColor: colors.primary }, timelineText: { color: colors.muted, fontSize: 12 }, timelineComplete: { color: colors.text, fontWeight: "700" },
  note: { padding: spacing.lg, backgroundColor: "#FFF8F0", borderRadius: radius.md, gap: 5 }, noteTitle: { color: colors.text, fontWeight: "900" },
});
