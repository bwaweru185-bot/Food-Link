# Supply Chain Rider App

Production rider/driver mobile application for food transportation.

This is not a demo application: it contains no fake jobs, earnings, GPS coordinates, customer records, or delivery confirmations. All operational state is expected to come from the backend.

## Stack

- Expo + Expo Router
- Strict TypeScript
- TanStack Query
- Zustand
- Expo Secure Store
- Expo Location
- Central API client with refresh-token handling

## Run

```bash
npm install
cp .env.example .env
npm run typecheck
npm run lint
npm start
```

## Required production API contract

```text
POST /v1/auth/rider/login
POST /v1/auth/rider/refresh
POST /v1/auth/rider/logout
GET  /v1/rider/me

GET  /v1/rider/jobs
GET  /v1/rider/jobs/:id
POST /v1/rider/jobs/:id/accept
POST /v1/rider/jobs/:id/reject
POST /v1/rider/jobs/:id/arrived-pickup
POST /v1/rider/jobs/:id/confirm-pickup
POST /v1/rider/jobs/:id/start-transit
POST /v1/rider/jobs/:id/confirm-delivery

POST /v1/rider/location
POST /v1/rider/location/batch

GET  /v1/rider/earnings
GET  /v1/rider/trips

GET  /v1/rider/profile
PATCH /v1/rider/profile
GET  /v1/rider/documents
GET  /v1/rider/vehicle

## Operational rules

The rider app must never independently mark a delivery as paid, completed, or assigned. The API must authorize every state transition and record an audit event.

GPS updates should be sent only while the rider is actively working, according to the backend's tracking policy. Background tracking requires explicit OS permission and store-compliant disclosure.

For delivery confirmation, production should use a backend-issued verification mechanism such as OTP, signature, or another approved proof-of-delivery method. Do not trust a client-only button as proof.

## Release checklist

- Production HTTPS API
- Secure refresh-token rotation
- Push notification credentials
- Maps provider and routing keys
- Location privacy disclosure
- Background-location review
- Crash/error monitoring
- Store privacy declarations
- Rider identity/onboarding handled server-side
- Audit logging for every job transition
