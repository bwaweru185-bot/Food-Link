import { Ionicons } from "@expo/vector-icons";
import { Pressable, StyleSheet, Text, View } from "react-native";
import type { DeliveryJob } from "@/types/job";
import { colors, radius, spacing } from "@/constants/theme";

export function JobCard({ job, onPress, action }: { job: DeliveryJob; onPress: () => void; action?: React.ReactNode }) {
  return <Pressable onPress={onPress} style={styles.card}>
    <View style={styles.top}>
      <View style={styles.icon}><Ionicons name="cube-outline" size={22} color={colors.primary} /></View>
      <View style={styles.body}>
        <Text style={styles.title}>{job.foodType}</Text>
        <Text style={styles.meta}>{job.quantity} · {job.reference}</Text>
      </View>
      <Text style={styles.amount}>{job.currency} {job.paymentAmount.toFixed(2)}</Text>
    </View>
    <View style={styles.route}>
      <View style={styles.marker}><Ionicons name="radio-button-on" size={12} color={colors.success} /></View>
      <Text style={styles.address} numberOfLines={1}>{job.pickup.line1}, {job.pickup.city}</Text>
    </View>
    <View style={styles.route}>
      <View style={[styles.marker, { backgroundColor: "#FFF1E2" }]}><Ionicons name="location" size={12} color={colors.primary} /></View>
      <Text style={styles.address} numberOfLines={1}>{job.delivery.line1}, {job.delivery.city}</Text>
    </View>
    {action}
  </Pressable>;
}

const styles = StyleSheet.create({
  card: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.md, gap: 10 },
  top: { flexDirection: "row", alignItems: "center", gap: 10 },
  icon: { width: 46, height: 46, borderRadius: 12, backgroundColor: "#FFF1E2", alignItems: "center", justifyContent: "center" },
  body: { flex: 1, gap: 3 },
  title: { color: colors.text, fontWeight: "900", fontSize: 14 },
  meta: { color: colors.muted, fontSize: 11 },
  amount: { color: colors.text, fontWeight: "900", fontSize: 13 },
  route: { flexDirection: "row", alignItems: "center", gap: 9 },
  marker: { width: 24, height: 24, borderRadius: 12, backgroundColor: colors.successSoft, alignItems: "center", justifyContent: "center" },
  address: { flex: 1, color: colors.muted, fontSize: 11 },
});
