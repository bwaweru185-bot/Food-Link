import { StyleSheet, Text, View } from "react-native";
import { Button } from "@/components/ui/Button";
import { colors, spacing } from "@/constants/theme";

export function ErrorState({ onRetry }: { onRetry: () => void }) {
  return <View style={styles.box}>
    <Text style={styles.title}>Couldn't load this</Text>
    <Text style={styles.text}>Check your connection and try again.</Text>
    <Button title="Try again" onPress={onRetry} />
  </View>;
}
const styles = StyleSheet.create({
  box: { alignItems: "center", gap: spacing.md, paddingVertical: 48 },
  title: { color: colors.text, fontWeight: "900", fontSize: 17 },
  text: { color: colors.muted, textAlign: "center" },
});
