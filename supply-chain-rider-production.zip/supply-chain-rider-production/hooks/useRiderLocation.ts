import * as Location from "expo-location";
import { useEffect } from "react";
import { sendLocation } from "@/services/jobs";

export function useRiderLocation(enabled: boolean) {
  useEffect(() => {
    if (!enabled) return;

    let mounted = true;
    let subscription: Location.LocationSubscription | null = null;

    (async () => {
      const foreground = await Location.requestForegroundPermissionsAsync();
      if (!mounted || foreground.status !== "granted") return;

      const background = await Location.requestBackgroundPermissionsAsync();
      if (!mounted || background.status !== "granted") return;

      subscription = await Location.watchPositionAsync(
        {
          accuracy: Location.Accuracy.Balanced,
          timeInterval: 10000,
          distanceInterval: 25,
        },
        (position) => {
          const { latitude, longitude, accuracy, heading, speed } = position.coords;
          void sendLocation({
            latitude,
            longitude,
            accuracy: accuracy ?? undefined,
            heading: heading ?? undefined,
            speed: speed ?? undefined,
            recordedAt: new Date(position.timestamp).toISOString(),
          });
        },
      );
    })();

    return () => {
      mounted = false;
      subscription?.remove();
    };
  }, [enabled]);
}
