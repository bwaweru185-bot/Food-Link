import { clearTokens, getAccessToken, getRefreshToken, setTokens } from "@/lib/secure-store";

const API_URL = process.env.EXPO_PUBLIC_API_URL;
if (!API_URL && !__DEV__) throw new Error("EXPO_PUBLIC_API_URL is required in production.");

export class ApiError extends Error {
  constructor(public readonly status: number, message: string, public readonly code?: string) {
    super(message);
    this.name = "ApiError";
  }
}

let refreshPromise: Promise<string | null> | null = null;

async function refreshAccessToken() {
  if (refreshPromise) return refreshPromise;
  refreshPromise = (async () => {
    const refreshToken = await getRefreshToken();
    if (!refreshToken) return null;
    const response = await fetch(`${API_URL ?? "http://localhost:3000"}/v1/auth/rider/refresh`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({ refreshToken }),
    });
    if (!response.ok) {
      await clearTokens();
      return null;
    }
    const data = await response.json() as { accessToken: string; refreshToken?: string };
    await setTokens(data.accessToken, data.refreshToken ?? refreshToken);
    return data.accessToken;
  })().finally(() => { refreshPromise = null; });
  return refreshPromise;
}

export async function api<T>(path: string, options: {
  method?: string;
  body?: unknown;
  auth?: boolean;
  retry?: boolean;
  headers?: Record<string, string>;
} = {}): Promise<T> {
  const auth = options.auth ?? true;
  let token = auth ? await getAccessToken() : null;
  const baseUrl = API_URL ?? "http://localhost:3000";

  const execute = () => fetch(`${baseUrl}${path}`, {
    method: options.method ?? "GET",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      ...(auth && token ? { Authorization: `Bearer ${token}` } : {}),
      ...options.headers,
    },
    body: options.body === undefined ? undefined : JSON.stringify(options.body),
  });

  let response = await execute();
  if (response.status === 401 && auth && (options.retry ?? true)) {
    token = await refreshAccessToken();
    if (token) response = await execute();
  }

  const text = await response.text();
  let data: unknown = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = { message: text }; }

  if (!response.ok) {
    const body = (data ?? {}) as { message?: string; code?: string };
    throw new ApiError(response.status, body.message ?? "Request failed.", body.code);
  }
  return data as T;
}
