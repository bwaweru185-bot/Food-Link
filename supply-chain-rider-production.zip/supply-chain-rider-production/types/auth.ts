export interface Rider {
  id: string;
  name: string;
  phone: string;
  rating: number;
  avatarUrl?: string;
  online: boolean;
}

export interface AuthResponse {
  accessToken: string;
  refreshToken: string;
  user: Rider;
}

export interface LoginInput {
  phone: string;
  password: string;
}
