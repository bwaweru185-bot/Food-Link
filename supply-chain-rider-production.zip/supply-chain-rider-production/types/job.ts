export type JobStatus =
  | "offered"
  | "accepted"
  | "arrived_pickup"
  | "picked_up"
  | "in_transit"
  | "delivered"
  | "rejected"
  | "cancelled";

export interface Customer {
  id: string;
  name: string;
  phone: string;
  avatarUrl?: string;
}

export interface Address {
  line1: string;
  city: string;
  region?: string;
  latitude?: number;
  longitude?: number;
}

export interface DeliveryJob {
  id: string;
  reference: string;
  status: JobStatus;
  foodType: string;
  quantity: string;
  pickup: Address;
  delivery: Address;
  customer: Customer;
  paymentAmount: number;
  currency: string;
  pickupAt: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface LocationPayload {
  latitude: number;
  longitude: number;
  accuracy?: number;
  heading?: number;
  speed?: number;
  recordedAt: string;
}

export interface EarningsSummary {
  currency: string;
  today: number;
  completedTrips: number;
  tripEarnings: number;
  tips: number;
  bonuses: number;
}
