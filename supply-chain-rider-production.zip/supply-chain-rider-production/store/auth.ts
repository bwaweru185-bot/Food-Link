import { create } from "zustand";
import type { Rider } from "@/types/auth";
import { api } from "@/lib/api";
import { clearTokens, getAccessToken, setTokens } from "@/lib/secure-store";

type State = {
  hydrated: boolean;
  token: string | null;
  rider: Rider | null;
  bootstrap: () => Promise<void>;
  setSession: (access: string, refresh: string, rider: Rider) => Promise<void>;
  logout: () => Promise<void>;
};

export const useAuthStore = create<State>((set) => ({
  hydrated: false,
  token: null,
  rider: null,

  bootstrap: async () => {
    const token = await getAccessToken();
    if (!token) return set({ hydrated: true });
    try {
      const rider = await api<Rider>("/v1/rider/me");
      set({ hydrated: true, token, rider });
    } catch {
      await clearTokens();
      set({ hydrated: true, token: null, rider: null });
    }
  },

  setSession: async (access, refresh, rider) => {
    await setTokens(access, refresh);
    set({ hydrated: true, token: access, rider });
  },

  logout: async () => {
    try { await api("/v1/auth/rider/logout", { method: "POST" }); } catch {}
    await clearTokens();
    set({ hydrated: true, token: null, rider: null });
  },
}));
