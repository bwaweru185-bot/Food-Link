import { api } from "@/lib/api";
import type { AuthResponse, LoginInput } from "@/types/auth";

export const login = (input: LoginInput) =>
  api<AuthResponse>("/v1/auth/rider/login", { method: "POST", auth: false, body: input });
