import { api } from "@/lib/api";
import type { EarningsSummary } from "@/types/job";

export const getEarnings = () => api<EarningsSummary>("/v1/rider/earnings");
export const getTrips = () => api<{ items: Array<{ id: string; reference: string; amount: number; currency: string; status: string; completedAt: string }> }>("/v1/rider/trips");
