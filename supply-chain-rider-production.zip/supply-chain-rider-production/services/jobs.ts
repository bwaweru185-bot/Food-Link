import { api } from "@/lib/api";
import type { DeliveryJob, JobStatus, LocationPayload } from "@/types/job";
import type { Paginated } from "@/types/api";

export const listJobs = (status?: JobStatus) =>
  api<Paginated<DeliveryJob>>(`/v1/rider/jobs?page=1&pageSize=20${status ? `&status=${status}` : ""}`);

export const getJob = (id: string) =>
  api<DeliveryJob>(`/v1/rider/jobs/${encodeURIComponent(id)}`);

export const transitionJob = (id: string, action: "accept" | "reject" | "arrived-pickup" | "confirm-pickup" | "start-transit" | "confirm-delivery") =>
  api<DeliveryJob>(`/v1/rider/jobs/${encodeURIComponent(id)}/${action}`, { method: "POST" });

export const sendLocation = (location: LocationPayload) =>
  api("/v1/rider/location", { method: "POST", body: location });
