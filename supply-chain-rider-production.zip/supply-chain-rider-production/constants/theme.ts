export const colors = {
  primary: "#E87500",
  primaryDark: "#C65E00",
  background: "#F7F8F7",
  surface: "#FFFFFF",
  text: "#18241F",
  muted: "#748079",
  border: "#DFE4E1",
  success: "#159447",
  successSoft: "#E8F6EE",
  danger: "#D92D20",
  dangerSoft: "#FEECEB",
  white: "#FFFFFF",
  black: "#000000",
} as const;

export const spacing = { xs: 4, sm: 8, md: 12, lg: 16, xl: 24, xxl: 32 } as const;
export const radius = { sm: 8, md: 12, lg: 18, pill: 999 } as const;
