import { createHash, randomBytes } from "node:crypto";
import argon2 from "argon2";
import { SignJWT, jwtVerify } from "jose";
import { prisma } from "./db.js";
import { env } from "./config.js";
import { AppError } from "./errors.js";

const accessSecret = new TextEncoder().encode(env.ACCESS_TOKEN_SECRET);
const refreshSecret = new TextEncoder().encode(env.REFRESH_TOKEN_SECRET);

export type AuthUser = {
  id: string;
  role: "CUSTOMER" | "VENDOR" | "RIDER" | "ADMIN" | "SUPPORT" | "FINANCE";
};

export async function hashPassword(password: string): Promise<string> {
  return argon2.hash(password);
}

export async function verifyPassword(hash: string, password: string): Promise<boolean> {
  return argon2.verify(hash, password);
}

export async function issueTokens(user: AuthUser) {
  const sessionId = randomBytes(24).toString("hex");
  const accessToken = await new SignJWT({ role: user.role, sessionId })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuer(env.JWT_ISSUER)
    .setAudience(env.JWT_AUDIENCE)
    .setSubject(user.id)
    .setIssuedAt()
    .setExpirationTime(env.ACCESS_TOKEN_TTL)
    .sign(accessSecret);

  const refreshToken = await new SignJWT({ role: user.role, sessionId })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuer(env.JWT_ISSUER)
    .setAudience(env.JWT_AUDIENCE)
    .setSubject(user.id)
    .setIssuedAt()
    .setExpirationTime(env.REFRESH_TOKEN_TTL)
    .sign(refreshSecret);

  await prisma.refreshSession.create({
    data: {
      id: sessionId,
      userId: user.id,
      tokenHash: createHash("sha256").update(refreshToken).digest("hex"),
      expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
    }
  });

  return { accessToken, refreshToken };
}

export async function verifyAccessToken(token: string): Promise<AuthUser> {
  try {
    const { payload } = await jwtVerify(token, accessSecret, {
      issuer: env.JWT_ISSUER,
      audience: env.JWT_AUDIENCE
    });
    if (!payload.sub || typeof payload.role !== "string") throw new Error("invalid claims");
    return { id: payload.sub, role: payload.role as AuthUser["role"] };
  } catch {
    throw new AppError("UNAUTHORIZED", "Authentication required.", 401);
  }
}

export async function rotateRefreshToken(refreshToken: string) {
  try {
    const { payload } = await jwtVerify(refreshToken, refreshSecret, {
      issuer: env.JWT_ISSUER,
      audience: env.JWT_AUDIENCE
    });
    if (!payload.sub || typeof payload.sessionId !== "string" || typeof payload.role !== "string") {
      throw new Error("invalid claims");
    }

    const tokenHash = createHash("sha256").update(refreshToken).digest("hex");
    const session = await prisma.refreshSession.findFirst({
      where: { id: payload.sessionId, tokenHash, userId: payload.sub, revokedAt: null }
    });
    if (!session || session.expiresAt <= new Date()) throw new Error("revoked");

    await prisma.refreshSession.update({
      where: { id: session.id },
      data: { revokedAt: new Date() }
    });

    return issueTokens({ id: payload.sub, role: payload.role as AuthUser["role"] });
  } catch {
    throw new AppError("UNAUTHORIZED", "Invalid refresh session.", 401);
  }
}

export async function revokeRefreshToken(refreshToken: string): Promise<void> {
  const tokenHash = createHash("sha256").update(refreshToken).digest("hex");
  await prisma.refreshSession.updateMany({
    where: { tokenHash, revokedAt: null },
    data: { revokedAt: new Date() }
  });
}
