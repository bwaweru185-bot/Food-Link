import type { FastifyInstance, FastifyRequest } from "fastify";
import { z } from "zod";
import { prisma } from "../db.js";
import { verifyAccessToken } from "../auth.js";
import { AppError } from "../errors.js";
import { assertOrderTransition } from "../order-state.js";

const createOrderSchema = z.object({
  vendorId: z.string().min(1),
  storeId: z.string().min(1),
  deliveryAddressId: z.string().min(1),
  items: z.array(z.object({ menuItemId: z.string().min(1), quantity: z.number().int().positive().max(50) })).min(1),
  idempotencyKey: z.string().min(8).max(128)
});

async function requireCustomer(request: FastifyRequest) {
  const header = request.headers.authorization;
  if (!header?.startsWith("Bearer ")) throw new AppError("UNAUTHORIZED", "Authentication required.", 401);
  const auth = await verifyAccessToken(header.slice(7));
  if (auth.role !== "CUSTOMER") throw new AppError("FORBIDDEN", "Customer access required.", 403);
  return auth;
}

export async function orderRoutes(app: FastifyInstance) {
  app.get("/v1/orders", async (request) => {
    const auth = await requireCustomer(request);
    const query = z.object({ limit: z.coerce.number().int().min(1).max(100).default(25) }).parse(request.query);
    return prisma.order.findMany({
      where: { customerId: auth.id },
      orderBy: { createdAt: "desc" },
      take: query.limit,
      include: { items: true, deliveryJob: true }
    });
  });

  app.post("/v1/orders", async (request) => {
    const auth = await requireCustomer(request);
    const input = createOrderSchema.parse(request.body);

    const existing = await prisma.order.findFirst({
      where: { customerId: auth.id, idempotencyKey: input.idempotencyKey }
    });
    if (existing) return existing;

    const address = await prisma.address.findFirst({
      where: { id: input.deliveryAddressId, customerId: auth.id }
    });
    if (!address) throw new AppError("ADDRESS_NOT_FOUND", "Delivery address not found.", 404);

    const store = await prisma.store.findFirst({
      where: { id: input.storeId, vendorId: input.vendorId, vendor: { status: "ACTIVE" } },
      include: { categories: { include: { items: true } } }
    });
    if (!store) throw new AppError("STORE_NOT_FOUND", "Store is not available.", 404);

    const menu = new Map(store.categories.flatMap((c) => c.items).map((item) => [item.id, item]));
    const orderItems = input.items.map((line) => {
      const item = menu.get(line.menuItemId);
      if (!item || !item.isAvailable) throw new AppError("MENU_ITEM_UNAVAILABLE", "One or more items are unavailable.", 409);
      return {
        menuItemId: item.id,
        nameSnapshot: item.name,
        unitPriceMinor: item.priceMinor,
        quantity: line.quantity,
        lineTotalMinor: item.priceMinor * line.quantity
      };
    });

    const subtotalMinor = orderItems.reduce((sum, item) => sum + item.lineTotalMinor, 0);
    const deliveryFeeMinor = 0;
    const serviceFeeMinor = Math.round(subtotalMinor * 0.05);
    const totalMinor = subtotalMinor + deliveryFeeMinor + serviceFeeMinor;

    return prisma.$transaction(async (tx) => {
      const order = await tx.order.create({
        data: {
          customerId: auth.id,
          vendorId: input.vendorId,
          storeId: input.storeId,
          deliveryAddressId: address.id,
          status: "CONFIRMED",
          subtotalMinor,
          deliveryFeeMinor,
          serviceFeeMinor,
          totalMinor,
          currency: "USD",
          idempotencyKey: input.idempotencyKey,
          items: { create: orderItems },
          statusHistory: { create: { to: "CONFIRMED", actorId: auth.id, reason: "order_created" } },
          payment: { create: { amountMinor: totalMinor, currency: "USD", status: "PENDING" } },
          deliveryJob: { create: { status: "UNASSIGNED" } }
        },
        include: { items: true, payment: true, deliveryJob: true }
      });
      return order;
    });
  });

  app.post("/v1/orders/:id/status", async (request) => {
    const authHeader = request.headers.authorization;
    if (!authHeader?.startsWith("Bearer ")) throw new AppError("UNAUTHORIZED", "Authentication required.", 401);
    const auth = await verifyAccessToken(authHeader.slice(7));
    const params = z.object({ id: z.string() }).parse(request.params);
    const body = z.object({ to: z.enum(["ACCEPTED","PREPARING","READY_FOR_PICKUP","CANCELLED"]) }).parse(request.body);

    const order = await prisma.order.findUnique({ where: { id: params.id } });
    if (!order) throw new AppError("ORDER_NOT_FOUND", "Order not found.", 404);
    if (auth.role === "CUSTOMER" && order.customerId !== auth.id) throw new AppError("FORBIDDEN", "Not allowed.", 403);
    if (auth.role === "CUSTOMER" && body.to !== "CANCELLED") throw new AppError("FORBIDDEN", "Customers cannot perform this transition.", 403);

    assertOrderTransition(order.status, body.to);
    return prisma.$transaction(async (tx) => {
      const updated = await tx.order.update({
        where: { id: order.id },
        data: { status: body.to, statusHistory: { create: { from: order.status, to: body.to, actorId: auth.id } } }
      });
      await tx.auditEvent.create({
        data: { actorId: auth.id, action: "ORDER_STATUS_CHANGED", entityType: "Order", entityId: order.id, metadata: { from: order.status, to: body.to } }
      });
      return updated;
    });
  });
}
