import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { prisma } from "../db.js";
import { verifyAccessToken } from "../auth.js";
import { AppError } from "../errors.js";

async function riderAuth(request: any) {
  const h = request.headers.authorization;
  if (!h?.startsWith("Bearer ")) throw new AppError("UNAUTHORIZED", "Authentication required.", 401);
  const auth = await verifyAccessToken(h.slice(7));
  if (auth.role !== "RIDER") throw new AppError("FORBIDDEN", "Rider access required.", 403);
  const rider = await prisma.riderProfile.findUnique({ where: { userId: auth.id } });
  if (!rider || rider.status !== "ACTIVE") throw new AppError("FORBIDDEN", "Rider account unavailable.", 403);
  return rider;
}

export async function riderRoutes(app: FastifyInstance) {
  app.get("/v1/rider/jobs", async (request) => {
    const rider = await riderAuth(request);
    return prisma.deliveryJob.findMany({
      where: { riderId: rider.id },
      orderBy: { createdAt: "desc" },
      take: 100,
      include: { order: { include: { store: true, deliveryAddress: true, items: true } } }
    });
  });

  app.get("/v1/rider/jobs/:id", async (request) => {
    const rider = await riderAuth(request);
    const params = z.object({ id: z.string() }).parse(request.params);
    const job = await prisma.deliveryJob.findFirst({ where: { id: params.id, riderId: rider.id }, include: { order: { include: { store: true, deliveryAddress: true, items: true } }, events: true } });
    if (!job) throw new AppError("JOB_NOT_FOUND", "Delivery job not found.", 404);
    return job;
  });

  app.post("/v1/rider/jobs/:id/accept", async (request) => {
    const rider = await riderAuth(request);
    const params = z.object({ id: z.string() }).parse(request.params);
    const job = await prisma.deliveryJob.findFirst({ where: { id: params.id, riderId: rider.id, status: "OFFERED" } });
    if (!job) throw new AppError("JOB_UNAVAILABLE", "Job is no longer available.", 409);
    return prisma.deliveryJob.update({ where: { id: job.id }, data: { status: "ACCEPTED", acceptedAt: new Date(), events: { create: { type: "ACCEPTED" } } } });
  });

  app.post("/v1/rider/jobs/:id/location", async (request) => {
    const rider = await riderAuth(request);
    const body = z.object({ latitude: z.number().gte(-90).lte(90), longitude: z.number().gte(-180).lte(180), accuracyM: z.number().nonnegative().optional(), recordedAt: z.coerce.date() }).parse(request.body);
    return prisma.locationPing.create({ data: { riderId: rider.id, ...body } });
  });
}
