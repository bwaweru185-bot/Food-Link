import type { FastifyInstance } from "fastify";
import { prisma } from "../db.js";
import { verifyAccessToken } from "../auth.js";
import { AppError } from "../errors.js";

export async function meRoutes(app: FastifyInstance) {
  app.get("/v1/me", async (request) => {
    const header = request.headers.authorization;
    if (!header?.startsWith("Bearer ")) throw new AppError("UNAUTHORIZED", "Authentication required.", 401);
    const auth = await verifyAccessToken(header.slice(7));
    const user = await prisma.user.findUnique({
      where: { id: auth.id },
      select: { id: true, email: true, phone: true, role: true, status: true }
    });
    if (!user || user.status !== "ACTIVE") throw new AppError("UNAUTHORIZED", "Account unavailable.", 401);
    return user;
  });
}
