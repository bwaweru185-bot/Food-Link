import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { prisma } from "../db.js";
import { AppError } from "../errors.js";
import { issueTokens, revokeRefreshToken, rotateRefreshToken, verifyPassword } from "../auth.js";

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8).max(200)
});

export async function authRoutes(app: FastifyInstance) {
  app.post("/v1/auth/login", async (request, reply) => {
    const input = loginSchema.parse(request.body);
    const user = await prisma.user.findUnique({ where: { email: input.email.toLowerCase() } });
    if (!user || user.status !== "ACTIVE" || !(await verifyPassword(user.passwordHash, input.password))) {
      throw new AppError("INVALID_CREDENTIALS", "Invalid email or password.", 401);
    }

    const tokens = await issueTokens({ id: user.id, role: user.role });
    return reply.send(tokens);
  });

  app.post("/v1/auth/refresh", async (request) => {
    const body = z.object({ refreshToken: z.string().min(20) }).parse(request.body);
    return rotateRefreshToken(body.refreshToken);
  });

  app.post("/v1/auth/logout", async (request) => {
    const body = z.object({ refreshToken: z.string().min(20) }).parse(request.body);
    await revokeRefreshToken(body.refreshToken);
    return { ok: true };
  });
}
