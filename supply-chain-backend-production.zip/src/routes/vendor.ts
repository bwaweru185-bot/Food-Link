import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { prisma } from "../db.js";
import { verifyAccessToken } from "../auth.js";
import { AppError } from "../errors.js";
import { assertOrderTransition } from "../order-state.js";

async function vendorAuth(request: any) {
  const h = request.headers.authorization;
  if (!h?.startsWith("Bearer ")) throw new AppError("UNAUTHORIZED", "Authentication required.", 401);
  const auth = await verifyAccessToken(h.slice(7));
  if (auth.role !== "VENDOR") throw new AppError("FORBIDDEN", "Vendor access required.", 403);
  const staff = await prisma.vendorStaff.findUnique({ where: { userId: auth.id } });
  if (!staff) throw new AppError("FORBIDDEN", "Vendor profile not configured.", 403);
  return { auth, vendorId: staff.vendorId };
}

export async function vendorRoutes(app: FastifyInstance) {
  app.get("/v1/vendor/store", async (request) => {
    const { vendorId } = await vendorAuth(request);
    return prisma.store.findFirst({ where: { vendorId }, include: { categories: { include: { items: true } }, businessHours: true } });
  });

  app.patch("/v1/vendor/store/open-state", async (request) => {
    const { vendorId } = await vendorAuth(request);
    const body = z.object({ isOpen: z.boolean() }).parse(request.body);
    return prisma.store.updateMany({ where: { vendorId }, data: { isOpen: body.isOpen } });
  });

  app.get("/v1/vendor/orders", async (request) => {
    const { vendorId } = await vendorAuth(request);
    return prisma.order.findMany({
      where: { vendorId },
      orderBy: { createdAt: "desc" },
      take: 100,
      include: { items: true, deliveryJob: { include: { rider: true } } }
    });
  });

  app.post("/v1/vendor/orders/:id/status", async (request) => {
    const { auth, vendorId } = await vendorAuth(request);
    const params = z.object({ id: z.string() }).parse(request.params);
    const body = z.object({ to: z.enum(["ACCEPTED","PREPARING","READY_FOR_PICKUP","CANCELLED"]) }).parse(request.body);
    const order = await prisma.order.findFirst({ where: { id: params.id, vendorId } });
    if (!order) throw new AppError("ORDER_NOT_FOUND", "Order not found.", 404);
    assertOrderTransition(order.status, body.to);
    return prisma.$transaction(async (tx) => {
      const updated = await tx.order.update({
        where: { id: order.id },
        data: { status: body.to, statusHistory: { create: { from: order.status, to: body.to, actorId: auth.id } } }
      });
      await tx.auditEvent.create({ data: { actorId: auth.id, action: "VENDOR_ORDER_STATUS_CHANGED", entityType: "Order", entityId: order.id, metadata: { to: body.to } } });
      return updated;
    });
  });
}
