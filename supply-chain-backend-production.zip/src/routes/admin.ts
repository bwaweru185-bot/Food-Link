import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { prisma } from "../db.js";
import { verifyAccessToken } from "../auth.js";
import { AppError } from "../errors.js";
import { assertOrderTransition } from "../order-state.js";

async function requireAdmin(request: any) {
  const header = request.headers.authorization;
  if (!header?.startsWith("Bearer ")) throw new AppError("UNAUTHORIZED", "Authentication required.", 401);
  const auth = await verifyAccessToken(header.slice(7));
  if (!["ADMIN", "SUPPORT", "FINANCE"].includes(auth.role)) throw new AppError("FORBIDDEN", "Admin access required.", 403);
  return auth;
}

export async function adminRoutes(app: FastifyInstance) {
  app.get("/v1/admin/dashboard", async (request) => {
    await requireAdmin(request);
    const [orders, vendors, riders, pendingPayouts] = await Promise.all([
      prisma.order.count(),
      prisma.vendor.count({ where: { status: "ACTIVE" } }),
      prisma.riderProfile.count({ where: { status: "ACTIVE" } }),
      prisma.payout.count({ where: { status: "PENDING" } })
    ]);
    return { orders, activeVendors: vendors, activeRiders: riders, pendingPayouts };
  });

  app.get("/v1/admin/orders", async (request) => {
    await requireAdmin(request);
    const q = z.object({
      status: z.string().optional(),
      limit: z.coerce.number().int().min(1).max(100).default(50)
    }).parse(request.query);
    return prisma.order.findMany({
      where: q.status ? { status: q.status as any } : undefined,
      orderBy: { createdAt: "desc" },
      take: q.limit,
      include: { vendor: true, store: true, deliveryJob: { include: { rider: true } } }
    });
  });

  app.post("/v1/admin/orders/:id/cancel", async (request) => {
    const auth = await requireAdmin(request);
    const params = z.object({ id: z.string() }).parse(request.params);
    const body = z.object({ reason: z.string().min(3).max(500) }).parse(request.body);
    const order = await prisma.order.findUnique({ where: { id: params.id } });
    if (!order) throw new AppError("ORDER_NOT_FOUND", "Order not found.", 404);
    assertOrderTransition(order.status, "CANCELLED");

    return prisma.$transaction(async (tx) => {
      const updated = await tx.order.update({
        where: { id: order.id },
        data: { status: "CANCELLED", statusHistory: { create: { from: order.status, to: "CANCELLED", actorId: auth.id, reason: body.reason } } }
      });
      await tx.auditEvent.create({
        data: { actorId: auth.id, action: "ADMIN_ORDER_CANCELLED", entityType: "Order", entityId: order.id, metadata: { reason: body.reason } }
      });
      return updated;
    });
  });

  app.post("/v1/admin/orders/:id/assign-rider", async (request) => {
    const auth = await requireAdmin(request);
    const params = z.object({ id: z.string() }).parse(request.params);
    const body = z.object({ riderId: z.string() }).parse(request.body);

    return prisma.$transaction(async (tx) => {
      const job = await tx.deliveryJob.findUnique({ where: { orderId: params.id } });
      const rider = await tx.riderProfile.findFirst({ where: { id: body.riderId, status: "ACTIVE" } });
      if (!job || !rider) throw new AppError("ASSIGNMENT_UNAVAILABLE", "Order or rider is unavailable.", 409);
      const order = await tx.order.findUnique({ where: { id: params.id } });
      if (!order) throw new AppError("ORDER_NOT_FOUND", "Order not found.", 404);
      assertOrderTransition(order.status, "RIDER_ASSIGNED");

      await tx.deliveryJob.update({
        where: { id: job.id },
        data: { riderId: rider.id, status: "OFFERED", assignedAt: new Date(), events: { create: { type: "ASSIGNED", metadata: { actorId: auth.id } } } }
      });
      return tx.order.update({
        where: { id: order.id },
        data: { status: "RIDER_ASSIGNED", statusHistory: { create: { from: order.status, to: "RIDER_ASSIGNED", actorId: auth.id } } }
      });
    });
  });

  app.get("/v1/admin/audit-events", async (request) => {
    await requireAdmin(request);
    return prisma.auditEvent.findMany({ orderBy: { createdAt: "desc" }, take: 100 });
  });
}
