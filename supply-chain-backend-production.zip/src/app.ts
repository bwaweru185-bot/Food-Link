import Fastify from "fastify";
import cors from "@fastify/cors";
import helmet from "@fastify/helmet";
import rateLimit from "@fastify/rate-limit";
import swagger from "@fastify/swagger";
import swaggerUi from "@fastify/swagger-ui";
import { ZodError } from "zod";
import { env, corsOrigins } from "./config.js";
import { healthRoutes } from "./routes/health.js";
import { authRoutes } from "./routes/auth.js";
import { meRoutes } from "./routes/me.js";
import { orderRoutes } from "./routes/orders.js";
import { vendorRoutes } from "./routes/vendor.js";
import { riderRoutes } from "./routes/rider.js";
import { adminRoutes } from "./routes/admin.js";
import { AppError } from "./errors.js";

export async function buildApp() {
  const app = Fastify({
    logger: { level: env.LOG_LEVEL },
    requestIdHeader: "x-request-id",
    disableRequestLogging: false
  });

  await app.register(helmet);
  await app.register(cors, { origin: corsOrigins, credentials: true });
  await app.register(rateLimit, { max: 300, timeWindow: "1 minute" });

  await app.register(swagger, {
    openapi: {
      info: { title: "Supply Chain Platform API", version: "1.0.0" },
      servers: [{ url: `http://localhost:${env.PORT}` }],
      tags: [
        { name: "health" }, { name: "auth" }, { name: "orders" },
        { name: "vendor" }, { name: "rider" }, { name: "admin" }
      ]
    }
  });
  await app.register(swaggerUi, { routePrefix: "/docs" });

  app.setErrorHandler((error, request, reply) => {
    if (error instanceof ZodError) {
      return reply.code(400).send({
        error: { code: "VALIDATION_ERROR", message: "Request validation failed.", requestId: request.id, details: error.issues }
      });
    }
    if (error instanceof AppError) {
      return reply.code(error.statusCode).send({ error: { code: error.code, message: error.message, requestId: request.id } });
    }
    request.log.error({ err: error }, "unhandled_request_error");
    return reply.code(500).send({ error: { code: "INTERNAL_ERROR", message: "Internal server error.", requestId: request.id } });
  });

  await app.register(healthRoutes);
  await app.register(authRoutes);
  await app.register(meRoutes);
  await app.register(orderRoutes);
  await app.register(vendorRoutes);
  await app.register(riderRoutes);
  await app.register(adminRoutes);

  return app;
}
