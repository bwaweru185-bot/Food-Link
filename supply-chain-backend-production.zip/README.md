# Supply Chain Platform API

Production-oriented TypeScript backend foundation for the customer, food-vendor, rider and admin applications.

## Stack

- Fastify 5 + TypeScript strict mode
- PostgreSQL + Prisma
- Redis-ready infrastructure
- Argon2 password hashing
- JWT access/refresh sessions with refresh-token rotation
- Zod request validation
- Helmet, CORS and rate limiting
- OpenAPI/Swagger UI
- Central server-authoritative order state machine
- Transactional audit events
- Idempotency key model
- Docker Compose for local infrastructure
- Vitest

## What is implemented

### Identity
- One user identity model with explicit application roles.
- Password hashing with Argon2.
- Short-lived access tokens.
- Rotating refresh sessions stored as hashes.
- Account status enforcement.

### Customer
- `/v1/me`
- `/v1/orders`
- Transactional order creation.
- Menu availability validation.
- Integer minor-unit money arithmetic.
- Customer ownership checks.
- Idempotency key field.
- Order cancellation path.

### Vendor
- Store retrieval.
- Store open/closed control.
- Incoming order list.
- Vendor-owned order status transitions.
- Audit events.

### Rider
- Assigned job list/detail.
- Job acceptance.
- Location pings.
- Rider ownership/status checks.

### Admin
- Operational dashboard.
- Order monitoring.
- Rider assignment.
- Order cancellation with reason.
- Audit log.

## Run locally

1. Copy `.env.example` to `.env`.
2. Start infrastructure:

```bash
docker compose up -d
```

3. Install dependencies:

```bash
npm install
```

4. Generate Prisma client:

```bash
npm run prisma:generate
```

5. Create the database schema:

```bash
npm run prisma:migrate
```

6. Start the API:

```bash
npm run dev
```

API: `http://localhost:4000`

OpenAPI UI: `http://localhost:4000/docs`

## Required production work before launch

This repository is intentionally the shared backend foundation, not a claim that external production services are configured.

Before production deployment:

- Use a managed PostgreSQL service with encrypted connections and backups.
- Use Redis for queues, rate-limit coordination and distributed jobs.
- Replace local JWT secrets with a managed secret store and rotate them.
- Prefer secure, httpOnly, same-site refresh cookies for browser admin sessions.
- Add MFA/WebAuthn for privileged admin and finance roles.
- Integrate the actual payment processor and verify webhooks cryptographically.
- Add payment/refund/reconciliation workflows.
- Add object storage and signed URLs for rider/vendor documents and proof of delivery.
- Add a real dispatch engine/geospatial service.
- Add notification workers for push, email and SMS.
- Add an outbox table/worker so domain events are not lost after DB commits.
- Add optimistic locking/version columns to high-contention aggregates.
- Add cursor pagination and server-side filtering to every large collection.
- Add request-id propagation into logs/traces.
- Add OpenTelemetry/APM, metrics and alerting.
- Add WAF/API gateway rules and stricter per-route rate limits.
- Add authorization tests for every role and ownership boundary.
- Add integration/e2e tests against disposable PostgreSQL/Redis.
- Add CI/CD, migrations as a deployment step, image scanning and dependency auditing.
- Review all retention, privacy, deletion and financial-record requirements for the target jurisdiction.

## Domain rule

All four apps should consume this backend's order state machine. The client applications may display actions, but the server must decide whether a transition is valid.

Financial values are represented as integer minor units. Do not use JavaScript floating point values for money.

Admin mutations must create audit records. Payouts, refunds, payments and other financial operations should use idempotency keys and transactional state changes.

## API contract expected by the existing apps

The mobile/web applications can be pointed at this API base URL. The original app foundations should be updated to use these shared endpoints rather than separate application-specific business logic.

The next backend modules to add are payments, notifications/outbox, dispatch, catalog management, support, promotions, reconciliation and reporting.
