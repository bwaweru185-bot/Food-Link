import { describe, expect, it } from "vitest";
import { assertOrderTransition } from "../src/order-state.js";

describe("order state machine", () => {
  it("allows confirmed -> accepted", () => {
    expect(() => assertOrderTransition("CONFIRMED", "ACCEPTED")).not.toThrow();
  });

  it("rejects delivered -> preparing", () => {
    expect(() => assertOrderTransition("DELIVERED", "PREPARING")).toThrow();
  });
});
