# Backend architecture

```text
Customer App ─┐
Vendor App   ─┼── HTTPS ──> API ──> PostgreSQL
Rider App    ─┤              │
Admin Web    ─┘              ├──> Redis / queues
                             ├──> Payment provider
                             ├──> Push / email / SMS
                             ├──> Object storage
                             └──> Maps / geospatial services
```

## Boundaries

- Identity/authentication
- Customer
- Vendor/catalog
- Orders
- Dispatch/rider
- Payments
- Payouts
- Notifications
- Administration
- Audit
- Reporting

## Invariants

1. Every order transition is validated server-side.
2. An actor may only mutate resources they are authorized to mutate.
3. Money uses integer minor units.
4. Mutating financial/operational commands should be idempotent.
5. Every privileged intervention is auditable.
6. External side effects should be triggered from durable outbox events.
7. Background work must be retryable and observable.
