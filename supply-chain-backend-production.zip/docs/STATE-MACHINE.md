# Order state machine

```text
PENDING_PAYMENT -> CONFIRMED -> ACCEPTED -> PREPARING
                                      |
                                      v
                              READY_FOR_PICKUP
                                      |
                                      v
                               RIDER_ASSIGNED
                                      |
                                      v
                                  PICKED_UP
                                      |
                                      v
                                  IN_TRANSIT
                                      |
                                      v
                                  DELIVERED

Cancellation is allowed only from explicitly permitted states.
Refund is a separate financial transition.
```

Do not implement a client-side-only status switch. The API validates the transition and records a status-history row in the same transaction.
