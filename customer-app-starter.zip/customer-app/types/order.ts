export type OrderStatus =
  | "created"
  | "accepted"
  | "preparing"
  | "ready_for_pickup"
  | "picked_up"
  | "in_transit"
  | "delivered"
  | "cancelled";

export interface Order {
  id: string;
  foodType: string;
  quantity: string;
  pickupAddress: string;
  deliveryAddress: string;
  status: OrderStatus;
  total: number;
  createdAt: string;
  eta?: string;
}

export interface CreateOrderInput {
  foodType: string;
  quantity: string;
  pickupAddress: string;
  deliveryAddress: string;
  pickupDate: string;
  pickupTime: string;
  contactPhone: string;
  specialInstructions?: string;
}
