import { api } from "@/lib/api";
import type { CreateOrderInput, Order } from "@/types/order";

export function getRecentOrders(token: string) {
  return api<Order[]>("/customer/orders?limit=3", { token });
}

export function createOrder(token: string, input: CreateOrderInput) {
  return api<Order>("/customer/orders", {
    method: "POST",
    token,
    body: JSON.stringify(input),
  });
}
