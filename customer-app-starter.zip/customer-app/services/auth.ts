import { api } from "@/lib/api";
import type { AuthResponse, LoginInput } from "@/types/auth";

export function login(input: LoginInput) {
  return api<AuthResponse>("/auth/customer/login", {
    method: "POST",
    body: JSON.stringify(input),
  });
}
