import { Pressable, StyleSheet, Text, View } from "react-native";
import type { Order } from "@/types/order";
import { colors, radius, spacing } from "@/constants/theme";

export function OrderCard({
  order,
  onPress,
}: {
  order: Order;
  onPress?: () => void;
}) {
  return (
    <Pressable onPress={onPress} style={styles.card}>
      <View style={styles.row}>
        <View style={styles.icon}>
          <Text>🍲</Text>
        </View>
        <View style={styles.body}>
          <Text style={styles.title}>{order.foodType}</Text>
          <Text style={styles.meta}>{order.quantity}</Text>
          <Text style={styles.status}>{formatStatus(order.status)}</Text>
        </View>
        <Text style={styles.total}>${order.total.toFixed(2)}</Text>
      </View>
    </Pressable>
  );
}

function formatStatus(status: Order["status"]) {
  return status.replaceAll("_", " ").replace(/\b\w/g, (c) => c.toUpperCase());
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  row: { flexDirection: "row", alignItems: "center", gap: spacing.md },
  icon: {
    width: 48,
    height: 48,
    borderRadius: radius.md,
    backgroundColor: colors.primarySoft,
    alignItems: "center",
    justifyContent: "center",
  },
  body: { flex: 1, gap: 3 },
  title: { color: colors.text, fontWeight: "700", fontSize: 14 },
  meta: { color: colors.muted, fontSize: 12 },
  status: { color: colors.primary, fontSize: 11, fontWeight: "700" },
  total: { color: colors.text, fontWeight: "700" },
});
