import { Platform } from "react-native";

const API_URL = process.env.EXPO_PUBLIC_API_URL;

if (!API_URL && !__DEV__) {
  throw new Error("EXPO_PUBLIC_API_URL is required in production.");
}

export class ApiError extends Error {
  constructor(
    public status: number,
    message: string,
    public details?: unknown,
  ) {
    super(message);
    this.name = "ApiError";
  }
}

type RequestOptions = RequestInit & {
  token?: string | null;
};

export async function api<T>(
  path: string,
  options: RequestOptions = {},
): Promise<T> {
  const baseUrl = API_URL ?? "http://localhost:3000";
  const { token, headers, ...init } = options;

  const response = await fetch(`${baseUrl}${path}`, {
    ...init,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      "X-Client-Platform": Platform.OS,
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...headers,
    },
  });

  const text = await response.text();
  const data = text ? JSON.parse(text) : null;

  if (!response.ok) {
    throw new ApiError(
      response.status,
      data?.message ?? "Something went wrong.",
      data,
    );
  }

  return data as T;
}
