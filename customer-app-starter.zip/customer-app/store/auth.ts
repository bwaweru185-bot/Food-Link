import { create } from "zustand";
import type { User } from "@/types/auth";
import {
  clearAccessToken,
  getAccessToken,
  setAccessToken,
} from "@/lib/secure-store";

type AuthState = {
  user: User | null;
  token: string | null;
  hydrated: boolean;
  setSession: (token: string, user: User) => Promise<void>;
  restoreSession: () => Promise<void>;
  logout: () => Promise<void>;
};

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  token: null,
  hydrated: false,

  setSession: async (token, user) => {
    await setAccessToken(token);
    set({ token, user, hydrated: true });
  },

  restoreSession: async () => {
    const token = await getAccessToken();
    // User profile should be restored from GET /me in the next backend integration step.
    set({ token, hydrated: true });
  },

  logout: async () => {
    await clearAccessToken();
    set({ token: null, user: null, hydrated: true });
  },
}));
