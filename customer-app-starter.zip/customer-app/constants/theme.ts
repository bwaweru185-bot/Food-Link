export const colors = {
  primary: "#07883F",
  primaryDark: "#006B32",
  primarySoft: "#E8F7EE",
  orange: "#F47B00",
  background: "#F7F9F8",
  surface: "#FFFFFF",
  text: "#102A22",
  muted: "#6D7D76",
  border: "#DDE5E1",
  danger: "#D92D20",
  success: "#149447",
} as const;

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 32,
} as const;

export const radius = {
  sm: 8,
  md: 12,
  lg: 18,
  pill: 999,
} as const;
