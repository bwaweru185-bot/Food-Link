# Supply Chain — Customer App

Production-oriented React Native customer application for food transportation.

## Stack

- Expo SDK 57 + Expo Router
- TypeScript
- TanStack Query for server state
- Zustand for client/session state
- React Hook Form + Zod for forms
- Expo Secure Store for auth tokens

## Run

```bash
npm install
npx expo start
```

Before connecting the backend:

```bash
cp .env.example .env
```

Set `EXPO_PUBLIC_API_URL` to your API.

## Quality checks

```bash
npm run typecheck
npm run lint
```

## Current customer flow

Welcome → Login → Dashboard → Send Food → Pickup & Delivery → Confirm & Pay

The remaining production modules should be connected to the backend in the next steps:
tracking, payments, notifications, order history, messaging, profile, addresses, and reviews.
