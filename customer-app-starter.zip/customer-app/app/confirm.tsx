import { router, useLocalSearchParams } from "expo-router";
import { StyleSheet, Text, View } from "react-native";
import { Button } from "@/components/ui/Button";
import { Screen } from "@/components/ui/Screen";
import { colors, radius, spacing } from "@/constants/theme";

export default function ConfirmScreen() {
  const params = useLocalSearchParams<{ orderId?: string; total?: string }>();
  const total = Number(params.total ?? 0);

  return (
    <Screen>
      <Text style={styles.title}>Confirm & Pay</Text>

      <View style={styles.card}>
        <Text style={styles.item}>🍲 Fufu & Light Soup</Text>
        <Text style={styles.meta}>2 kg</Text>
      </View>

      <View style={styles.summary}>
        <Row label="Pickup Fee" value="$3.00" />
        <Row label="Delivery Fee" value="$5.00" />
        <Row label="Service Fee" value="$1.00" />
        <View style={styles.divider} />
        <Row label="Total" value={`$${total || "9.00"}`} bold />
      </View>

      <Text style={styles.paymentTitle}>Payment Method</Text>
      <View style={styles.payment}>
        <Text style={styles.paymentText}>Mobile Money</Text>
        <Text style={styles.chevron}>›</Text>
      </View>

      <Button
        title="Pay Now"
        onPress={() =>
          router.replace({
            pathname: "/track",
            params: { orderId: params.orderId ?? "" },
          })
        }
      />
    </Screen>
  );
}

function Row({
  label,
  value,
  bold = false,
}: {
  label: string;
  value: string;
  bold?: boolean;
}) {
  return (
    <View style={styles.row}>
      <Text style={[styles.label, bold && styles.bold]}>{label}</Text>
      <Text style={[styles.value, bold && styles.bold]}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  title: { fontSize: 25, fontWeight: "800", color: colors.text },
  card: {
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    padding: spacing.lg,
    borderWidth: 1,
    borderColor: colors.border,
  },
  item: { color: colors.text, fontWeight: "700" },
  meta: { color: colors.muted, marginTop: 4 },
  summary: {
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    padding: spacing.lg,
    gap: spacing.md,
  },
  row: { flexDirection: "row", justifyContent: "space-between" },
  label: { color: colors.muted },
  value: { color: colors.text },
  bold: { fontWeight: "800", color: colors.text },
  divider: { height: 1, backgroundColor: colors.border },
  paymentTitle: { color: colors.text, fontWeight: "700" },
  payment: {
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    padding: spacing.lg,
    flexDirection: "row",
    justifyContent: "space-between",
  },
  paymentText: { color: colors.text, fontWeight: "600" },
  chevron: { color: colors.muted, fontSize: 22 },
});
