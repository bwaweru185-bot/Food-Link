import { router } from "expo-router";
import { StyleSheet, Text, View } from "react-native";
import { Button } from "@/components/ui/Button";
import { colors, spacing } from "@/constants/theme";

export default function WelcomeScreen() {
  return (
    <View style={styles.container}>
      <View style={styles.logo}>
        <Text style={styles.truck}>🚚</Text>
      </View>

      <View style={styles.copy}>
        <Text style={styles.title}>SUPPLY CHAIN</Text>
        <Text style={styles.subtitle}>Food Transportation</Text>
        <Text style={styles.tagline}>Safe. Fast. Reliable.</Text>
      </View>

      <View style={styles.actions}>
        <Button title="Get Started" onPress={() => router.push("/login")} />
        <Button
          title="Login"
          variant="secondary"
          onPress={() => router.push("/login")}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.primaryDark,
    padding: spacing.xl,
    justifyContent: "space-between",
  },
  logo: {
    alignSelf: "center",
    marginTop: 90,
    width: 110,
    height: 110,
    borderRadius: 55,
    backgroundColor: "#FFFFFF",
    alignItems: "center",
    justifyContent: "center",
  },
  truck: { fontSize: 54 },
  copy: { alignItems: "center" },
  title: {
    color: "#FFFFFF",
    fontSize: 25,
    fontWeight: "800",
    letterSpacing: 0.5,
  },
  subtitle: { color: "#FFFFFF", fontSize: 16, marginTop: 5 },
  tagline: { color: "#D7EEE1", fontSize: 13, marginTop: 5 },
  actions: { gap: spacing.md, marginBottom: spacing.lg },
});
