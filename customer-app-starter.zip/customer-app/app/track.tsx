import { router, useLocalSearchParams } from "expo-router";
import { StyleSheet, Text, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { Button } from "@/components/ui/Button";
import { Screen } from "@/components/ui/Screen";
import { colors, radius, spacing } from "@/constants/theme";

export default function TrackScreen() {
  const { orderId } = useLocalSearchParams<{ orderId?: string }>();

  return (
    <Screen>
      <View style={styles.header}>
        <Text style={styles.title}>Track Order</Text>
        <Text style={styles.id}>Order ID: {orderId ?? "Pending"}</Text>
      </View>

      <View style={styles.status}>
        <View style={styles.check}>
          <Ionicons name="checkmark" size={20} color="#FFFFFF" />
        </View>
        <View>
          <Text style={styles.statusTitle}>In Transit</Text>
          <Text style={styles.statusText}>Your food is on the way.</Text>
        </View>
      </View>

      <View style={styles.map}>
        <Ionicons name="map-outline" size={64} color={colors.primary} />
        <Text style={styles.mapText}>Live map will connect here.</Text>
      </View>

      <View style={styles.driver}>
        <View style={styles.avatar}>
          <Ionicons name="person" size={22} color={colors.primary} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.driverName}>Rider: Kojo Mensah</Text>
          <Text style={styles.rating}>★ 4.8</Text>
        </View>
        <Ionicons name="call-outline" size={22} color={colors.primary} />
        <Ionicons name="chatbubble-outline" size={22} color={colors.primary} />
      </View>

      <Text style={styles.eta}>ETA: 15 mins</Text>

      <Button title="Back to Home" onPress={() => router.replace("/(tabs)")} />
    </Screen>
  );
}

const styles = StyleSheet.create({
  header: { gap: 4 },
  title: { fontSize: 25, fontWeight: "800", color: colors.text },
  id: { color: colors.muted, fontSize: 12 },
  status: {
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    padding: spacing.lg,
    flexDirection: "row",
    gap: spacing.md,
    alignItems: "center",
  },
  check: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.success,
    alignItems: "center",
    justifyContent: "center",
  },
  statusTitle: { color: colors.text, fontWeight: "800" },
  statusText: { color: colors.muted, marginTop: 2 },
  map: {
    height: 300,
    borderRadius: radius.md,
    backgroundColor: "#EAF0ED",
    alignItems: "center",
    justifyContent: "center",
    gap: spacing.sm,
  },
  mapText: { color: colors.muted },
  driver: {
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    padding: spacing.md,
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
  },
  avatar: {
    width: 46,
    height: 46,
    borderRadius: 23,
    backgroundColor: colors.primarySoft,
    alignItems: "center",
    justifyContent: "center",
  },
  driverName: { color: colors.text, fontWeight: "700" },
  rating: { color: colors.orange, marginTop: 3 },
  eta: { color: colors.text, fontWeight: "800" },
});
