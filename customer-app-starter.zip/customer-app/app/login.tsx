import { zodResolver } from "@hookform/resolvers/zod";
import { router } from "expo-router";
import { Controller, useForm } from "react-hook-form";
import { Alert, StyleSheet, Text, View } from "react-native";
import { z } from "zod";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { Screen } from "@/components/ui/Screen";
import { colors, spacing } from "@/constants/theme";
import { login } from "@/services/auth";
import { useAuthStore } from "@/store/auth";

const schema = z.object({
  phone: z.string().min(9, "Enter a valid phone number."),
  password: z.string().min(6, "Password must be at least 6 characters."),
});

type FormData = z.infer<typeof schema>;

export default function LoginScreen() {
  const setSession = useAuthStore((state) => state.setSession);
  const { control, handleSubmit, formState: { errors, isSubmitting } } =
    useForm<FormData>({
      resolver: zodResolver(schema),
      defaultValues: { phone: "", password: "" },
    });

  const onSubmit = async (data: FormData) => {
    try {
      const response = await login(data);
      await setSession(response.accessToken, response.user);
      router.replace("/(tabs)");
    } catch (error) {
      Alert.alert(
        "Login failed",
        error instanceof Error ? error.message : "Please try again.",
      );
    }
  };

  return (
    <Screen>
      <View style={styles.header}>
        <Text style={styles.title}>Welcome Back!</Text>
        <Text style={styles.subtitle}>Login to continue</Text>
      </View>

      <View style={styles.form}>
        <Controller
          control={control}
          name="phone"
          render={({ field: { onChange, onBlur, value } }) => (
            <Input
              label="Phone Number"
              placeholder="+233 24 123 4567"
              keyboardType="phone-pad"
              autoComplete="tel"
              value={value}
              onBlur={onBlur}
              onChangeText={onChange}
              error={errors.phone?.message}
            />
          )}
        />

        <Controller
          control={control}
          name="password"
          render={({ field: { onChange, onBlur, value } }) => (
            <Input
              label="Password"
              placeholder="••••••••"
              secureTextEntry
              value={value}
              onBlur={onBlur}
              onChangeText={onChange}
              error={errors.password?.message}
            />
          )}
        />

        <Text style={styles.forgot}>Forgot Password?</Text>

        <Button
          title="Login"
          loading={isSubmitting}
          onPress={handleSubmit(onSubmit)}
        />

        <Button
          title="Continue with Google"
          variant="secondary"
          onPress={() => Alert.alert("Coming soon", "Google sign-in will be connected to the auth provider.")}
        />

        <Text style={styles.register}>
          Don't have an account? <Text style={styles.link}>Register</Text>
        </Text>
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  header: { marginTop: spacing.xl, gap: spacing.sm },
  title: { fontSize: 25, fontWeight: "800", color: colors.text },
  subtitle: { fontSize: 14, color: colors.muted },
  form: { gap: spacing.lg },
  forgot: {
    alignSelf: "flex-end",
    color: colors.primary,
    fontSize: 12,
    fontWeight: "600",
  },
  register: {
    textAlign: "center",
    color: colors.muted,
    fontSize: 13,
    marginTop: spacing.md,
  },
  link: { color: colors.primary, fontWeight: "700" },
});
