import { StyleSheet, Text } from "react-native";
import { Screen } from "@/components/ui/Screen";
import { colors } from "@/constants/theme";

export default function MessagesScreen() {
  return (
    <Screen>
      <Text style={styles.title}>Messages</Text>
      <Text style={styles.empty}>Your delivery conversations will appear here.</Text>
    </Screen>
  );
}

const styles = StyleSheet.create({
  title: { fontSize: 25, fontWeight: "800", color: colors.text },
  empty: { color: colors.muted, marginTop: 24 },
});
