import { router } from "expo-router";
import { StyleSheet, Text, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { Button } from "@/components/ui/Button";
import { Screen } from "@/components/ui/Screen";
import { colors, radius, spacing } from "@/constants/theme";
import { useAuthStore } from "@/store/auth";

export default function ProfileScreen() {
  const user = useAuthStore((state) => state.user);
  const logout = useAuthStore((state) => state.logout);

  const handleLogout = async () => {
    await logout();
    router.replace("/login");
  };

  return (
    <Screen>
      <View style={styles.profile}>
        <View style={styles.avatar}>
          <Ionicons name="person" size={32} color={colors.primary} />
        </View>
        <Text style={styles.name}>{user?.name ?? "Customer"}</Text>
        <Text style={styles.phone}>{user?.phone ?? "—"}</Text>
      </View>

      {["Personal Information", "Saved Addresses", "Payment Methods", "Settings"].map(
        (item) => (
          <View key={item} style={styles.row}>
            <Text style={styles.rowText}>{item}</Text>
            <Text style={styles.chevron}>›</Text>
          </View>
        ),
      )}

      <Button title="Logout" variant="secondary" onPress={handleLogout} />
    </Screen>
  );
}

const styles = StyleSheet.create({
  profile: { alignItems: "center", gap: spacing.sm, paddingVertical: spacing.lg },
  avatar: {
    width: 84,
    height: 84,
    borderRadius: 42,
    backgroundColor: colors.primarySoft,
    alignItems: "center",
    justifyContent: "center",
  },
  name: { color: colors.text, fontSize: 20, fontWeight: "800" },
  phone: { color: colors.muted },
  row: {
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    padding: spacing.lg,
    flexDirection: "row",
    justifyContent: "space-between",
    borderWidth: 1,
    borderColor: colors.border,
  },
  rowText: { color: colors.text, fontWeight: "600" },
  chevron: { color: colors.muted, fontSize: 22 },
});
