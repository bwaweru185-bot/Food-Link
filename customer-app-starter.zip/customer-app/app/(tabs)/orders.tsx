import { useQuery } from "@tanstack/react-query";
import { ActivityIndicator, StyleSheet, Text, View } from "react-native";
import { OrderCard } from "@/components/order/OrderCard";
import { Screen } from "@/components/ui/Screen";
import { colors, spacing } from "@/constants/theme";
import { getRecentOrders } from "@/services/orders";
import { useAuthStore } from "@/store/auth";

export default function OrdersScreen() {
  const token = useAuthStore((state) => state.token);
  const query = useQuery({
    queryKey: ["orders", "all"],
    queryFn: () => getRecentOrders(token!),
    enabled: Boolean(token),
  });

  return (
    <Screen>
      <Text style={styles.title}>Orders</Text>
      <Text style={styles.subtitle}>Your recent food transportation orders.</Text>

      {query.isLoading ? (
        <ActivityIndicator color={colors.primary} />
      ) : query.isError ? (
        <Text style={styles.error}>Unable to load orders.</Text>
      ) : (
        <View style={styles.list}>
          {(query.data ?? []).map((order) => (
            <OrderCard key={order.id} order={order} />
          ))}
          {!query.data?.length ? (
            <Text style={styles.empty}>No orders yet.</Text>
          ) : null}
        </View>
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  title: { fontSize: 25, fontWeight: "800", color: colors.text },
  subtitle: { color: colors.muted, marginTop: -spacing.md },
  list: { gap: spacing.md },
  error: { color: colors.danger },
  empty: { color: colors.muted, textAlign: "center", marginTop: spacing.xxl },
});
