import { zodResolver } from "@hookform/resolvers/zod";
import { router } from "expo-router";
import { Controller, useForm } from "react-hook-form";
import { Alert, StyleSheet, Text } from "react-native";
import { z } from "zod";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { Screen } from "@/components/ui/Screen";
import { colors, spacing } from "@/constants/theme";
import { createOrder } from "@/services/orders";
import { useAuthStore } from "@/store/auth";

const schema = z.object({
  foodType: z.string().min(2, "Enter the food type."),
  quantity: z.string().min(1, "Enter quantity or weight."),
  pickupAddress: z.string().min(3, "Enter pickup location."),
  deliveryAddress: z.string().min(3, "Enter delivery location."),
  pickupDate: z.string().min(3, "Enter pickup date."),
  pickupTime: z.string().min(2, "Enter pickup time."),
  contactPhone: z.string().min(9, "Enter a valid phone number."),
  specialInstructions: z.string().optional(),
});

type FormData = z.infer<typeof schema>;

export default function SendScreen() {
  const token = useAuthStore((state) => state.token);
  const { control, handleSubmit, formState: { errors, isSubmitting } } =
    useForm<FormData>({
      resolver: zodResolver(schema),
      defaultValues: {
        foodType: "Fufu & Light Soup",
        quantity: "2 kg",
        pickupAddress: "Achimota, Accra",
        deliveryAddress: "Madina, Accra",
        pickupDate: "Today",
        pickupTime: "2:00 PM",
        contactPhone: "",
        specialInstructions: "Please handle with care.",
      },
    });

  const onSubmit = async (data: FormData) => {
    if (!token) {
      router.replace("/login");
      return;
    }

    try {
      const order = await createOrder(token, data);
      router.push({
        pathname: "/confirm",
        params: { orderId: order.id, total: String(order.total) },
      });
    } catch (error) {
      Alert.alert(
        "Unable to create order",
        error instanceof Error ? error.message : "Please try again.",
      );
    }
  };

  return (
    <Screen>
      <Text style={styles.title}>Send Food</Text>
      <Text style={styles.subtitle}>Enter food details</Text>

      <Controller
        control={control}
        name="foodType"
        render={({ field: { onChange, value } }) => (
          <Input
            label="Food Type"
            value={value}
            onChangeText={onChange}
            error={errors.foodType?.message}
          />
        )}
      />

      <Controller
        control={control}
        name="quantity"
        render={({ field: { onChange, value } }) => (
          <Input
            label="Quantity / Weight"
            value={value}
            onChangeText={onChange}
            error={errors.quantity?.message}
          />
        )}
      />

      <Controller
        control={control}
        name="pickupAddress"
        render={({ field: { onChange, value } }) => (
          <Input
            label="Pickup Location"
            value={value}
            onChangeText={onChange}
            error={errors.pickupAddress?.message}
          />
        )}
      />

      <Controller
        control={control}
        name="deliveryAddress"
        render={({ field: { onChange, value } }) => (
          <Input
            label="Delivery Location"
            value={value}
            onChangeText={onChange}
            error={errors.deliveryAddress?.message}
          />
        )}
      />

      <Controller
        control={control}
        name="pickupDate"
        render={({ field: { onChange, value } }) => (
          <Input
            label="Pickup Date"
            value={value}
            onChangeText={onChange}
            error={errors.pickupDate?.message}
          />
        )}
      />

      <Controller
        control={control}
        name="pickupTime"
        render={({ field: { onChange, value } }) => (
          <Input
            label="Pickup Time"
            value={value}
            onChangeText={onChange}
            error={errors.pickupTime?.message}
          />
        )}
      />

      <Controller
        control={control}
        name="contactPhone"
        render={({ field: { onChange, value } }) => (
          <Input
            label="Contact Person"
            value={value}
            keyboardType="phone-pad"
            onChangeText={onChange}
            error={errors.contactPhone?.message}
          />
        )}
      />

      <Controller
        control={control}
        name="specialInstructions"
        render={({ field: { onChange, value } }) => (
          <Input
            label="Special Instructions (optional)"
            value={value}
            multiline
            numberOfLines={4}
            onChangeText={onChange}
          />
        )}
      />

      <Button
        title="Continue"
        loading={isSubmitting}
        onPress={handleSubmit(onSubmit)}
      />
    </Screen>
  );
}

const styles = StyleSheet.create({
  title: { fontSize: 25, fontWeight: "800", color: colors.text },
  subtitle: { color: colors.muted, marginTop: -spacing.md },
});
