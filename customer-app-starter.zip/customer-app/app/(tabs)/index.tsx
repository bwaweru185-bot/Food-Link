import { Link } from "expo-router";
import { useQuery } from "@tanstack/react-query";
import { StyleSheet, Text, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { OrderCard } from "@/components/order/OrderCard";
import { Screen } from "@/components/ui/Screen";
import { colors, radius, spacing } from "@/constants/theme";
import { getRecentOrders } from "@/services/orders";
import { useAuthStore } from "@/store/auth";

export default function DashboardScreen() {
  const token = useAuthStore((state) => state.token);
  const user = useAuthStore((state) => state.user);

  const ordersQuery = useQuery({
    queryKey: ["orders", "recent"],
    queryFn: () => getRecentOrders(token!),
    enabled: Boolean(token),
  });

  const orders = ordersQuery.data ?? [
    {
      id: "demo-1",
      foodType: "Fufu & Light Soup",
      quantity: "2 kg",
      pickupAddress: "Achimota, Accra",
      deliveryAddress: "Madina, Accra",
      status: "delivered" as const,
      total: 15,
      createdAt: new Date().toISOString(),
    },
  ];

  return (
    <Screen>
      <View style={styles.header}>
        <View>
          <Text style={styles.greeting}>Hello, {user?.name ?? "there"}</Text>
          <Text style={styles.subtitle}>What would you like to do?</Text>
        </View>
        <View style={styles.avatar}>
          <Ionicons name="person" size={20} color={colors.primary} />
        </View>
      </View>

      <View style={styles.actions}>
        <Link href="/(tabs)/send" asChild>
          <View style={styles.actionCard}>
            <Ionicons name="send" size={22} color="#FFFFFF" />
            <Text style={styles.actionText}>Send Food</Text>
          </View>
        </Link>

        <View style={[styles.actionCard, styles.trackCard]}>
          <Ionicons name="location" size={22} color="#FFFFFF" />
          <Text style={styles.actionText}>Track Order</Text>
        </View>
      </View>

      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>Recent Orders</Text>
        <Link href="/(tabs)/orders">
          <Text style={styles.viewAll}>View all</Text>
        </Link>
      </View>

      <View style={styles.orders}>
        {orders.map((order) => (
          <OrderCard key={order.id} order={order} />
        ))}
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  greeting: { color: colors.text, fontSize: 20, fontWeight: "800" },
  subtitle: { color: colors.muted, fontSize: 13, marginTop: 3 },
  avatar: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: colors.primarySoft,
    alignItems: "center",
    justifyContent: "center",
  },
  actions: { flexDirection: "row", gap: spacing.md },
  actionCard: {
    flex: 1,
    minHeight: 86,
    borderRadius: radius.md,
    backgroundColor: colors.primary,
    padding: spacing.md,
    justifyContent: "space-between",
  },
  trackCard: { backgroundColor: colors.primaryDark },
  actionText: { color: "#FFFFFF", fontWeight: "700", fontSize: 13 },
  sectionHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  sectionTitle: { color: colors.text, fontSize: 17, fontWeight: "800" },
  viewAll: { color: colors.primary, fontWeight: "700", fontSize: 12 },
  orders: { gap: spacing.md },
});
